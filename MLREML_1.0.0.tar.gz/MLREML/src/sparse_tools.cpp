// sparse_tools.cpp -- compiled helpers of MLREML (version 1.0.0)
//   * takahashi_cpp: selected inverse of a sparse symmetric positive definite matrix C = L L' (Takahashi,
//     Fagan and Chen, 1973; Erisman and Tinney, 1975): returns the elements of C^{-1} on the (filled)
//     pattern of the Cholesky factor L.
//   * sel_lookup_cpp, trace_sel_cpp: elements of the selected inverse and traces tr(C^{-1} B) for sparse B.
//   * inbreeding_cpp: inbreeding coefficients by the algorithm of Meuwissen and Luo (1992).
#define USE_FC_LEN_T
#include <Rcpp.h>
#include <R_ext/BLAS.h>
#include <R_ext/Lapack.h>
#ifndef FCONE
#define FCONE
#endif
#include <queue>
#include <vector>
#include <algorithm>
using namespace Rcpp;

// position of row r in column c of a CSC pattern (rows sorted increasingly); -1 if absent
static inline int find_pos(const int* Lp, const int* Li, int r, int c) {
  const int* b = Li + Lp[c];
  const int* e = Li + Lp[c + 1];
  const int* it = std::lower_bound(b, e, r);
  if (it != e && *it == r) return (int)(it - Li);
  return -1;
}

// scalar recursion for column i (used for columns outside large supernodes)
static void taka_column(int i, const int* lp, const int* li, const double* Lx, double* Zx,
                        std::vector<double>& u, std::vector<double>& w) {
  int p0 = lp[i], p1 = lp[i + 1];
  double lii = Lx[p0];
  int m = p1 - p0 - 1;
  const int* S = li + p0 + 1;
  u.assign(m, 0.0); w.assign(m, 0.0);
  for (int a = 0; a < m; a++) u[a] = Lx[p0 + 1 + a] / lii;
  for (int b = 0; b < m; b++) {
    int k = S[b];
    int q = lp[k], qe = lp[k + 1];
    w[b] += u[b] * Zx[q];
    q++;
    for (int a = b + 1; a < m; a++) {
      int r = S[a];
      while (q < qe && li[q] < r) q++;
      if (q >= qe || li[q] != r) Rcpp::stop("takahashi: pattern not closed at (%d, %d)", r, k);
      double z = Zx[q];
      w[a] += u[b] * z;
      w[b] += u[a] * z;
    }
  }
  double s = 0.0;
  for (int a = 0; a < m; a++) { Zx[p0 + 1 + a] = -w[a]; s += u[a] * (-w[a]); }
  Zx[p0] = 1.0 / (lii * lii) - s;
}

// [[Rcpp::export]]
NumericVector takahashi_cpp(IntegerVector Lp, IntegerVector Li, NumericVector Lx, int n) {
  // Elements of C^{-1} on the pattern of the Cholesky factor L (C = L L'; lower triangular,
  // diagonal stored first in each column, rows sorted). Columns are processed from the last
  // to the first with the recursions of Takahashi et al. (1973):
  //   Z_{s_a,i} = - sum_b u_b Z_{s_a,s_b},   Z_ii = 1 / L_ii^2 - sum_a u_a Z_{s_a,i},
  // u_a = L_{s_a,i} / L_ii, S_i = {s_1 < ... < s_m} the rows below the diagonal of column i.
  // Consecutive columns with nested structure (supernodes J, S_j = {j+1, ..., l} U R) are
  // processed as dense blocks with BLAS/LAPACK (Lin et al., 2011, SelInv):
  //   U = L_RJ L_JJ^{-1},  Z_RJ = - Z_RR U,  Z_JJ = (L_JJ L_JJ')^{-1} - U' Z_RJ.
  // Elements Z_{r,k} needed on the right-hand side are found by a sorted merge of the rows
  // with column k (the pattern of a Cholesky factor is closed), without searches.
  NumericVector Zx(Lx.size());
  const int* lp = Lp.begin(); const int* li = Li.begin();
  const double* lx = Lx.begin(); double* zx = Zx.begin();
  for (int i = 0; i < n; i++) {
    if (lp[i + 1] <= lp[i] || li[lp[i]] != i) stop("takahashi: the diagonal of column %d is not stored first", i);
    if (!(lx[lp[i]] > 0)) stop("takahashi: non-positive pivot in column %d", i);
  }
  // fundamental supernodes
  std::vector<int> sf, sl;
  int f = 0;
  for (int i = 0; i < n; i++) {
    bool join = false;
    if (i + 1 < n) {
      int a0 = lp[i], a1 = lp[i + 1], b0 = lp[i + 1], b1 = lp[i + 2];
      if (a1 - a0 >= 2 && a1 - a0 == b1 - b0 + 1 && li[a0 + 1] == i + 1)
        join = std::equal(li + a0 + 2, li + a1, li + b0 + 1);
    }
    if (!join) { sf.push_back(f); sl.push_back(i); f = i + 1; }
  }
  std::vector<double> u, w, LJJ, U, ZRR, ZRJ;
  int one = 1; double dzero = 0.0, done = 1.0, dmone = -1.0;
  for (int sn = (int)sf.size() - 1; sn >= 0; sn--) {
    int fs = sf[sn], ls = sl[sn], ns = ls - fs + 1;
    int m = lp[ls + 1] - lp[ls] - 1;
    const int* R = li + lp[ls] + 1;
    if (ns < 2 || (double)ns * (m + ns) < 64.0) {
      for (int i = ls; i >= fs; i--) taka_column(i, lp, li, lx, zx, u, w);
      continue;
    }
    // dense blocks L_JJ (ns x ns, lower) and U = L_RJ (m x ns), column-major
    LJJ.assign((size_t)ns * ns, 0.0); U.assign((size_t)m * ns, 0.0);
    for (int j = 0; j < ns; j++) {
      int p0 = lp[fs + j];
      for (int t = 0; t < ns - j; t++) LJJ[(size_t)(j + t) + (size_t)j * ns] = lx[p0 + t];
      for (int r = 0; r < m; r++) U[(size_t)r + (size_t)j * m] = lx[p0 + (ns - j) + r];
    }
    if (m > 0) {
      // U = L_RJ L_JJ^{-1}
      F77_CALL(dtrsm)("R", "L", "N", "N", &m, &ns, &done, LJJ.data(), &ns, U.data(), &m FCONE FCONE FCONE FCONE);
      // Z_RR (lower triangle) gathered from the columns of R
      ZRR.assign((size_t)m * m, 0.0);
      for (int b = 0; b < m; b++) {
        int k = R[b];
        int q = lp[k], qe = lp[k + 1];
        ZRR[(size_t)b + (size_t)b * m] = zx[q];
        q++;
        for (int a = b + 1; a < m; a++) {
          int r = R[a];
          while (q < qe && li[q] < r) q++;
          if (q >= qe || li[q] != r) stop("takahashi: pattern not closed at (%d, %d)", r, k);
          ZRR[(size_t)a + (size_t)b * m] = zx[q];
        }
      }
      // Z_RJ = - Z_RR U
      ZRJ.assign((size_t)m * ns, 0.0);
      F77_CALL(dsymm)("L", "L", &m, &ns, &dmone, ZRR.data(), &m, U.data(), &m, &dzero, ZRJ.data(), &m FCONE FCONE);
    }
    // Z_JJ = (L_JJ L_JJ')^{-1} - U' Z_RJ  (lower triangle)
    int info = 0;
    F77_CALL(dpotri)("L", &ns, LJJ.data(), &ns, &info FCONE);
    if (info != 0) stop("takahashi: dpotri failed (info = %d)", info);
    if (m > 0)
      F77_CALL(dgemm)("T", "N", &ns, &ns, &m, &dmone, U.data(), &m, ZRJ.data(), &m, &done, LJJ.data(), &ns FCONE FCONE);
    for (int j = 0; j < ns; j++) {
      int p0 = lp[fs + j];
      for (int t = 0; t < ns - j; t++) zx[p0 + t] = LJJ[(size_t)(j + t) + (size_t)j * ns];
      for (int r = 0; r < m; r++) zx[p0 + (ns - j) + r] = ZRJ[(size_t)r + (size_t)j * m];
    }
    (void)one;
    Rcpp::checkUserInterrupt();
  }
  return Zx;
}

// [[Rcpp::export]]
NumericVector sel_lookup_cpp(IntegerVector Lp, IntegerVector Li, NumericVector Zx, IntegerVector r, IntegerVector c) {
  int m = r.size(); NumericVector out(m);
  for (int a = 0; a < m; a++) {
    int rr = std::max(r[a], c[a]), cc = std::min(r[a], c[a]);
    int pos = find_pos(Lp.begin(), Li.begin(), rr, cc);
    out[a] = pos < 0 ? NA_REAL : Zx[pos];
  }
  return out;
}

// tr(C^{-1} B) for a sparse B (CSC, both triangles stored) given in the original ordering;
// pinv maps original indices to the permuted ordering of the factor (0-based)
// [[Rcpp::export]]
double trace_sel_cpp(IntegerVector Lp, IntegerVector Li, NumericVector Zx, IntegerVector pinv,
                     IntegerVector Bp, IntegerVector Bi, NumericVector Bx, int offset) {
  int nc = Bp.size() - 1; double s = 0.0;
  for (int j = 0; j < nc; j++) {
    int cj = pinv[j + offset];
    for (int p = Bp[j]; p < Bp[j + 1]; p++) {
      if (Bx[p] == 0.0) continue;
      int ri = pinv[Bi[p] + offset];
      int rr = std::max(ri, cj), cc = std::min(ri, cj);
      int pos = find_pos(Lp.begin(), Li.begin(), rr, cc);
      if (pos < 0) stop("trace_sel: element (%d, %d) outside the pattern of the factor", rr, cc);
      s += Bx[p] * Zx[pos];
    }
  }
  return s;
}

// Meuwissen and Luo (1992). s, d: 1-based positions of the parents (0 = unknown); parents precede offspring
// [[Rcpp::export]]
NumericVector inbreeding_cpp(IntegerVector s, IntegerVector d) {
  int n = s.size();
  NumericVector F(n); std::vector<double> D(n), L(n, 0.0);
  std::vector<char> inq(n, 0); std::vector<int> visited;
  for (int i = 0; i < n; i++) {
    double Fs = s[i] > 0 ? F[s[i] - 1] : -1.0, Fd = d[i] > 0 ? F[d[i] - 1] : -1.0;
    D[i] = 0.5 - 0.25 * (Fs + Fd);
    if (s[i] == 0 || d[i] == 0) { F[i] = 0.0; continue; }
    if (i > 0 && s[i] == s[i - 1] && d[i] == d[i - 1]) { F[i] = F[i - 1]; continue; }
    std::priority_queue<int> heap; visited.clear();
    L[i] = 1.0; heap.push(i); inq[i] = 1; visited.push_back(i);
    double fi = -1.0;
    while (!heap.empty()) {
      int j = heap.top(); heap.pop();
      int pj[2] = {s[j] - 1, d[j] - 1};
      for (int a = 0; a < 2; a++) {
        int k = pj[a];
        if (k < 0) continue;
        L[k] += 0.5 * L[j];
        if (!inq[k]) { inq[k] = 1; heap.push(k); visited.push_back(k); }
      }
      fi += L[j] * L[j] * D[j];
    }
    F[i] = fi;
    for (int v : visited) { L[v] = 0.0; inq[v] = 0; }
    if (i % 1000 == 0) Rcpp::checkUserInterrupt();
  }
  return F;
}

// ---------------------------------------------------------------------------------------------
// Supernodal versions working directly on the CHOLMOD supernodal factor (Matrix class dCHMsuper):
// supernode k has columns super[k] .. super[k+1]-1, row indices s[pi[k] .. pi[k+1]-1] (sorted; the
// first ones are the columns of the supernode) and values x[px[k] ..] stored column by column in a
// dense nrow x ncol block. The selected inverse Z is returned in the same layout.

static inline int find_row(const int* s, int b, int e, int r) {
  const int* it = std::lower_bound(s + b, s + e, r);
  if (it != s + e && *it == r) return (int)(it - s) - b;
  return -1;
}

// [[Rcpp::export]]
NumericVector takahashi_super_cpp(IntegerVector super, IntegerVector pi, IntegerVector px,
                                  IntegerVector s, NumericVector x, bool inplace = false) {
  // with inplace = true the values of the factor are overwritten by those of the inverse (the
  // supernodes are processed from the last one, and the block of L of a supernode is copied before
  // its block of Z is written), which halves the memory needed
  int nsuper = super.size() - 1;
  int n = super[nsuper];
  NumericVector Zx = inplace ? x : NumericVector(x.size());
  const int* sp = s.begin();
  double* zx = Zx.begin(); const double* lx = x.begin();
  std::vector<int> col2sup(n);
  for (int k = 0; k < nsuper; k++) for (int c = super[k]; c < super[k + 1]; c++) col2sup[c] = k;
  std::vector<double> LJJ, U, ZRR, ZRJ;
  double dzero = 0.0, done = 1.0, dmone = -1.0;
  for (int k = nsuper - 1; k >= 0; k--) {
    int ns = super[k + 1] - super[k];
    int nr = pi[k + 1] - pi[k];
    int m = nr - ns;
    const int* R = sp + pi[k] + ns;
    const double* blk = lx + px[k];
    LJJ.assign((size_t)ns * ns, 0.0);
    for (int j = 0; j < ns; j++) for (int i = j; i < ns; i++) LJJ[i + (size_t)j * ns] = blk[i + (size_t)j * nr];
    for (int j = 0; j < ns; j++) if (!(LJJ[j + (size_t)j * ns] > 0)) stop("takahashi: non-positive pivot");
    if (m > 0) {
      U.assign((size_t)m * ns, 0.0);
      for (int j = 0; j < ns; j++) for (int i = 0; i < m; i++) U[i + (size_t)j * m] = blk[ns + i + (size_t)j * nr];
      F77_CALL(dtrsm)("R", "L", "N", "N", &m, &ns, &done, LJJ.data(), &ns, U.data(), &m FCONE FCONE FCONE FCONE);
      // gather Z_RR (lower triangle) from the supernodes already processed
      ZRR.assign((size_t)m * m, 0.0);
      for (int b = 0; b < m; b++) {
        int c = R[b], K = col2sup[c];
        int nrK = pi[K + 1] - pi[K], cK = c - super[K];
        const int* sK = sp + pi[K];
        const double* zK = zx + px[K] + (size_t)cK * nrK;
        int q = cK;                                   // row c is at position cK of supernode K
        ZRR[b + (size_t)b * m] = zK[q];
        q++;
        for (int a = b + 1; a < m; a++) {
          int r = R[a];
          while (q < nrK && sK[q] < r) q++;
          if (q >= nrK || sK[q] != r) stop("takahashi: pattern not closed at (%d, %d)", r, c);
          ZRR[a + (size_t)b * m] = zK[q];
        }
      }
      ZRJ.assign((size_t)m * ns, 0.0);
      F77_CALL(dsymm)("L", "L", &m, &ns, &dmone, ZRR.data(), &m, U.data(), &m, &dzero, ZRJ.data(), &m FCONE FCONE);
    }
    int info = 0;
    F77_CALL(dpotri)("L", &ns, LJJ.data(), &ns, &info FCONE);
    if (info != 0) stop("takahashi: dpotri failed (info = %d)", info);
    if (m > 0)
      F77_CALL(dgemm)("T", "N", &ns, &ns, &m, &dmone, U.data(), &m, ZRJ.data(), &m, &done, LJJ.data(), &ns FCONE FCONE);
    double* zb = zx + px[k];
    for (int j = 0; j < ns; j++) {
      for (int i = j; i < ns; i++) { double v = LJJ[i + (size_t)j * ns]; zb[i + (size_t)j * nr] = v; zb[j + (size_t)i * nr] = v; }
      for (int i = 0; i < m; i++) zb[ns + i + (size_t)j * nr] = ZRJ[i + (size_t)j * m];
    }
    if (k % 256 == 0) Rcpp::checkUserInterrupt();
  }
  return Zx;
}

// elements (r, c) (0-based, permuted order) of a matrix stored in the supernodal layout; NA if absent
// [[Rcpp::export]]
NumericVector super_lookup_cpp(IntegerVector super, IntegerVector pi, IntegerVector px, IntegerVector s,
                               NumericVector Zx, IntegerVector col2sup, IntegerVector r, IntegerVector c) {
  int nn = r.size(); NumericVector out(nn);
  for (int a = 0; a < nn; a++) {
    int rr = std::max(r[a], c[a]), cc = std::min(r[a], c[a]);
    int K = col2sup[cc];
    int nrK = pi[K + 1] - pi[K];
    int pos = find_row(s.begin(), pi[K], pi[K + 1], rr);
    out[a] = pos < 0 ? NA_REAL : Zx[px[K] + (size_t)(cc - super[K]) * nrK + pos];
  }
  return out;
}

// tr(Z B) for a sparse B (CSC, both triangles, original ordering) and Z in the supernodal layout
// [[Rcpp::export]]
double super_trace_cpp(IntegerVector super, IntegerVector pi, IntegerVector px, IntegerVector s,
                       NumericVector Zx, IntegerVector col2sup, IntegerVector pinv,
                       IntegerVector Bp, IntegerVector Bi, NumericVector Bx, int offset) {
  int nc = Bp.size() - 1; double tot = 0.0;
  for (int j = 0; j < nc; j++) {
    int cj = pinv[j + offset];
    for (int p = Bp[j]; p < Bp[j + 1]; p++) {
      if (Bx[p] == 0.0) continue;
      int ri = pinv[Bi[p] + offset];
      int rr = std::max(ri, cj), cc = std::min(ri, cj);
      int K = col2sup[cc];
      int nrK = pi[K + 1] - pi[K];
      int pos = find_row(s.begin(), pi[K], pi[K + 1], rr);
      if (pos < 0) stop("trace: element (%d, %d) outside the pattern of the factor", rr, cc);
      tot += Bx[p] * Zx[px[K] + (size_t)(cc - super[K]) * nrK + pos];
    }
  }
  return tot;
}

// log-determinant 2 sum log L_jj of the supernodal factor
// [[Rcpp::export]]
double super_logdet_cpp(IntegerVector super, IntegerVector pi, IntegerVector px, NumericVector x) {
  int nsuper = super.size() - 1; double ld = 0.0;
  for (int k = 0; k < nsuper; k++) {
    int ns = super[k + 1] - super[k], nr = pi[k + 1] - pi[k];
    for (int j = 0; j < ns; j++) ld += std::log(x[px[k] + (size_t)j * nr + j]);
  }
  return 2.0 * ld;
}
