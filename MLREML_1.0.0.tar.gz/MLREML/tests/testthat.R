library(testthat)
library(MLREML)
test_check("MLREML")
