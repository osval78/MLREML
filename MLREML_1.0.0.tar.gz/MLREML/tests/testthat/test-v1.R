## Tests of the corrections and new features of version 1.0.0

sim_ped <- function(nf = 40, ngen = 3, noff = 80, seed = 1) {
  set.seed(seed)
  ped <- data.frame(id = paste0("F", 1:nf), sire = NA, dam = NA,
                    sex = rep(c("M", "F"), length.out = nf), gen = 0)
  for (g in 1:ngen) {
    m <- ped$id[ped$sex == "M"]; f <- ped$id[ped$sex == "F"]
    ped <- rbind(ped, data.frame(id = paste0("G", g, "_", 1:noff), sire = sample(m, noff, TRUE),
                                 dam = sample(f, noff, TRUE), sex = sample(c("M", "F"), noff, TRUE),
                                 gen = g))
  }
  ped
}

test_that("exponential correlation with distances below one agrees with nlme (0.9.0 bug)", {
  skip_if_not_installed("nlme")
  set.seed(7)
  d <- data.frame(t = rep(c(0, 0.3, 0.7, 1.2, 2), 20), id = factor(rep(1:20, each = 5)))
  d$y <- rnorm(20)[d$id] * 0 + rnorm(100)
  e <- rnorm(100)
  for (i in 1:20) { r <- d$id == i; d$y[r] <- 0.5 * d$t[r] + cumsum(e[r]) / 2 }
  f <- mlreml(y ~ t, residual = ~ expc(t):id(id), data = d, trace = FALSE)
  g <- nlme::gls(y ~ t, correlation = nlme::corExp(form = ~ t | id), data = d)
  expect_equal(f$loglik, as.numeric(logLik(g)), tolerance = 1e-6)
})

test_that("compound symmetry lower bound keeps the matrix positive definite", {
  set.seed(1)
  d <- expand.grid(rep = factor(1:4), gen = factor(1:30))
  d$y <- rnorm(nrow(d))
  f <- mlreml(y ~ 1, random = ~ cs(rep):id(gen), data = d, trace = FALSE)
  lw <- f$info$lower[grepl("cor", f$info$name)]
  expect_gt(lw, -1 / 3)
})

test_that("conditional Wald statistics respect marginality", {
  set.seed(11)
  d <- expand.grid(A = factor(1:3), B = factor(1:4), blk = factor(1:6))
  d <- d[-sample(nrow(d), 15), ]
  d$y <- c(0, .5, 1)[d$A] + c(0, .3, .6, .2)[d$B] + rnorm(6)[d$blk] + rnorm(nrow(d))
  f1 <- mlreml(y ~ A * B, random = ~ blk, data = d, trace = FALSE, tol = 1e-10)
  f2 <- mlreml(y ~ B + A + A:B, random = ~ blk, data = d, trace = FALSE, tol = 1e-10)
  w1 <- wald(f1, ddf = "residual"); w2 <- wald(f2, ddf = "residual")
  ## A adjusted for B (not for A:B) equals the incremental statistic of A after B
  expect_equal(w1$wald.con[w1$term == "A"], w2$wald.inc[w2$term == "A"], tolerance = 1e-6)
  expect_equal(w1$wald.con[w1$term == "B"], w1$wald.inc[w1$term == "B"], tolerance = 1e-6)
  expect_equal(w1$wald.con[w1$term == "A:B"], w1$wald.inc[w1$term == "A:B"], tolerance = 1e-6)
})

test_that("Kenward-Roger F tests agree with pbkrtest", {
  skip_if_not_installed("lme4"); skip_if_not_installed("pbkrtest"); skip_if_not_installed("agridat")
  d <- agridat::john.alpha
  f <- mlreml(yield ~ rep + gen, random = ~ rep:block, data = d, trace = FALSE, tol = 1e-10)
  l <- lme4::lmer(yield ~ rep + gen + (1 | rep:block), data = d)
  w <- wald(f, ddf = "KR")
  j <- which(f$assign == 2)
  L <- chol(solve(f$vcov_beta))[j, , drop = FALSE]
  st <- pbkrtest::KRmodcomp(l, L)$stats
  expect_equal(w$F.inc[w$term == "gen"], st$Fstat, tolerance = 1e-4)
  expect_equal(w$ddf.inc[w$term == "gen"], st$ddf, tolerance = 1e-4)
  expect_equal(attr(w, "ddf"), "Kenward-Roger")
})

test_that("str(): zero covariance equals two independent terms, and dense = sparse", {
  ped <- sim_ped()
  pp <- pedigree_prepare(ped[, 1:3]); A <- Amatrix(pp); Ai <- Ainverse(pp)
  expect_true(isTRUE(attr(Ai, "INVERSE")))
  set.seed(3)
  d <- ped[ped$gen >= 1, ]
  d$y <- rnorm(nrow(A))[match(d$id, rownames(A))] + rnorm(nrow(A))[match(d$dam, rownames(A))] * 0.7 +
    rnorm(nrow(d))
  nm <- "str(id, dam, K = A)!dam:id"
  f0 <- mlreml(y ~ 1, random = ~ str(id, dam, K = A), data = d, trace = FALSE,
               start = stats::setNames(0, nm), fix = nm)
  f2 <- mlreml(y ~ 1, random = ~ vm(id, A) + vm(dam, A), data = d, trace = FALSE)
  expect_equal(f0$loglik, f2$loglik, tolerance = 1e-6)
  b0 <- f0$blups[[1]]
  expect_equal(b0$blup[b0$effect == "dam"], f2$blups[[2]]$blup, tolerance = 1e-3)
  ## unknown dams are kept
  d$dam[1:10] <- NA
  fd <- mlreml(y ~ 1, random = ~ str(id, dam, K = A), data = d, trace = FALSE, engine = "dense")
  fs <- mlreml(y ~ 1, random = ~ str(id, dam, K = Ai), data = d, trace = FALSE, engine = "sparse")
  expect_equal(fd$n, nrow(d))
  expect_equal(fd$loglik, fs$loglik, tolerance = 1e-7)
  expect_equal(unname(fd$theta), unname(fs$theta), tolerance = 1e-5)
  expect_equal(fd$blups[[1]]$pev, fs$blups[[1]]$pev, tolerance = 1e-6)
})

test_that("sparse engine reproduces the dense engine", {
  skip_if_not_installed("lme4"); skip_if_not_installed("nlme"); skip_if_not_installed("agridat")
  chk <- function(fd, fs) {
    expect_equal(fd$loglik, fs$loglik, tolerance = 1e-8)
    expect_equal(unname(fd$theta), unname(fs$theta), tolerance = 1e-5)
    expect_equal(fd$vcov_beta, fs$vcov_beta, tolerance = 1e-6)
    for (k in seq_along(fd$blups)) {
      expect_equal(fd$blups[[k]]$blup, fs$blups[[k]]$blup, tolerance = 1e-6)
      expect_equal(fd$blups[[k]]$pev, fs$blups[[k]]$pev, tolerance = 1e-6)
    }
  }
  d <- agridat::john.alpha
  chk(mlreml(yield ~ rep, random = ~ gen + rep:block, data = d, trace = FALSE, engine = "dense"),
      mlreml(yield ~ rep, random = ~ gen + rep:block, data = d, trace = FALSE, engine = "sparse"))
  data(sleepstudy, package = "lme4")
  chk(mlreml(Reaction ~ Days, random = ~ us(leg(Days, 1)):id(Subject), data = sleepstudy,
             trace = FALSE, engine = "dense"),
      mlreml(Reaction ~ Days, random = ~ us(leg(Days, 1)):id(Subject), data = sleepstudy,
             trace = FALSE, engine = "sparse"))
  o <- as.data.frame(nlme::Orthodont); o$Subject <- factor(as.character(o$Subject))
  chk(mlreml(distance ~ age * Sex, random = ~ Subject, residual = ~ diag(Sex):units, data = o,
             trace = FALSE, engine = "dense"),
      mlreml(distance ~ age * Sex, random = ~ Subject, residual = ~ diag(Sex):units, data = o,
             trace = FALSE, engine = "sparse"))
  ## multivariate animal model with missing traits
  ped <- sim_ped(); pp <- pedigree_prepare(ped[, 1:3]); A <- Amatrix(pp); Ai <- Ainverse(pp)
  set.seed(5)
  m <- ped[ped$gen >= 1, ]
  g <- t(chol(A)) %*% matrix(rnorm(2 * nrow(A)), ncol = 2) %*% chol(matrix(c(2, 0.6, 0.6, 1), 2))
  rownames(g) <- rownames(A)
  m$y1 <- g[m$id, 1] + rnorm(nrow(m)); m$y2 <- g[m$id, 2] + rnorm(nrow(m))
  m$y1[1:15] <- NA; m$y2[20:30] <- NA
  fd <- mlreml(cbind(y1, y2) ~ trait, random = ~ us(trait):vm(id, A), data = m, trace = FALSE,
               engine = "dense")
  fs <- mlreml(cbind(y1, y2) ~ trait, random = ~ us(trait):vm(id, Ai), data = m, trace = FALSE,
               engine = "sparse")
  chk(fd, fs)
  pd <- predict(mlreml(yield ~ rep, random = ~ gen + rep:block, data = d, trace = FALSE,
                       engine = "dense"), "gen")
  ps <- predict(mlreml(yield ~ rep, random = ~ gen + rep:block, data = d, trace = FALSE,
                       engine = "sparse"), "gen")
  expect_equal(pd$pvals$std.error, ps$pvals$std.error, tolerance = 1e-8)
  expect_equal(pd$avsed, ps$avsed, tolerance = 1e-8)
})

test_that("variances on the boundary do not stall the other parameters (0.9.0 bug)", {
  set.seed(3)
  M <- matrix(rbinom(80 * 200, 2, .4), 80); rownames(M) <- paste0("g", 1:80)
  G <- Gmatrix(M) + diag(0.01, 80)
  dm <- expand.grid(gen = rownames(G), env = paste0("E", 1:4)); dm <- dm[sample(nrow(dm), 250), ]
  dm$y <- rnorm(4)[dm$env] + rnorm(80)[match(dm$gen, rownames(G))] + rnorm(nrow(dm))
  f <- mlreml(y ~ env, random = ~ vm(gen, G) + diag(env):vm(gen, G), data = dm, trace = FALSE)
  expect_true(f$converged)
  ## optimum found with a bounded quasi-Newton search: -423.5884
  expect_equal(f$loglik, -423.5884, tolerance = 1e-6)
  ## the score of the parameters that are not on the boundary is zero
  free_int <- f$varcomp$bound == "P"
  g <- suppressWarnings(mlreml(y ~ env, random = ~ vm(gen, G) + diag(env):vm(gen, G), data = dm,
                               trace = FALSE, start = f$theta * ifelse(free_int, 1.01, 1), maxit = 0))
  expect_lte(g$loglik, f$loglik)
})

test_that("compiled inbreeding agrees with the diagonal of A, including selfing", {
  ped <- data.frame(id = c("P1", "P2", "S1", "S2", "S3", "X1", "X2"),
                    sire = c(NA, NA, "P1", "S1", "S2", "S3", "X1"),
                    dam = c(NA, NA, "P1", "S1", "P2", "S2", "S3"))
  pp <- pedigree_prepare(ped)
  A <- Amatrix(pp)
  expect_equal(unname(inbreeding_coef(pp)), unname(diag(A)) - 1, tolerance = 1e-12)
  expect_equal(unname(as.matrix(Ainverse(pp)) %*% A), diag(nrow(A)), tolerance = 1e-10)
  big <- sim_ped(nf = 60, ngen = 5, noff = 150)
  pb <- pedigree_prepare(big[, 1:3])
  expect_equal(unname(inbreeding_coef(pb)), unname(diag(Amatrix(pb))) - 1, tolerance = 1e-12)
})

test_that("vm() accepts a relationship matrix given by its inverse", {
  ped <- sim_ped(); pp <- pedigree_prepare(ped[, 1:3]); A <- Amatrix(pp); Ai <- Ainverse(pp)
  set.seed(8)
  d <- ped[ped$gen >= 1, ]; d$y <- rnorm(nrow(A))[match(d$id, rownames(A))] + rnorm(nrow(d))
  f1 <- mlreml(y ~ 1, random = ~ vm(id, A), data = d, trace = FALSE)
  f2 <- mlreml(y ~ 1, random = ~ vm(id, Ai), data = d, trace = FALSE, engine = "dense")
  expect_equal(f1$loglik, f2$loglik, tolerance = 1e-8)
})

test_that("sparse (Takahashi) inverse equals the dense inverse on the pattern of the factor", {
  set.seed(1)
  n <- 600
  A <- Matrix::rsparsematrix(n, n, 0.005)
  C <- Matrix::crossprod(A) + Matrix::Diagonal(n) * 2
  C[1:20, ] <- C[1:20, ] + 0.01
  C <- Matrix::forceSymmetric((C + Matrix::t(C)) / 2)
  sel <- MLREML:::.sp_selinv(C)
  Ci <- solve(as.matrix(C))
  ij <- which(as.matrix(C) != 0, arr.ind = TRUE)
  expect_equal(sel$lookup(ij[, 1], ij[, 2]), Ci[ij], tolerance = 1e-10)
  expect_equal(sel$diag(), diag(Ci), tolerance = 1e-10)
  expect_equal(sel$logdet, as.numeric(determinant(as.matrix(C))$modulus), tolerance = 1e-10)
})
