test_that("variance components agree with lme4 (alpha lattice)", {
  skip_if_not_installed("lme4"); skip_if_not_installed("agridat")
  d <- agridat::john.alpha
  f <- mlreml(yield ~ rep, random = ~ gen + rep:block, data = d, trace = FALSE)
  l <- lme4::lmer(yield ~ rep + (1 | gen) + (1 | rep:block), data = d)
  vc <- as.data.frame(lme4::VarCorr(l))$vcov
  expect_equal(unname(f$theta), vc, tolerance = 1e-4)
  expect_equal(f$loglik, as.numeric(logLik(l)), tolerance = 1e-6)
})

test_that("random regression with us(pol()) agrees with lme4", {
  skip_if_not_installed("lme4")
  data(sleepstudy, package = "lme4")
  f <- mlreml(Reaction ~ Days, random = ~ us(pol(Days, 1)):id(Subject),
              data = sleepstudy, trace = FALSE)
  l <- lme4::lmer(Reaction ~ Days + (Days | Subject), sleepstudy)
  V <- lme4::VarCorr(l)$Subject
  expect_equal(unname(f$theta[1:3]), c(V[1, 1], V[2, 1], V[2, 2]), tolerance = 1e-4)
  expect_equal(f$loglik, as.numeric(logLik(l)), tolerance = 1e-6)
})

test_that("heterogeneous residual variances agree with nlme", {
  skip_if_not_installed("nlme")
  d <- as.data.frame(nlme::Orthodont); d$Subject <- factor(as.character(d$Subject))
  f <- mlreml(distance ~ age * Sex, random = ~ Subject, residual = ~ diag(Sex):units,
              data = d, trace = FALSE)
  l <- nlme::lme(distance ~ age * Sex, random = ~ 1 | Subject,
                 weights = nlme::varIdent(form = ~ 1 | Sex), data = d)
  expect_equal(f$loglik, as.numeric(logLik(l)), tolerance = 1e-6)
})

test_that("AR1 residuals agree with nlme::gls", {
  skip_if_not_installed("nlme")
  d <- as.data.frame(nlme::Orthodont); d$Subject <- factor(as.character(d$Subject))
  f <- mlreml(distance ~ age * Sex, residual = ~ ar1(age):id(Subject), data = d, trace = FALSE)
  g <- nlme::gls(distance ~ age * Sex, correlation = nlme::corExp(form = ~ age | Subject), data = d)
  expect_equal(f$loglik, as.numeric(logLik(g)), tolerance = 1e-6)
})

test_that("GBLUP: general engine equals spectral gblup()", {
  set.seed(1)
  M <- matrix(rbinom(150 * 300, 2, 0.3), 150); rownames(M) <- paste0("i", 1:150)
  G <- Gmatrix(M) + diag(1e-3, 150)
  g <- drop(M %*% rnorm(300, 0, 0.1)); y <- g + rnorm(150)
  names(y) <- rownames(M)
  d <- data.frame(id = names(y), y = y)
  f <- mlreml(y ~ 1, random = ~ vm(id, G), data = d, trace = FALSE)
  s <- gblup(y, G)
  expect_equal(f$loglik, s$loglik, tolerance = 1e-5)
  expect_equal(unname(f$theta), unname(s$varcomp[1:2]), tolerance = 1e-3)
})

test_that("pedigree tools are consistent", {
  ped <- data.frame(id = c("A3", "A4", "A5", "A6"), sire = c("A1", "A1", "A3", "A3"),
                    dam = c("A2", "A2", "A4", "0"))
  pp <- pedigree_prepare(ped)
  A <- Amatrix(pp)
  expect_equal(unname(diag(A)) - 1, unname(inbreeding_coef(pp)))
  expect_equal(unname(as.matrix(Ainverse(pp)) %*% A), diag(nrow(A)), tolerance = 1e-10)
  expect_equal(A["A5", "A5"], 1.25)
})

test_that("predicted means and SED agree with lme4", {
  skip_if_not_installed("lme4"); skip_if_not_installed("agridat")
  d <- agridat::john.alpha
  f <- mlreml(yield ~ rep + gen, random = ~ rep:block, data = d, trace = FALSE)
  pr <- predict(f, "gen")
  l <- lme4::lmer(yield ~ 0 + gen + rep + (1 | rep:block), data = d)
  V <- as.matrix(vcov(l))[1:24, 1:24]
  sedl <- sqrt(outer(diag(V), diag(V), "+") - 2 * V)
  expect_equal(pr$avsed, mean(sedl[upper.tri(sedl)]), tolerance = 1e-4)
})

test_that("score is zero at the AR1 x AR1 optimum (numerical check)", {
  set.seed(4)
  d <- expand.grid(row = 1:12, col = 1:8)
  d$gen <- factor(sample(rep(1:24, 4)))
  d$y <- rnorm(24)[d$gen] + rnorm(96)
  f <- mlreml(y ~ 1, random = ~ gen, residual = ~ ar1(row):ar1(col), data = d, trace = FALSE)
  ## perturbing any parameter must not increase the REML likelihood
  for (j in seq_along(f$theta)) {
    st <- f$theta; st[j] <- st[j] * 1.02
    g <- mlreml(y ~ 1, random = ~ gen, residual = ~ ar1(row):ar1(col), data = d,
                start = st, fix = names(st), maxit = 1, trace = FALSE, pev = FALSE)
    expect_lte(g$loglik, f$loglik + 1e-6)
  }
})
