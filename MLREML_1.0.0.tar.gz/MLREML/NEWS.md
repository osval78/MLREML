# MLREML 1.0.0

## Corrections

* The derivative of the exponential correlation structures (`expc`, `sexp`, and `ar1` with
  numeric levels) with respect to the correlation was computed as `d * rho^max(d - 1, 0)`, which is
  wrong for distances `0 < d < 1`. The score was wrong and the algorithm could stop at a point that
  is not the maximum of the REML likelihood. It is now `d * rho^(d - 1)` for every `d > 0`
  (validated against `nlme::gls()`).
* `wald()`: the conditional statistics adjusted every term for all the others, including the
  interactions that contain it, so that with treatment contrasts the main effect `A` of `y ~ A * B`
  was tested at the reference level of `B`. Conditional statistics now respect marginality, as in
  ASReml: each term is adjusted for the terms that do not contain it.
* AI iterations: when a variance reached its lower bound, the joint step was clipped, which could
  stall all the parameters at a non-stationary point and declare convergence. Parameters on the
  bound whose score (or step) points outside the parameter space are now held on the bound and
  removed from the AI system (active set).
* Bounds: the compound symmetry correlation is restricted to `rho > -1/(L - 1)` (positive
  definiteness), and autoregressive correlations are restricted to positive values when some
  distances are not integers.
* A warning is issued when the steps become negligible while the score is not zero (typically an
  unstructured matrix that converges to a singular one), instead of declaring convergence silently.
* The help page of the package referred to guides that were not installed; the guides are now
  `inst/doc/MLREML-guide-en.pdf` (version 1.0.0) and `inst/doc/MLREML-guide-es.pdf` (version 0.9.0).

## New features

* Correlated random effects of several factors sharing a relationship matrix, in particular the
  direct-maternal animal model: `random = ~ str(animal, dam, K = A, cov = "us")`. Missing values of
  the factors (unknown dams) mean "no effect" and do not remove records.
* Sparse engine: `mlreml(..., engine = "sparse")` (or `"auto"`, the default, for more than 5000
  records) estimates the parameters with the mixed model equations, the supernodal sparse Cholesky
  factorisation of CHOLMOD (package Matrix) and the sparse (Takahashi / selected) inverse computed in
  compiled code. It supports random terms built from `id`, `vm`, `diag`, `us` components and `str()`
  terms, and the residuals `units`, `diag(f):units` and `us(trait):units`. Relationship matrices can
  be given through their inverse (attribute `INVERSE = TRUE`, as returned by `Ainverse()`).
  `inst/scale/sparse_scale.R` measures its time and memory with simulated animal models.
* Kenward-Roger adjustment: `wald(fit, ddf = "KR")` (the default for fits of the dense engine
  stored with `store = TRUE`) gives F statistics with the adjusted covariance matrix of the fixed
  effects and Kenward-Roger denominator degrees of freedom for the incremental and the conditional
  tests; second derivatives of `V` are included for non-linear structures. Validated against
  `pbkrtest`.

## Other changes

* `inbreeding_coef()` is implemented in C++ (the R implementation had a cost proportional to the
  square of the number of animals).
* `Ainverse()` returns its result with the attributes `INVERSE = TRUE` and `Kinfo` (log-determinant
  and diagonal of A).
* The package contains compiled code (Rcpp) and links to BLAS/LAPACK.
* New tests in `tests/testthat/test-v1.R`.
