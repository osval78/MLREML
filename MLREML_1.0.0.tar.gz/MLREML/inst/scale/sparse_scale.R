## sparse_scale.R -- timing of the sparse engine of MLREML with simulated animal models
## (Section 15.2 of the user guide). Usage, from a shell:
##   Rscript sparse_scale.R 250000 a     # additive animal model with 250,000 animals
##   Rscript sparse_scale.R 100000 m     # direct-maternal model
##   Rscript sparse_scale.R 1000000 r    # repeated records of cows in herds (no pedigree)
## The memory needed grows with the number of non-zero elements of the Cholesky factor of the
## mixed model equations, which depends on the structure of the data (pedigree and contemporary groups).
library(MLREML)
## simulated dairy-type population: herds, overlapping generations, artificial-insemination
## sires used across herds, dams within herds; records on animals with parents;
## contemporary groups herd x year
sim_big <- function(N, s2a = 0.3, s2m = 0.1, cam = -0.05, s2e = 0.6, seed = 1) {
  set.seed(seed)
  ngen <- 10; nherd <- max(10, N %/% 200)
  nf <- max(400, N %/% 20); per <- (N - nf) %/% ngen
  sex <- rep(1:2, length.out = nf); herd <- sample(nherd, nf, TRUE); gen <- rep(0L, nf)
  sire_i <- rep(0L, nf); dam_i <- rep(0L, nf)
  for (g in 1:ngen) {
    cand <- which(gen >= g - 3 & gen < g)
    ms <- cand[sex[cand] == 1]; fs <- cand[sex[cand] == 2]
    ai <- sample(ms, max(20, length(ms) %/% 50))         # AI sires
    dd <- sample(fs, per, TRUE)
    sire_i <- c(sire_i, sample(ai, per, TRUE)); dam_i <- c(dam_i, dd)
    herd <- c(herd, herd[dd]); gen <- c(gen, rep(g, per)); sex <- c(sex, sample(1:2, per, TRUE))
  }
  n <- length(sex); id <- paste0("a", seq_len(n))
  ped <- data.frame(id = id, sire = ifelse(sire_i > 0, id[pmax(sire_i, 1)], NA),
                    dam = ifelse(dam_i > 0, id[pmax(dam_i, 1)], NA))
  ## direct and maternal breeding values by the recursion u_i = (u_s + u_d)/2 + mendelian
  pp <- pedigree_prepare(ped)
  Fv <- inbreeding_coef(pp)
  S <- matrix(c(s2a, cam, cam, s2m), 2); cS <- chol(S)
  s <- match(ped$sire, pp$id); d <- match(ped$dam, pp$id)
  o <- match(pp$id, ped$id)                      # pp order -> ped order
  U <- matrix(0, n, 2)
  Fp <- function(j) ifelse(is.na(j), -1, Fv[pmax(j, 1)])
  for (i in seq_len(n)) {
    r <- o[i]
    si <- s[r]; di <- d[r]
    b <- 0.5 - 0.25 * (Fp(si) + Fp(di))
    us <- if (is.na(si)) c(0, 0) else U[si, ]; ud <- if (is.na(di)) c(0, 0) else U[di, ]
    U[i, ] <- (us + ud) / 2 + sqrt(b) * drop(rnorm(2) %*% cS)
  }
  rownames(U) <- pp$id
  rec <- which(!is.na(ped$sire))
  dat <- data.frame(id = ped$id[rec], dam = ped$dam[rec], herd = herd[rec], year = gen[rec])
  dat$hy <- factor(paste(dat$herd, dat$year, sep = "_"))
  dat$y <- rnorm(nlevels(dat$hy))[dat$hy] + U[dat$id, 1] + U[dat$dam, 2] + rnorm(nrow(dat), sd = sqrt(s2e))
  list(data = dat, ped = pp, U = U)
}
args <- commandArgs(TRUE)
N <- if (length(args) >= 1) as.integer(args[1]) else 100000
model <- if (length(args) >= 2) args[2] else "a"
if (model == "r") {
  ## repeated records: four records per cow, cows nested in herds, year as fixed effect
  set.seed(1)
  ncow <- N %/% 4; nherd <- max(100, ncow %/% 50)
  cow <- sample(ncow, N, TRUE); herd <- ((cow - 1) %% nherd) + 1; year <- sample(10, N, TRUE)
  d <- data.frame(cow = factor(cow), herd = factor(herd), year = factor(year))
  d$y <- rnorm(10)[year] + rnorm(nherd, sd = sqrt(2))[herd] + rnorm(ncow, sd = 1)[cow] +
    rnorm(N, sd = sqrt(3))
  t0 <- proc.time()[3]
  f <- mlreml(y ~ year, random = ~ herd + cow, data = d, engine = "sparse", trace = FALSE)
  print(summary(f)$varcomp[, 1:2])
  cat("fit time", round(proc.time()[3] - t0, 1), "s; iterations", f$iterations, "; equations",
      f$sparse$N, "; elements of the factor", f$sparse$nnzL, "\n")
  quit(save = "no")
}
t0 <- proc.time()[3]; s <- sim_big(N); t1 <- proc.time()[3]
d <- s$data; Ai <- Ainverse(s$ped)
cat("animals", nrow(s$ped), " records", nrow(d), " contemporary groups", nlevels(d$hy),
    " simulation", round(t1 - t0, 1), "s\n")
t3 <- proc.time()[3]
f <- if (model == "m") mlreml(y ~ hy, random = ~ str(id, dam, K = Ai), data = d, engine = "sparse") else
  mlreml(y ~ hy, random = ~ vm(id, Ai), data = d, engine = "sparse")
t4 <- proc.time()[3]
print(summary(f)$varcomp[, 1:3])
cat("fit time", round(t4 - t3, 1), "s; iterations", f$iterations, "; equations", f$sparse$N,
    "; non-zeros of the factor", f$sparse$nnzL, "\n")
b <- f$blups[[1]]; bd <- b[if (model == "m") b$effect == "id" else TRUE, ]
cat("correlation between EBV and true breeding value", cor(bd$blup, s$U[bd$level, 1]), "\n")
st <- "/proc/self/status"
if (file.exists(st)) cat("peak memory (MB)", as.numeric(sub(".*:\\s+([0-9]+) kB", "\\1",
                         grep("VmHWM", readLines(st), value = TRUE))) / 1024, "\n")
