## ---------------------------------------------------------------------------
## Sparse engine: AI-REML on Henderson's mixed model equations (MME)
##
##   C = T' R^-1 T + blockdiag(0, G^-1),  T = [X Z],  C s = T' R^-1 y
##   logL = -0.5 [ (n - p) log(2 pi) + log|R| + log|G| + log|C| + y'Py ],
##   y'Py = y'R^-1 y - s' T'R^-1 y
##   dlogL/dtheta = -0.5 [ tr(R^-1 dR) + tr(G^-1 dG) + tr(C^-1 dC)
##                         + e' d(R^-1) e + u' d(G^-1) u ]
## The traces tr(C^-1 dC) use the elements of C^-1 on the pattern of the Cholesky
## factor (Takahashi selected inverse, src/sparse_tools.cpp). The AI matrix uses the
## working variates w = dV P y: Z dG G^-1 u for G parameters and dR R^-1 e for R
## parameters, with AI_ij = 0.5 (w_i'R^-1 w_j - t_i'C^-1 t_j), t = T'R^-1 w.
## ---------------------------------------------------------------------------

## NULL if the sparse engine supports the model, otherwise the reason
.sparse_supported <- function(rlabs, rlab, multi) {
  okcomp <- function(p) {
    if (is.name(p)) return(TRUE)
    if (!is.call(p)) return(FALSE)
    fn <- as.character(p[[1]])
    fn %in% c("id", "vm", "diag", "us", "pol", "leg", "mm")
  }
  for (l in rlabs) {
    if (.is_str_label(l)) next
    parts <- .split_colon(str2lang(l))
    for (p in parts) if (!okcomp(p))
      return(paste0("structure '", paste(deparse(p), collapse = ""), "' in random term '", l, "'"))
  }
  parts <- .split_colon(str2lang(rlab))
  isu <- vapply(parts, function(p) identical(p, as.name("units")) ||
                  (is.call(p) && identical(p[[1]], as.name("id")) && identical(p[[2]], as.name("units"))),
                logical(1))
  if (sum(isu) != 1 || length(parts) > 2)
    return(paste0("residual '", rlab, "'; supported: units, diag(f):units, us(trait):units"))
  if (length(parts) == 2) {
    o <- parts[[which(!isu)]]
    fn <- if (is.call(o)) as.character(o[[1]]) else ""
    if (fn == "diag" && is.name(o[[2]])) return(NULL)
    if (fn == "us" && multi && identical(o[[2]], as.name("trait"))) return(NULL)
    return(paste0("residual '", rlab, "'; supported: units, diag(f):units, us(trait):units"))
  }
  NULL
}

## inverse, log-determinant and diagonal of a relationship matrix (or identity)
.sp_Kinfo <- function(K, L) {
  if (is.null(K)) return(list(Finv = .sp_gen(Matrix::Diagonal(L)), logdet = 0, diag = rep(1, L)))
  if (isTRUE(attr(K, "INVERSE"))) {
    Ki <- Matrix::forceSymmetric(Matrix::Matrix(K, sparse = TRUE))
    ## Ainverse() stores log|A| and diag(A) = 1 + F; they are used if they belong to this matrix
    ki <- attr(K, "Kinfo")
    if (is.list(ki) && identical(ki$n, nrow(Ki)) && isTRUE(all.equal(ki$sumx, sum(Ki@x))))
      return(list(Finv = .sp_gen(Ki), logdet = ki$logdet, diag = ki$diag))
    sel <- .sp_selinv(Ki)
    return(list(Finv = .sp_gen(Ki), logdet = -sel$logdet, diag = sel$diag()))
  }
  Kd <- as.matrix(K)
  ch <- tryCatch(chol(Kd), error = function(e)
    stop("the relationship matrix is not positive definite; use bend() or give its inverse"))
  Ki <- chol2inv(ch)
  list(Finv = .sp_gen(Matrix::Matrix(Ki, sparse = TRUE)), logdet = 2 * sum(log(diag(ch))),
       diag = diag(Kd))
}

## general (both triangles stored) sparse matrix without dimnames
.sp_gen <- function(A) {
  A <- methods::as(methods::as(A, "CsparseMatrix"), "generalMatrix")
  if (!methods::is(A, "dgCMatrix")) A <- methods::as(A, "dMatrix")
  A@Dimnames <- list(NULL, NULL)
  A
}

## sparse Cholesky factor (supernodal, CHOLMOD) of a symmetric positive definite matrix and its
## selected inverse, computed in the supernodal layout of the factor (no conversion of the factor)
.sp_selinv <- function(C, factor = NULL, inplace = FALSE) {
  Lf <- if (is.null(factor)) Matrix::Cholesky(C, perm = TRUE, LDL = FALSE, super = TRUE) else
    Matrix::update(factor, C)
  factor <- NULL
  if (!methods::is(Lf, "dCHMsuper")) stop("internal error: a supernodal factor was expected")
  N <- Lf@Dim[1]
  pinv <- integer(N); pinv[Lf@perm + 1L] <- seq_len(N) - 1L
  sup <- Lf@super; spi <- Lf@pi; spx <- Lf@px; ss <- Lf@s
  col2sup <- rep.int(seq_len(length(sup) - 1L) - 1L, diff(sup))
  ld <- super_logdet_cpp(sup, spi, spx, Lf@x)
  Zx <- NULL
  ## inplace = TRUE: the values of the factor are replaced by those of the sparse inverse; the factor
  ## can then only be used as the symbolic template of the next update() (no solves)
  getZ <- function() {
    if (is.null(Zx)) Zx <<- takahashi_super_cpp(sup, spi, spx, ss, Lf@x, inplace)
    Zx
  }
  list(factor = Lf, pinv = pinv, logdet = ld, nnz = length(Lf@x), Zx = getZ,
       diag = function() super_lookup_cpp(sup, spi, spx, ss, getZ(), col2sup, pinv, pinv),
       lookup = function(r, c) super_lookup_cpp(sup, spi, spx, ss, getZ(), col2sup, pinv[r], pinv[c]),
       trace = function(B, offset = 0L) super_trace_cpp(sup, spi, spx, ss, getZ(), col2sup, pinv,
                                                        B@p, B@i, B@x, as.integer(offset)))
}

## multiply mode 2 of u (array La x Lc x Lb, first index fastest) by M (Lc x Lc)
.mode_mult <- function(u, M, La, Lc, Lb) {
  if (Lc == 1) return(u * M[1, 1])
  A <- aperm(array(u, c(La, Lc, Lb)), c(2, 1, 3))
  B <- M %*% matrix(A, Lc)
  as.vector(aperm(array(B, c(Lc, La, Lb)), c(2, 1, 3)))
}

## random term: Z, the fixed Kronecker factors before (Fb) and after (Fa) the
## parameterised component, and the functions of its parameters
.sp_term_setup <- function(tk) {
  if (identical(tk$kind, "str")) {
    Z <- do.call(cbind, tk$Zs)
    pc <- tk$comps[[1]]
    Kf <- .sp_Kinfo(tk$K, length(tk$levels))
    fb <- list(); fa <- list(list(Finv = Kf$Finv, logdet = Kf$logdet, diag = Kf$diag, L = length(tk$levels)))
    Lc <- pc$L
    Sig <- function(th) .comp_Sigma(pc, th)
    dSig <- function(th, j) .comp_dSigma(pc, th, j)
    levels <- paste(rep(tk$names, each = length(tk$levels)), tk$levels, sep = ":")
  } else {
    zt <- .term_Z(tk)
    Z <- methods::as(zt$Z, "CsparseMatrix")
    levels <- zt$levels
    pci <- which(vapply(tk$comps, function(cc) cc$npar > 0, logical(1)))
    fixed_info <- lapply(tk$comps, function(cc) {
      if (cc$npar > 0) return(NULL)
      if (cc$struct == "vm") { k <- .sp_Kinfo(cc$K, cc$L); k$L <- cc$L; return(k) }
      list(Finv = .sp_gen(Matrix::Diagonal(cc$L)), logdet = 0, diag = rep(1, cc$L), L = cc$L)
    })
    if (length(pci) == 0) {
      ## scale term: G = s2 * (F1 %x% F2 %x% ...)
      fb <- fixed_info; fa <- list()
      Lc <- 1
      Sig <- function(th) matrix(th[1], 1, 1)
      dSig <- function(th, j) matrix(1, 1, 1)
    } else {
      pc <- tk$comps[[pci]]
      fb <- fixed_info[seq_len(pci - 1)]
      fa <- if (pci < length(tk$comps)) fixed_info[(pci + 1):length(tk$comps)] else list()
      Lc <- pc$L
      Sig <- function(th) .comp_Sigma(pc, th)
      dSig <- function(th, j) .comp_dSigma(pc, th, j)
    }
  }
  kr <- function(lst) {
    if (!length(lst)) return(list(F = .sp_gen(Matrix::Diagonal(1)), L = 1, logdet = 0, diag = 1))
    F <- lst[[1]]$Finv; L <- lst[[1]]$L; ld <- lst[[1]]$logdet; dg <- lst[[1]]$diag
    if (length(lst) > 1) for (f in lst[-1]) {
      ## log|A %x% B| = L_B log|A| + L_A log|B|
      ld <- f$L * ld + L * f$logdet
      F <- .sp_gen(Matrix::kronecker(F, f$Finv)); dg <- kronecker(dg, f$diag); L <- L * f$L
    }
    list(F = F, L = L, logdet = ld, diag = dg)
  }
  B <- kr(fb); A <- kr(fa)
  q <- B$L * Lc * A$L
  if (q != ncol(Z)) stop("internal error: dimension of the term '", tk$label, "'")
  ones <- Matrix::Matrix(1, Lc, Lc, sparse = TRUE)
  pat <- .sp_gen(Matrix::kronecker(B$F, Matrix::kronecker(ones, A$F)))
  pat@x[] <- 1
  list(Z = Z, levels = levels, q = q, Lb = B$L, La = A$L, Lc = Lc, Fb = B$F, Fa = A$F,
       ## log|Kb %x% Sigma %x% Ka| = Lc La log|Kb| + Lb La log|Sigma| + Lb Lc log|Ka|
       logdetF = Lc * (A$L * B$logdet + B$L * A$logdet), Lfix = B$L * A$L,
       diagF_b = B$diag, diagF_a = A$diag, Sig = Sig, dSig = dSig, pattern = pat,
       is_str = identical(tk$kind, "str"), names = tk$names, Klevels = tk$levels)
}

## G^-1 of a term at parameters th
.sp_Ginv <- function(ts, Si) {
  .sp_gen(Matrix::kronecker(ts$Fb, Matrix::kronecker(Matrix::Matrix(Si, sparse = TRUE), ts$Fa)))
}

## residual: records (blocks of R), observed-level patterns and their row indices
.sp_resid_setup <- function(rterm, data, n) {
  vc <- which(vapply(rterm$comps, function(cc) cc$npar > 0, logical(1)))
  if (length(vc) == 0) {
    Lr <- 1; lev <- rep(1L, n); rec <- seq_len(n)
    Sig <- function(th) matrix(th[1], 1, 1)
    dSig <- function(th, j) matrix(1, 1, 1)
  } else {
    cc <- rterm$comps[[vc]]
    Lr <- cc$L; lev <- cc$idx
    rec <- if (cc$struct == "us") match(data$.units, unique(data$.units)) else seq_len(n)
    Sig <- function(th) .comp_Sigma(cc, th)
    dSig <- function(th, j) .comp_dSigma(cc, th, j)
  }
  if (Lr > 30 && length(vc) && rterm$comps[[vc]]$struct == "us")
    stop("us(trait):units with more than 30 traits is not supported by the sparse engine")
  ## rows of each record are consecutive and ordered by level (data sorted by record, trait)
  first <- which(!duplicated(rec))
  nrec <- length(first)
  if (nrec == n) {
    key <- lev
    pats <- lapply(sort(unique(lev)), function(l) list(levs = l, rows = matrix(which(lev == l), ncol = 1)))
  } else {
    if (is.unsorted(rec)) stop("internal error: records are not sorted")
    code <- rowsum(2^(lev - 1), rec, reorder = FALSE)[, 1]
    pats <- lapply(sort(unique(code)), function(cd) {
      levs <- which(bitwAnd(as.integer(cd), bitwShiftL(1L, seq_len(Lr) - 1L)) > 0)
      r <- which(code == cd)
      rows <- outer(first[r], seq_along(levs) - 1L, "+")
      list(levs = levs, rows = matrix(rows, ncol = length(levs)))
    })
  }
  list(Lr = Lr, Sig = Sig, dSig = dSig, pats = pats, n = n)
}

## R^-1 v (or dR v): per pattern, v_o %*% M_o
.sp_Rapply <- function(rs, Ms, v) {
  out <- numeric(length(v))
  for (o in seq_along(rs$pats)) {
    rw <- rs$pats[[o]]$rows
    out[rw] <- matrix(v[rw], ncol = ncol(rw)) %*% Ms[[o]]
  }
  out
}

## the sparse engine
.mlreml_sparse <- function(cl, fixed, random, residual, data, y, rhs, rlabs, rlab, env, multi,
                           traits, yname, start, fix, maxit, tol, pev, trace, store) {
  n <- length(y)
  ## fixed effects (sparse model matrix, aliased columns removed)
  mf <- stats::model.frame(rhs, data, drop.unused.levels = TRUE)
  X0 <- Matrix::sparse.model.matrix(rhs, mf)
  asg0 <- attr(X0, "assign")
  if (ncol(X0) <= 3000) {
    XtX <- as.matrix(Matrix::crossprod(X0))
    sc <- sqrt(pmax(diag(XtX), 1e-300))
    qx <- qr(XtX / outer(sc, sc), tol = 1e-9)
    keepX <- sort(qx$pivot[seq_len(qx$rank)])
  } else {
    sq <- Matrix::qr(X0)
    d <- abs(Matrix::diag(sq@R))
    dep <- sq@q[which(d < 1e-9 * max(d))] + 1L
    keepX <- setdiff(seq_len(ncol(X0)), dep)
  }
  X <- X0[, keepX, drop = FALSE]
  cn <- colnames(X)
  assign <- asg0[keepX]
  xlev <- stats::.getXlevels(stats::terms(mf), mf)
  p <- ncol(X)

  ## terms
  terms <- lapply(rlabs, .make_term, data = data, env = env, nobs = n, dense = FALSE)
  rterm <- .make_term(rlab, data, env, n, is_resid = TRUE, dense = FALSE)
  allterms <- c(terms, list(rterm))
  nt <- length(terms)
  if (trace) message("Sparse engine: setting up the mixed model equations")
  ts <- lapply(terms, .sp_term_setup)
  rs <- .sp_resid_setup(rterm, data, n)
  T <- methods::as(do.call(cbind, c(list(X), lapply(ts, function(t) t$Z))), "CsparseMatrix")
  T@Dimnames <- list(NULL, NULL)
  N <- ncol(T)
  off <- p + c(0, cumsum(vapply(ts, function(t) t$q, 0)))   # offset of each term in C

  ## T' E_ab T for every pattern and pair of levels
  Bm <- list()
  for (o in seq_along(rs$pats)) {
    rw <- rs$pats[[o]]$rows; k <- ncol(rw)
    Ta <- lapply(seq_len(k), function(a) T[rw[, a], , drop = FALSE])
    for (a in seq_len(k)) for (b in seq_len(a)) {
      B <- if (a == b) Matrix::crossprod(Ta[[a]]) else {
        M <- Matrix::crossprod(Ta[[a]], Ta[[b]]); M + Matrix::t(M) }
      Bm[[length(Bm) + 1]] <- list(o = o, a = a, b = b, B = .sp_gen(B))
    }
  }
  ## fixed pattern of C (union of all possible non-zeros, values 0)
  pat <- Reduce(`+`, lapply(Bm, function(z) { B <- z$B; B@x[] <- 1; B }))
  if (nt) pat <- pat + .sp_gen(Matrix::bdiag(c(list(Matrix::Matrix(0, p, p, sparse = TRUE)),
                                               lapply(ts, function(t) t$pattern))))
  pat <- .sp_gen(pat); pat@x[] <- 0

  ## starting values from the least-squares residuals
  XtXs <- Matrix::crossprod(X)
  b0 <- as.vector(Matrix::solve(XtXs, Matrix::crossprod(X, y)))
  r0 <- y - as.vector(X %*% b0)
  init <- .start_values(allterms, y, X, data, r = r0)
  pp <- .setup_params(init, start, fix)
  theta <- pp$theta; info <- pp$info; free <- pp$free
  ptid <- info$termid

  factor <- NULL
  ev <- function(theta, deriv = TRUE, keep = FALSE) {
    ## residual
    thR <- theta[ptid == nt + 1]
    SR <- rs$Sig(thR)
    Si <- lapply(rs$pats, function(pt) {
      S <- SR[pt$levs, pt$levs, drop = FALSE]
      cs <- chol(S)
      list(Si = chol2inv(cs), ld = 2 * sum(log(diag(cs))), n = nrow(pt$rows))
    })
    ldR <- sum(vapply(Si, function(z) z$n * z$ld, 0))
    TRT <- Reduce(`+`, lapply(Bm, function(z) Si[[z$o]]$Si[z$a, z$b] * z$B))
    ## random terms
    Gi <- vector("list", nt); SG <- vector("list", nt); SGi <- vector("list", nt); ldG <- 0
    for (k in seq_len(nt)) {
      t <- ts[[k]]
      SG[[k]] <- t$Sig(theta[ptid == k])
      cs <- chol(SG[[k]])
      SGi[[k]] <- chol2inv(cs)
      Gi[[k]] <- .sp_Ginv(t, SGi[[k]])
      ldG <- ldG + t$logdetF + t$Lfix * 2 * sum(log(diag(cs)))
    }
    C <- TRT + pat
    if (nt) C <- C + .sp_gen(Matrix::bdiag(c(list(Matrix::Matrix(0, p, p, sparse = TRUE)), Gi)))
    C <- Matrix::forceSymmetric(C, "U")
    ## the values of the factor are overwritten by the sparse inverse during the iterations
    ## (solves are done before); the factor of the final evaluation is kept
    sel <- .sp_selinv(C, factor, inplace = deriv && !keep)
    rm(C)
    factor <<- sel$factor
    Riy <- .sp_Rapply(rs, lapply(Si, `[[`, "Si"), y)
    rhsv <- as.vector(Matrix::crossprod(T, Riy))
    sol <- as.vector(Matrix::solve(sel$factor, rhsv, system = "A"))
    yPy <- sum(y * Riy) - sum(sol * rhsv)
    ll <- -0.5 * ((n - p) * log(2 * pi) + ldR + ldG + sel$logdet + yPy)
    if (!deriv) return(list(loglik = ll))
    ehat <- y - as.vector(T %*% sol)
    Rie <- .sp_Rapply(rs, lapply(Si, `[[`, "Si"), ehat)
    u <- lapply(seq_len(nt), function(k) sol[off[k] + seq_len(ts[[k]]$q)])
    Giu <- lapply(seq_len(nt), function(k) as.vector(Gi[[k]] %*% u[[k]]))
    fi <- which(free)
    m <- length(fi)
    ## working variates and the parts of the score that do not need C^-1
    W <- matrix(0, n, m); part <- numeric(m); spec <- vector("list", m)
    for (a in seq_len(m)) {
      i <- fi[a]; k <- ptid[i]
      loc <- match(i, which(ptid == k))
      if (k == nt + 1) {
        dS <- rs$dSig(thR, loc)
        Ds <- lapply(rs$pats, function(pt) dS[pt$levs, pt$levs, drop = FALSE])
        trR <- 0
        Q <- vector("list", length(rs$pats))
        for (o in seq_along(rs$pats)) {
          trR <- trR + Si[[o]]$n * sum(Si[[o]]$Si * Ds[[o]])
          Q[[o]] <- -Si[[o]]$Si %*% Ds[[o]] %*% Si[[o]]$Si
        }
        w <- .sp_Rapply(rs, Ds, Rie)                # dR R^-1 e
        quad <- -sum(Rie * w)                       # e' d(R^-1) e
        part[a] <- trR + quad
        spec[[a]] <- list(type = "R", Q = Q)
      } else {
        t <- ts[[k]]
        thk <- theta[ptid == k]
        dS <- t$dSig(thk, loc)
        M1 <- dS %*% SGi[[k]]                        # dSigma Sigma^-1
        trG <- t$Lfix * sum(diag(M1))                # tr(G^-1 dG)
        dSi <- -SGi[[k]] %*% M1                      # d(Sigma^-1)
        v <- .mode_mult(u[[k]], M1, t$La, t$Lc, t$Lb)   # dG G^-1 u
        w <- as.vector(t$Z %*% v)
        quad <- -sum(Giu[[k]] * v)                  # u' d(G^-1) u
        part[a] <- trG + quad
        spec[[a]] <- list(type = "G", k = k, dSi = dSi)
      }
      W[, a] <- w
    }
    ## average information (solves with the factor, before the sparse inverse overwrites it)
    AI <- matrix(0, m, m)
    if (m) {
      RiW <- apply(W, 2, function(w) .sp_Rapply(rs, lapply(Si, `[[`, "Si"), w))
      RiW <- matrix(RiW, n, m)
      tt <- as.matrix(Matrix::crossprod(T, RiW))
      st <- as.matrix(Matrix::solve(sel$factor, tt, system = "A"))
      AI <- 0.5 * (crossprod(W, RiW) - crossprod(tt, st))
      AI <- (AI + t(AI)) / 2
    }
    ## traces tr(C^-1 dC) with the sparse inverse
    trB <- if (any(vapply(spec, function(z) z$type == "R", TRUE))) vapply(Bm, function(z) sel$trace(z$B), 0) else NULL
    score <- numeric(m)
    for (a in seq_len(m)) {
      z <- spec[[a]]
      if (z$type == "R") {
        trC <- 0
        for (zz in seq_along(Bm)) {
          b <- Bm[[zz]]
          if (z$Q[[b$o]][b$a, b$b] != 0) trC <- trC + z$Q[[b$o]][b$a, b$b] * trB[zz]
        }
      } else {
        trC <- sel$trace(.sp_Ginv(ts[[z$k]], z$dSi), off[z$k])
      }
      score[a] <- -0.5 * (part[a] + trC)
    }
    out <- list(loglik = ll, score = score, AI = AI)
    if (keep) out <- c(out, list(sel = sel, sol = sol, u = u, SG = SG, ehat = ehat))
    out
  }

  t0 <- proc.time()[3]
  evalfun <- function(theta, deriv) ev(theta, deriv)
  it <- .ai_iterate(evalfun, allterms, info, theta, free, maxit, tol, trace)
  theta <- it$theta
  fin <- ev(theta, TRUE, keep = TRUE)
  vt <- .varcomp_table(fin$AI, theta, info, free)
  sel <- fin$sel
  beta <- fin$sol[seq_len(p)]
  names(beta) <- cn
  ## covariance matrix of beta: block of C^-1 of the fixed effects. With more than
  ## getOption("MLREML.sparse_vcov", 1000) fixed effects only its diagonal (from the sparse
  ## inverse) is stored, as a diagonal matrix; wald() computes the complete block when needed
  if (p <= getOption("MLREML.sparse_vcov", 1000)) {
    ij <- expand.grid(r = seq_len(p), c = seq_len(p))
    vb <- matrix(sel$lookup(ij$r, ij$c), p, p)
    if (anyNA(vb)) vb <- .sp_vcov_fixed(sel$factor, N, p)
  } else {
    vb <- Matrix::Diagonal(x = sel$lookup(seq_len(p), seq_len(p)))
  }
  dimnames(vb) <- list(cn, cn)
  ## BLUPs, prediction error variances and reliabilities
  blups <- list()
  fitted_r <- as.vector(X %*% beta)
  dC <- if (pev) sel$diag() else NULL
  for (k in seq_len(nt)) {
    t <- ts[[k]]
    u <- fin$u[[k]]
    dG <- kronecker(t$diagF_b, kronecker(diag(fin$SG[[k]]), t$diagF_a))
    if (t$is_str) {
      ql <- length(t$Klevels)
      out <- data.frame(effect = rep(t$names, each = ql), level = rep(t$Klevels, t$Lc),
                        blup = u, stringsAsFactors = FALSE)
    } else out <- data.frame(level = t$levels, blup = u, stringsAsFactors = FALSE)
    if (pev) {
      pv <- dC[off[k] + seq_len(t$q)]
      out$pev <- pmax(pv, 0)
      out$se <- sqrt(out$pev)
      out$reliability <- ifelse(dG > 0, 1 - out$pev / dG, NA)
    }
    blups[[terms[[k]]$label]] <- out
    fitted_r <- fitted_r + as.vector(t$Z %*% u)
  }
  npar <- sum(free)
  ll <- fin$loglik
  if (trace) message(sprintf("Sparse engine: %d equations, %d non-zeros in the Cholesky factor, %.1f s",
                             N, sel$nnz, proc.time()[3] - t0))
  res <- list(call = cl, fixed = fixed, random = random, residual = residual,
              loglik = ll, AIC = -2 * ll + 2 * npar, BIC = -2 * ll + log(n - p) * npar,
              varcomp = vt$varcomp, theta = theta, vcov_theta = vt$vcov_theta, AI = fin$AI,
              free = free, info = info, beta = beta, vcov_beta = vb, blups = blups,
              fitted = fitted_r, residuals = y - fitted_r,
              fixed_fitted = as.vector(X %*% beta), y = y, n = n, p = p, X = X,
              assign = assign, xlev = xlev, terms_fixed = stats::terms(mf),
              terms = terms, rterm = rterm, converged = it$converged,
              iterations = nrow(it$history), history = it$history, multi = multi,
              traits = traits, data = data, yname = yname, engine = "sparse",
              sparse = list(N = N, nnzL = sel$nnz, offsets = off))
  if (store) res$sparse$factor <- sel$factor
  class(res) <- "mlreml"
  res
}

## block of C^-1 of the fixed effects: with C = P'LL'P, C^-1_FF = B'B with B = L^-1 P E_F,
## obtained by sparse forward substitution
.sp_vcov_fixed <- function(factor, N, p) {
  E <- Matrix::sparseMatrix(i = seq_len(p), j = seq_len(p), x = 1, dims = c(N, p))
  B <- Matrix::solve(factor, Matrix::solve(factor, E, system = "P"), system = "L")
  as.matrix(Matrix::crossprod(B))
}
