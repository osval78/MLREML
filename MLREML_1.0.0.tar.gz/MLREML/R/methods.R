#' Print and summary methods for mlreml fits
#'
#' @param object,x an object of class \code{"mlreml"}.
#' @param ... further arguments (ignored).
#' @return \code{summary} returns a list with the variance components
#'   (\code{varcomp}), the fixed effects with standard errors (\code{coef.fixed}),
#'   the log-likelihood and information criteria.
#' @export
summary.mlreml <- function(object, ...) {
  se <- sqrt(.vb_diag(object$vcov_beta))
  cf <- data.frame(estimate = object$beta, std.error = se, z.ratio = object$beta / se)
  vc <- object$varcomp[, c("estimate", "std.error", "z.ratio", "bound")]
  out <- list(call = object$call, varcomp = vc, coef.fixed = cf, loglik = object$loglik,
              AIC = object$AIC, BIC = object$BIC, n = object$n, p = object$p,
              converged = object$converged, iterations = object$iterations,
              engine = if (is.null(object$engine)) "dense" else object$engine)
  class(out) <- "summary.mlreml"
  out
}

#' @rdname summary.mlreml
#' @export
print.summary.mlreml <- function(x, ...) {
  cat(if (identical(x$engine, "sparse")) "MLREML fit (AI-REML, sparse engine)\n" else "MLREML fit (AI-REML)\n")
  cat("Observations:", x$n, "  Fixed-effect columns:", x$p,
      "  Iterations:", x$iterations, if (x$converged) "(converged)" else "(NOT converged)", "\n")
  cat(sprintf("REML log-likelihood: %.4f   AIC: %.2f   BIC: %.2f\n\n", x$loglik, x$AIC, x$BIC))
  cat("Variance parameters:\n")
  vc <- x$varcomp
  vc$estimate <- signif(vc$estimate, 5); vc$std.error <- signif(vc$std.error, 4)
  vc$z.ratio <- round(vc$z.ratio, 2)
  print(vc)
  cat("\nBound codes: P positive/free, B at boundary, F fixed.\n")
  invisible(x)
}

#' @rdname summary.mlreml
#' @export
print.mlreml <- function(x, ...) {
  print(summary(x))
  invisible(x)
}

#' Extract fixed and random effects
#'
#' @param object an \code{"mlreml"} fit.
#' @param type \code{"fixed"} or \code{"random"}.
#' @param term for random effects, the label of a random term (as in
#'   \code{names(object$blups)}); \code{NULL} returns all terms.
#' @param ... ignored.
#' @return A named vector (fixed effects) or a data frame (BLUPs with
#'   prediction error variance, standard error and reliability).
#' @export
coef.mlreml <- function(object, type = c("fixed", "random"), term = NULL, ...) {
  type <- match.arg(type)
  if (type == "fixed") return(object$beta)
  if (is.null(term)) return(object$blups)
  object$blups[[term]]
}

#' @rdname coef.mlreml
#' @export
ranef_mlreml <- function(object, term = NULL) coef.mlreml(object, "random", term)

#' @rdname coef.mlreml
#' @export
fixef_mlreml <- function(object) object$beta

#' @rdname summary.mlreml
#' @export
fitted.mlreml <- function(object, ...) object$fitted

#' @rdname summary.mlreml
#' @export
residuals.mlreml <- function(object, ...) object$residuals

#' @rdname summary.mlreml
#' @export
vcov.mlreml <- function(object, ...) object$vcov_beta

#' @rdname summary.mlreml
#' @export
logLik.mlreml <- function(object, ...) {
  structure(object$loglik, df = sum(object$free), nobs = object$n - object$p,
            class = "logLik")
}

#' Wald tests for fixed effects
#'
#' Computes incremental and conditional Wald statistics for every term of the
#' fixed formula, with F tests whose denominator degrees of freedom are
#' obtained by the method of Kenward and Roger (1997) or, as a large-sample
#' approximation, by the residual degrees of freedom \eqn{n - rank(X)}.
#'
#' The incremental statistic of a term tests it adjusted for the terms that
#' precede it in the fixed formula (sequential, "type I" tests). The
#' conditional statistic tests a term adjusted for all other terms that do not
#' contain it, respecting the principle of marginality as ASReml does
#' (equivalent to "type II" tests): the main effect \code{A} in
#' \code{y ~ A * B} is adjusted for \code{B} but not for \code{A:B}. Both
#' statistics are computed from the Cholesky factor of the inverse of the
#' covariance matrix of the fixed effects, with the columns reordered for the
#' conditional statistic (the term after the terms that do not contain it and
#' before the terms that contain it).
#'
#' With the Kenward-Roger method, the statistic of each hypothesis
#' \eqn{L\beta = 0} is \eqn{F = \lambda (L\hat\beta)'(L\Phi_A L')^{-1}
#' (L\hat\beta)/q}, where \eqn{\Phi_A} is the covariance matrix of the fixed
#' effects adjusted for the uncertainty of the estimated variance parameters,
#' and the denominator degrees of freedom \eqn{m} and the scale \eqn{\lambda}
#' are obtained by matching the moments of \eqn{F} with those of an
#' \eqn{F(q, m)} distribution. The expected information matrix is used; the
#' second derivatives of \eqn{V} are included for structures that are not linear in
#' their parameters (\code{ar1}, \code{expc}, \code{sexp}, \code{fa}, products of
#' parameterised components). Variance parameters that are fixed or on the
#' boundary of the parameter space are treated as known.
#'
#' @param object an \code{"mlreml"} fit.
#' @param ddf \code{"auto"} (Kenward-Roger for fits of the dense engine
#'   stored with \code{store = TRUE}, residual degrees of freedom otherwise),
#'   \code{"KR"} or \code{"residual"}.
#' @return A data frame with one row per fixed term: numerator degrees of
#'   freedom (\code{df}); incremental Wald statistic, F statistic,
#'   denominator degrees of freedom and p-value (\code{wald.inc},
#'   \code{F.inc}, \code{ddf.inc}, \code{p.inc}); the same for the
#'   conditional test (\code{wald.con}, \code{F.con}, \code{ddf.con},
#'   \code{p.con}); and the p-value of the conditional Wald statistic referred
#'   to a chi-square distribution (\code{p.chisq}). The attribute
#'   \code{"ddf"} gives the method used.
#' @references Kenward, M.G., Roger, J.H. (1997). Small sample inference for
#'   fixed effects from restricted maximum likelihood. \emph{Biometrics} 53,
#'   983-997.
#'
#'   Halekoh, U., Hojsgaard, S. (2014). A Kenward-Roger approximation and
#'   parametric bootstrap methods for tests in linear mixed models - the R
#'   package pbkrtest. \emph{J. Stat. Softw.} 59(9).
#' @examples
#' set.seed(2)
#' d <- data.frame(trt = gl(3, 20), blk = gl(4, 5, 60))
#' d$y <- c(0, 1, 2)[d$trt] + rnorm(4)[d$blk] + rnorm(60)
#' fit <- mlreml(y ~ trt, random = ~ blk, data = d, trace = FALSE)
#' wald(fit)
#' wald(fit, ddf = "residual")
#' @export
wald <- function(object, ddf = c("auto", "KR", "residual")) {
  ddf <- match.arg(ddf)
  dense <- is.null(object$engine) || identical(object$engine, "dense")
  if (ddf == "auto") ddf <- if (dense && !is.null(object$P)) "KR" else "residual"
  b <- object$beta; vb <- .full_vcov_beta(object)
  asg <- object$assign
  tf <- object$terms_fixed
  labs <- c("(Intercept)", attr(tf, "term.labels"))
  fac <- attr(tf, "factors")
  ## does term a2 contain term a1 (assign codes; 0 = intercept)?
  contains <- function(a2, a1) {
    if (a1 == a2) return(FALSE)
    if (a1 == 0) return(TRUE)
    if (a2 == 0) return(FALSE)
    v1 <- fac[, a1] > 0; v2 <- fac[, a2] > 0
    all(v2[v1])
  }
  C <- solve(vb)
  C <- (C + t(C)) / 2
  cC <- chol(C)
  kr <- if (ddf == "KR") .kr_phiA(object) else NULL
  rdf <- object$n - object$p
  test <- function(L, wald_stat) {
    q <- nrow(L)
    if (is.null(kr)) {
      Fv <- wald_stat / q
      return(c(F = Fv, ddf = rdf, p = stats::pf(Fv, q, rdf, lower.tail = FALSE)))
    }
    r <- .kr_test(kr, L, b)
    c(F = unname(r["F"]), ddf = unname(r["ddf"]),
      p = stats::pf(unname(r["F"]), q, unname(r["ddf"]), lower.tail = FALSE))
  }
  ua <- sort(unique(asg))
  out <- data.frame()
  for (a in ua) {
    j <- which(asg == a)
    df <- length(j)
    ## incremental: rows of the Cholesky factor in the order of the formula
    Linc <- cC[j, , drop = FALSE]
    inc <- sum(drop(Linc %*% b)^2)
    ## conditional: terms that do not contain the term, the term, terms that contain it
    others <- setdiff(ua, a)
    cont <- others[vapply(others, function(o) contains(o, a), logical(1))]
    before <- setdiff(others, cont)
    ord <- c(which(asg %in% before), j, which(asg %in% cont))
    Ro <- chol(C[ord, ord, drop = FALSE])
    pos <- match(j, ord)
    Lcon <- matrix(0, df, length(b))
    Lcon[, ord] <- Ro[pos, , drop = FALSE]
    con <- sum(drop(Lcon %*% b)^2)
    ti <- test(Linc, inc); tc <- test(Lcon, con)
    out <- rbind(out, data.frame(term = labs[a + 1], df = df,
                                 wald.inc = inc, F.inc = unname(ti["F"]), ddf.inc = unname(ti["ddf"]),
                                 p.inc = unname(ti["p"]),
                                 wald.con = con, F.con = unname(tc["F"]), ddf.con = unname(tc["ddf"]),
                                 p.con = unname(tc["p"]),
                                 p.chisq = stats::pchisq(con, df, lower.tail = FALSE)))
  }
  rownames(out) <- NULL
  attr(out, "ddf") <- if (ddf == "KR") "Kenward-Roger" else "residual (n - rank(X))"
  out
}

#' Functions of variance parameters with delta-method standard errors
#'
#' Evaluates a function of the variance parameters (for example a
#' heritability or a genetic correlation) and its approximate standard error
#' from the inverse of the Average Information matrix, as the
#' \code{vpredict} function of ASReml-R. Parameters are referred to as
#' \code{V1}, \code{V2}, ... in the order of \code{summary(fit)$varcomp}.
#'
#' @param object an \code{"mlreml"} fit.
#' @param formula a formula such as \code{h2 ~ V2 / (V2 + V3)}.
#' @return A data frame with the estimate and its standard error.
#' @examples
#' set.seed(3)
#' d <- data.frame(fam = gl(40, 5))
#' d$y <- rnorm(40, sd = 1)[d$fam] + rnorm(200, sd = 2)
#' fit <- mlreml(y ~ 1, random = ~ fam, data = d, trace = FALSE)
#' vpredict(fit, h2 ~ 4 * V1 / (V1 + V2))
#' @export
vpredict <- function(object, formula) {
  nm <- as.character(formula[[2]])
  ex <- formula[[3]]
  th <- object$theta
  f <- function(v) {
    e <- as.list(v); names(e) <- paste0("V", seq_along(v))
    eval(ex, e)
  }
  est <- f(th)
  g <- numeric(length(th))
  for (i in seq_along(th)) {
    h <- 1e-6 * max(abs(th[i]), 1e-4)
    tp <- th; tm <- th; tp[i] <- tp[i] + h; tm[i] <- tm[i] - h
    g[i] <- (f(tp) - f(tm)) / (2 * h)
  }
  se <- sqrt(max(drop(t(g) %*% object$vcov_theta %*% g), 0))
  data.frame(row.names = nm, estimate = est, std.error = se)
}

#' Likelihood ratio test between nested models
#'
#' Compares two models with the same fixed effects that differ in their
#' variance structure. With \code{boundary = TRUE} the p-value uses a 50:50
#' mixture of chi-square distributions, appropriate when a single variance
#' parameter is tested on the boundary of the parameter space.
#'
#' @param fit0 reduced model.
#' @param fit1 full model.
#' @param boundary logical; use the mixture distribution.
#' @return A data frame with the statistic, degrees of freedom and p-value.
#' @export
lrt <- function(fit0, fit1, boundary = TRUE) {
  if (!isTRUE(all.equal(colnames(fit0$X), colnames(fit1$X))))
    warning("REML likelihoods are only comparable with identical fixed effects")
  df <- sum(fit1$free) - sum(fit0$free)
  stat <- 2 * (fit1$loglik - fit0$loglik)
  p <- stats::pchisq(stat, df, lower.tail = FALSE)
  if (boundary && df == 1) p <- 0.5 * p
  data.frame(df = df, LR.statistic = stat, p.value = p,
             AIC0 = fit0$AIC, AIC1 = fit1$AIC, BIC0 = fit0$BIC, BIC1 = fit1$BIC)
}

#' Estimated covariance and correlation matrix of a structured component
#'
#' Returns the estimated covariance matrix of a \code{us}, \code{diag} or
#' \code{fa} component (for example the genetic covariance matrix between
#' environments or traits), its correlation matrix and, for \code{fa}, the
#' loadings and specific variances.
#'
#' @param object an \code{"mlreml"} fit.
#' @param term label of the term (as in \code{object$varcomp$term}), or
#'   \code{"residual"}.
#' @return A list with \code{cov} and \code{cor} (and \code{loadings},
#'   \code{psi} for factor analytic structures).
#' @export
vc_matrix <- function(object, term) {
  allterms <- c(object$terms, list(object$rterm))
  labs <- vapply(allterms, function(t) t$label, "")
  if (identical(term, "residual")) k <- length(allterms) else k <- match(term, labs)
  if (is.na(k)) stop("term not found; available: ", paste(labs, collapse = ", "))
  tk <- allterms[[k]]
  th <- object$theta[object$info$termid == k]
  pos <- if (tk$scale) 2L else 1L
  for (cc in tk$comps) {
    if (cc$npar == 0) next
    thc <- th[pos:(pos + cc$npar - 1)]; pos <- pos + cc$npar
    if (cc$struct %in% .var_structs) {
      S <- .comp_Sigma(cc, thc)
      dimnames(S) <- list(cc$levels, cc$levels)
      out <- list(cov = S, cor = stats::cov2cor(S))
      if (cc$struct == "fa") {
        Lam <- matrix(thc[seq_len(cc$L * cc$k)], cc$L, cc$k, dimnames = list(cc$levels, NULL))
        ## rotate to principal axes for interpretation
        sv <- svd(Lam)
        out$loadings <- Lam
        out$loadings_rotated <- Lam %*% sv$v
        out$psi <- stats::setNames(thc[cc$L * cc$k + seq_len(cc$L)], cc$levels)
        out$pct_variance <- 100 * diag(tcrossprod(Lam)) / diag(S)
      }
      return(out)
    }
  }
  stop("term '", term, "' has no diag, us or fa component")
}

#' Predicted means with standard errors and standard errors of differences
#'
#' Forms predictions for the levels of one or more factors (\code{classify}),
#' averaging the fixed effects over the levels of the other fixed factors
#' (simple averaging) and evaluating covariates at their mean. Random terms
#' whose factors are all contained in \code{classify} are included as BLUPs;
#' the remaining random terms are ignored (their expectation is zero). The
#' standard errors and the matrix of standard errors of differences (SED)
#' are computed from the joint prediction error variance of fixed and random
#' effects, following Welham et al. (2004).
#'
#' @param object an \code{"mlreml"} fit (fitted with \code{store = TRUE}).
#' @param classify character, for example \code{"gen"} or \code{"env:gen"}.
#' @param sed logical; return the SED matrix.
#' @param ... ignored.
#' @return A list with \code{pvals} (predicted values and standard errors),
#'   \code{sed} (matrix) and \code{avsed} (average SED).
#' @references Welham, S., Cullis, B., Gogel, B., Gilmour, A., Thompson, R.
#'   (2004). Prediction in linear mixed models. \emph{Aust. N. Z. J. Stat.}
#'   46, 325-347.
#' @export
predict.mlreml <- function(object, classify, sed = TRUE, ...) {
  sparse <- identical(object$engine, "sparse")
  if (sparse && is.null(object$sparse$factor)) stop("refit with store = TRUE")
  if (!sparse && is.null(object$P)) stop("refit with store = TRUE")
  cls <- strsplit(classify, ":", fixed = TRUE)[[1]]
  data <- object$data
  tf <- object$terms_fixed
  fvars <- all.vars(tf)
  ## levels of classify factors
  lev_list <- list()
  for (v in cls) {
    if (!is.null(object$xlev[[v]])) lev_list[[v]] <- object$xlev[[v]]
    else {
      found <- NULL
      for (tk in object$terms) for (cc in tk$comps) if (cc$label == v) found <- cc$levels
      if (is.null(found)) found <- levels(factor(data[[v]]))
      lev_list[[v]] <- found
    }
  }
  grid <- expand.grid(lev_list, stringsAsFactors = FALSE)
  key <- do.call(paste, c(grid, sep = ":"))
  ## fixed part: average model matrix rows over other factors
  others <- setdiff(names(object$xlev), cls)
  ogrid <- if (length(others)) expand.grid(object$xlev[others], stringsAsFactors = FALSE) else data.frame(.d = 1)
  covs <- setdiff(fvars, c(names(object$xlev), cls))
  L <- matrix(0, nrow(grid), ncol(object$X))
  for (g in seq_len(nrow(grid))) {
    nd <- ogrid
    for (v in cls) if (v %in% fvars) nd[[v]] <- grid[[v]][g]
    for (v in covs) nd[[v]] <- mean(data[[v]])
    for (v in names(object$xlev)) if (!is.null(nd[[v]])) nd[[v]] <- factor(nd[[v]], levels = object$xlev[[v]])
    mfn <- stats::model.frame(tf, nd, xlev = object$xlev)
    Xn <- stats::model.matrix(tf, mfn)
    Xn <- Xn[, colnames(object$X), drop = FALSE]
    L[g, ] <- colMeans(Xn)
  }
  pv <- drop(L %*% object$beta)
  VarP <- L %*% object$vcov_beta %*% t(L)
  ## random part
  inc <- c()
  Mr <- list()
  if (!sparse) {
    S <- matrix(0, nrow(grid), object$n)
    extra <- matrix(0, nrow(grid), nrow(grid))
  }
  for (k in seq_along(object$terms)) {
    tk <- object$terms[[k]]
    if (identical(tk$kind, "str")) next
    if (!all(tk$names %in% cls)) next
    if (any(vapply(tk$comps, function(cc) cc$basis_type != "factor", TRUE))) next
    inc <- c(inc, tk$label)
    th <- object$theta[object$info$termid == k]
    zt <- .term_Z(tk)
    parts <- .term_parts(tk, th)
    tkey <- do.call(paste, c(grid[tk$names], sep = ":"))
    m <- match(tkey, zt$levels)
    ok <- which(!is.na(m))
    b <- object$blups[[tk$label]]$blup
    pv[ok] <- pv[ok] + b[m[ok]]
    if (sparse) {
      ## columns of the random effects in the mixed model equations
      if (length(ok)) Mr[[length(Mr) + 1]] <- list(rows = ok, cols = object$sparse$offsets[k] + m[ok])
      next
    }
    if (length(ok)) {
      S[ok, ] <- S[ok, , drop = FALSE] + .GZt_rows(tk, parts, m[ok])
      extra[ok, ok] <- extra[ok, ok] + .G_sub(parts, m[ok], m[ok])
    }
  }
  if (sparse) {
    ## prediction error variance [L M] C^-1 [L M]' from the mixed model equations
    N <- object$sparse$N; p <- ncol(object$X)
    LM <- Matrix::Matrix(0, N, nrow(grid), sparse = TRUE)
    LM[seq_len(p), ] <- t(L)
    for (z in Mr) LM[cbind(z$cols, z$rows)] <- 1
    S <- as.matrix(Matrix::solve(object$sparse$factor, LM, system = "A"))
    VarP <- as.matrix(Matrix::crossprod(LM, S))
  } else if (length(inc)) {
    C12 <- -S %*% object$VX %*% object$vcov_beta      # M C21 (q x p)
    VarP <- VarP + L %*% t(C12) + C12 %*% t(L) + extra - S %*% object$P %*% t(S)
  }
  se <- sqrt(pmax(diag(VarP), 0))
  pvals <- cbind(grid, predicted.value = pv, std.error = se)
  out <- list(pvals = pvals, included_random = inc)
  if (sed) {
    dv <- diag(VarP)
    SED <- sqrt(pmax(outer(dv, dv, "+") - 2 * VarP, 0))
    dimnames(SED) <- list(key, key)
    out$sed <- SED
    out$avsed <- mean(SED[upper.tri(SED)])
  }
  out
}

#' Diagnostic plots
#'
#' Residuals against fitted values, normal quantile plot and histogram of the
#' residuals, and the history of the REML log-likelihood.
#' @param x an \code{"mlreml"} fit.
#' @param ... passed to \code{plot}.
#' @export
plot.mlreml <- function(x, ...) {
  op <- graphics::par(mfrow = c(2, 2), mar = c(4, 4, 2, 1))
  on.exit(graphics::par(op))
  graphics::plot(x$fitted, x$residuals, xlab = "Fitted", ylab = "Residual",
                 main = "Residuals vs fitted", pch = 20, col = "grey30", ...)
  graphics::abline(h = 0, lty = 2)
  stats::qqnorm(x$residuals, pch = 20, main = "Normal Q-Q"); stats::qqline(x$residuals)
  graphics::hist(x$residuals, breaks = 30, main = "Residuals", xlab = "Residual", col = "grey80")
  if (nrow(x$history)) graphics::plot(x$history$iteration, x$history$loglik, type = "b",
                                     xlab = "Iteration", ylab = "REML logLik", main = "Convergence")
}

#' Sample variogram of residuals of a field trial
#'
#' Computes the empirical semi-variogram of the residuals by absolute row
#' and column displacement, the standard diagnostic of spatial analyses
#' (Gilmour, Cullis and Verbyla, 1997).
#'
#' @param object an \code{"mlreml"} fit.
#' @param row,col names of the numeric row and column variables in the data.
#' @param plot logical; draw a perspective plot.
#' @param resid optional vector of residuals (default: conditional residuals).
#' @return A data frame with row lag, column lag, semi-variance and number of
#'   pairs.
#' @references Gilmour, A.R., Cullis, B.R., Verbyla, A.P. (1997). Accounting
#'   for natural and extraneous variation in the analysis of field experiments.
#'   \emph{JABES} 2, 269-293.
#' @export
variogram <- function(object, row, col, plot = TRUE, resid = NULL) {
  r <- if (is.null(resid)) object$residuals else resid
  rr <- as.numeric(as.character(object$data[[row]]))
  cc <- as.numeric(as.character(object$data[[col]]))
  dr <- abs(outer(rr, rr, "-")); dc <- abs(outer(cc, cc, "-"))
  sv <- 0.5 * outer(r, r, "-")^2
  up <- upper.tri(sv)
  agg <- stats::aggregate(sv[up], by = list(row.lag = dr[up], col.lag = dc[up]),
                          FUN = function(z) c(gamma = mean(z), n = length(z)))
  out <- data.frame(row.lag = agg$row.lag, col.lag = agg$col.lag,
                    gamma = agg$x[, "gamma"], npairs = agg$x[, "n"])
  out <- out[out$npairs >= 10, ]
  if (plot) {
    rl <- sort(unique(out$row.lag)); clg <- sort(unique(out$col.lag))
    Zm <- matrix(NA, length(rl), length(clg))
    Zm[cbind(match(out$row.lag, rl), match(out$col.lag, clg))] <- out$gamma
    graphics::persp(rl, clg, Zm, theta = 30, phi = 25, xlab = "Row lag",
                    ylab = "Column lag", zlab = "Semi-variance", ticktype = "detailed",
                    col = "lightblue", main = "Sample variogram")
  }
  out
}

## complete covariance matrix of the fixed effects (fits of the sparse engine with many
## fixed effects store only the elements available in the sparse inverse)
.full_vcov_beta <- function(object) {
  vb <- object$vcov_beta
  if (!methods::is(vb, "diagonalMatrix") && !anyNA(vb)) return(vb)
  if (is.null(object$sparse$factor))
    stop("the covariance matrix of the fixed effects is incomplete; refit with store = TRUE")
  out <- .sp_vcov_fixed(object$sparse$factor, object$sparse$N, nrow(vb))
  dimnames(out) <- list(names(object$beta), names(object$beta))
  out
}

## diagonal of the covariance matrix of the fixed effects (dense matrix or diagonal Matrix)
.vb_diag <- function(vb) {
  if (methods::is(vb, "Matrix")) return(stats::setNames(Matrix::diag(vb), rownames(vb)))
  diag(vb)
}
