#' Fast GBLUP by spectral decomposition
#'
#' Fits \eqn{y = X\beta + g + e}, \eqn{g \sim N(0, K\sigma^2_g)},
#' \eqn{e \sim N(0, I\sigma^2_e)} by exact REML using the eigen-decomposition
#' of the relationship matrix of the phenotyped individuals (Kang et al.,
#' 2008), which reduces REML to a one-dimensional optimisation. Predictions
#' (GEBVs) are returned for every individual in \code{K}, phenotyped or not.
#' The results are identical to \code{mlreml(y ~ ..., random = ~ vm(id, K))}
#' but much faster.
#'
#' @param y numeric vector of phenotypes, named by individual, or with the
#'   individual identifiers given in \code{id}.
#' @param K relationship matrix with rownames.
#' @param X optional fixed-effects design matrix (default: intercept).
#' @param id optional character vector of identifiers for \code{y}.
#' @return A list with \code{varcomp} (\eqn{\sigma^2_g}, \eqn{\sigma^2_e},
#'   \eqn{h^2}), \code{beta}, \code{gebv} (named vector for all individuals in
#'   \code{K}) and \code{loglik}.
#' @references Kang, H.M. et al. (2008). Efficient control of population
#'   structure in model organism association mapping. \emph{Genetics} 178,
#'   1709-1723.
#' @export
gblup <- function(y, K, X = NULL, id = names(y)) {
  if (is.null(id)) stop("give names to y or the argument 'id'")
  ok <- !is.na(y)
  y <- y[ok]; id <- id[ok]
  if (is.null(X)) X <- matrix(1, length(y), 1) else X <- as.matrix(X)[ok, , drop = FALSE]
  m <- match(id, rownames(K))
  if (anyNA(m)) stop("some individuals are missing from K")
  Ko <- K[m, m]
  e <- eigen(Ko, symmetric = TRUE)
  lam <- pmax(e$values, 0)
  U <- e$vectors
  yt <- drop(crossprod(U, y)); Xt <- crossprod(U, X)
  n <- length(y); p <- ncol(X)
  reml <- function(ld) {
    d <- lam + exp(ld)
    XDX <- crossprod(Xt, Xt / d)
    b <- solve(XDX, crossprod(Xt, yt / d))
    r <- yt - Xt %*% b
    s2 <- sum(r^2 / d) / (n - p)
    -0.5 * ((n - p) * log(s2) + sum(log(d)) + as.numeric(determinant(XDX)$modulus) + (n - p))
  }
  opt <- stats::optimize(reml, c(-12, 12), maximum = TRUE)
  delta <- exp(opt$maximum)
  d <- lam + delta
  XDX <- crossprod(Xt, Xt / d)
  b <- drop(solve(XDX, crossprod(Xt, yt / d)))
  r <- drop(yt - Xt %*% b)
  s2g <- sum(r^2 / d) / (n - p)
  alpha <- U %*% (r / d)                       # (K + delta I)^-1 (y - Xb)
  gebv <- drop(K[, m] %*% alpha)
  names(gebv) <- rownames(K)
  list(varcomp = c(sigma2_g = s2g, sigma2_e = delta * s2g, h2 = 1 / (1 + delta)),
       beta = b, gebv = gebv, loglik = opt$objective - 0.5 * (n - p) * log(2 * pi),
       delta = delta)
}

#' K-fold cross-validation of GBLUP
#'
#' Randomly partitions the phenotyped individuals into \code{folds} groups,
#' predicts each group from the others with \code{\link{gblup}} and reports
#' the Pearson correlation between predicted and observed values.
#'
#' @param y named vector of phenotypes.
#' @param K relationship matrix.
#' @param folds number of folds.
#' @param reps number of repetitions of the random partition.
#' @param seed random seed.
#' @return A data frame with one row per repetition and fold.
#' @export
cv_gblup <- function(y, K, folds = 5, reps = 1, seed = 1) {
  set.seed(seed)
  y <- y[!is.na(y)]
  out <- data.frame()
  for (r in seq_len(reps)) {
    f <- sample(rep(seq_len(folds), length.out = length(y)))
    for (k in seq_len(folds)) {
      ytr <- y; ytr[f == k] <- NA
      fit <- gblup(ytr, K, id = names(y))
      pr <- fit$gebv[names(y)[f == k]]
      out <- rbind(out, data.frame(rep = r, fold = k, n_test = sum(f == k),
                                   cor = stats::cor(pr, y[f == k]),
                                   h2 = fit$varcomp["h2"]))
    }
  }
  rownames(out) <- NULL
  out
}
