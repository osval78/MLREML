## ---------------------------------------------------------------------------
## Kenward-Roger (1997) adjustment of the covariance matrix of the fixed effects
## and denominator degrees of freedom of F tests (dense engine).
##
##   Phi   = (X'V^-1 X)^-1
##   P_i   = -X'V^-1 V_i V^-1 X,  Q_ij = X'V^-1 V_i V^-1 V_j V^-1 X,
##   R_ij  = X'V^-1 V_ij V^-1 X   (V_i = dV/dtheta_i, V_ij = d2V/dtheta_i dtheta_j)
##   W     = inverse of the expected information, I_ij = 0.5 tr(P V_i P V_j)
##   Phi_A = Phi + 2 Phi { sum_ij W_ij (Q_ij - P_i Phi P_j - R_ij / 4) } Phi
## The computations follow Kenward and Roger (1997) and the implementation of
## the pbkrtest package (Halekoh and Hojsgaard, 2014), extended with the second
## derivatives R_ij for covariance structures that are not linear in their
## parameters (ar1, expc, sexp, fa and products of parameterised components).
## ---------------------------------------------------------------------------

## second derivative of V with respect to parameters i and j (NULL if zero)
.d2V <- function(allterms, info, cache, i, j) {
  k <- info$termid[i]
  if (info$termid[j] != k) return(NULL)
  tk <- allterms[[k]]
  if (identical(tk$kind, "str")) return(NULL)
  pk <- which(info$termid == k)
  li <- match(i, pk); lj <- match(j, pk)
  ch <- cache[[k]]
  s1 <- tk$scale && li == 1; s2 <- tk$scale && lj == 1
  if (s1 && s2) return(NULL)
  if (s1 || s2) {
    o <- if (s1) j else i
    return(.dV(allterms, info, cache, o) / ch$s2)
  }
  c1 <- tk$parcomp[li]; c2 <- tk$parcomp[lj]
  j1 <- tk$parj[li]; j2 <- tk$parj[lj]
  if (c1 != c2) {
    d1 <- .expand(tk$comps[[c1]], .comp_dSigma(tk$comps[[c1]], ch$ths[[c1]], j1))
    d2 <- .expand(tk$comps[[c2]], .comp_dSigma(tk$comps[[c2]], ch$ths[[c2]], j2))
    others <- ch$Ms[-c(c1, c2)]
    out <- d1 * d2
  } else {
    S2 <- .comp_d2Sigma(tk$comps[[c1]], ch$ths[[c1]], j1, j2)
    if (is.null(S2)) return(NULL)
    out <- .expand(tk$comps[[c1]], S2)
    others <- ch$Ms[-c1]
  }
  if (length(others)) out <- out * Reduce(`*`, others)
  ch$s2 * out
}

## adjusted covariance matrix Phi_A and the quantities needed by the F tests
.kr_phiA <- function(object, maxmem = 2e9) {
  if (!identical(object$engine, "dense") && !is.null(object$engine))
    stop("the Kenward-Roger adjustment is only available for the dense engine")
  if (is.null(object$P)) stop("refit with store = TRUE to use the Kenward-Roger adjustment")
  allterms <- lapply(c(object$terms, list(object$rterm)), .restore_term)
  info <- object$info; theta <- object$theta
  bv <- .build_V(allterms, info, theta)
  V <- bv$V
  X <- object$X; Phi <- object$vcov_beta; P <- object$P; VX <- object$VX
  n <- nrow(X); p <- ncol(X)
  use <- which(object$free & object$varcomp$bound != "B")
  m <- length(use)
  if (m == 0) return(list(PhiA = Phi, Phi = Phi, Pl = list(), W = matrix(0, 0, 0), m = 0))
  Vinv <- P + VX %*% Phi %*% t(VX)
  Vi <- lapply(use, function(i) .dV(allterms, info, bv$cache, i))
  Pl <- lapply(Vi, function(D) -crossprod(VX, D %*% VX))
  O <- lapply(Vi, function(D) D %*% VX)                       # V_i V^-1 X
  VO <- lapply(O, function(o) Vinv %*% o)
  ## expected information 0.5 tr(P V_i P V_j); the AI matrix if memory is short
  if (8 * m * n^2 <= maxmem) {
    PV <- lapply(Vi, function(D) P %*% D)
    IE <- matrix(0, m, m)
    for (a in seq_len(m)) for (b in seq_len(a)) {
      IE[a, b] <- IE[b, a] <- 0.5 * sum(PV[[a]] * t(PV[[b]]))
    }
    rm(PV)
    info_type <- "expected"
  } else {
    pos <- match(use, which(object$free))
    IE <- object$AI[pos, pos, drop = FALSE]
    info_type <- "average"
  }
  W <- tryCatch(solve(IE), error = function(e) MASS_ginv(IE))
  U <- matrix(0, p, p)
  for (a in seq_len(m)) for (b in seq_len(m)) {
    Qab <- crossprod(O[[a]], VO[[b]])
    term <- Qab - Pl[[a]] %*% Phi %*% Pl[[b]]
    D2 <- .d2V(allterms, info, bv$cache, use[a], use[b])
    if (!is.null(D2)) term <- term - 0.25 * crossprod(VX, D2 %*% VX)
    U <- U + W[a, b] * term
  }
  PhiA <- Phi + 2 * Phi %*% U %*% Phi
  PhiA <- (PhiA + t(PhiA)) / 2
  dimnames(PhiA) <- dimnames(Phi)
  list(PhiA = PhiA, Phi = Phi, Pl = Pl, W = W, m = m, information = info_type)
}

## Kenward-Roger F test of L beta = 0
.kr_test <- function(kr, L, beta) {
  q <- qr(L)$rank
  Phi <- kr$Phi; PhiA <- kr$PhiA
  Lb <- drop(L %*% beta)
  F0 <- drop(crossprod(Lb, solve(L %*% PhiA %*% t(L), Lb))) / q
  if (kr$m == 0) return(c(F = F0, ddf = Inf, scale = 1))
  Theta <- t(L) %*% solve(L %*% Phi %*% t(L), L)
  TP <- Theta %*% Phi
  ui <- lapply(kr$Pl, function(Pi) TP %*% Pi %*% Phi)
  tri <- vapply(ui, function(u) sum(diag(u)), 0)
  A1 <- 0; A2 <- 0
  for (a in seq_len(kr$m)) for (b in seq_len(kr$m)) {
    A1 <- A1 + kr$W[a, b] * tri[a] * tri[b]
    A2 <- A2 + kr$W[a, b] * sum(ui[[a]] * t(ui[[b]]))
  }
  B <- (A1 + 6 * A2) / (2 * q)
  g <- ((q + 1) * A1 - (q + 4) * A2) / ((q + 2) * A2)
  den <- 3 * q + 2 * (1 - g)
  c1 <- g / den; c2 <- (q - g) / den; c3 <- (q + 2 - g) / den
  V0 <- 1 + c1 * B; V1 <- 1 - c2 * B; V2 <- 1 - c3 * B
  if (abs(V0) < 1e-10) V0 <- 0
  Estar <- 1 - A2 / q
  rho <- (1 / q) * (Estar / V1)^2 * V0 / V2          # Vstar / (2 Estar^2)
  m <- 4 + (q + 2) / (q * rho - 1)
  lambda <- if (abs(m - 4) < 1e-2) 1 else m * Estar / (m - 2)
  c(F = lambda * F0, ddf = m, scale = lambda)
}
