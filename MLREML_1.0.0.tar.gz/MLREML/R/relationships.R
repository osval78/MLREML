#' Prepare a pedigree
#'
#' Recodes unknown parents, adds parents that do not appear as individuals
#' (as founders), checks for errors and sorts the pedigree so that parents
#' precede their offspring.
#'
#' @param ped data frame whose first three columns are individual, sire
#'   (father) and dam (mother). Unknown parents can be coded as \code{NA},
#'   \code{0}, \code{"0"}, \code{"-"} or \code{""}.
#' @return A data frame with columns \code{id}, \code{sire}, \code{dam}
#'   (character, \code{NA} for unknown), \code{sire_i}, \code{dam_i}
#'   (integer positions, 0 for unknown) and \code{gen} (generation number).
#' @examples
#' ped <- data.frame(id = c("A3", "A4", "A5"), sire = c("A1", "A1", "A3"),
#'                   dam = c("A2", "A2", "A4"))
#' pedigree_prepare(ped)
#' @export
pedigree_prepare <- function(ped) {
  ped <- as.data.frame(ped)[, 1:3]
  names(ped) <- c("id", "sire", "dam")
  for (j in 1:3) ped[[j]] <- trimws(as.character(ped[[j]]))
  unk <- function(x) { x[x %in% c("0", "-", "", "NA", ".")] <- NA; x }
  ped$sire <- unk(ped$sire); ped$dam <- unk(ped$dam)
  if (anyDuplicated(ped$id)) stop("duplicated individuals in the pedigree: ",
                                  paste(utils::head(ped$id[duplicated(ped$id)]), collapse = ", "))
  if (any(ped$id == ped$sire, na.rm = TRUE) || any(ped$id == ped$dam, na.rm = TRUE))
    stop("some individuals are their own parent")
  extra <- setdiff(unique(c(ped$sire, ped$dam)), c(ped$id, NA))
  if (length(extra))
    ped <- rbind(data.frame(id = extra, sire = NA, dam = NA, stringsAsFactors = FALSE), ped)
  ## generation numbers
  gen <- rep(NA_integer_, nrow(ped))
  names(gen) <- ped$id
  gen[is.na(ped$sire) & is.na(ped$dam)] <- 0L
  for (it in seq_len(nrow(ped))) {
    todo <- which(is.na(gen))
    if (!length(todo)) break
    gs <- ifelse(is.na(ped$sire[todo]), -1L, gen[ped$sire[todo]])
    gd <- ifelse(is.na(ped$dam[todo]), -1L, gen[ped$dam[todo]])
    ok <- !is.na(gs) & !is.na(gd)
    gen[todo[ok]] <- pmax(gs[ok], gd[ok]) + 1L
    if (!any(ok)) stop("the pedigree contains loops")
  }
  ped$gen <- as.integer(gen)
  ped <- ped[order(ped$gen, seq_len(nrow(ped))), ]
  rownames(ped) <- NULL
  ped$sire_i <- match(ped$sire, ped$id, nomatch = 0L)
  ped$dam_i <- match(ped$dam, ped$id, nomatch = 0L)
  ped[, c("id", "sire", "dam", "sire_i", "dam_i", "gen")]
}

#' Inbreeding coefficients (Meuwissen and Luo, 1992)
#'
#' @param ped a pedigree as returned by \code{\link{pedigree_prepare}}, or any
#'   data frame accepted by it.
#' @return A named vector of inbreeding coefficients.
#' @references Meuwissen, T.H.E., Luo, Z. (1992). Computing inbreeding
#'   coefficients in large populations. \emph{Genet. Sel. Evol.} 24, 305-313.
#' @export
inbreeding_coef <- function(ped) {
  if (is.null(ped$sire_i)) ped <- pedigree_prepare(ped)
  ## compiled implementation (version 1.0.0); the interpreted version of 0.9.0 reset a
  ## working vector of length n for every animal, O(n^2) operations
  Fv <- inbreeding_cpp(as.integer(ped$sire_i), as.integer(ped$dam_i))
  stats::setNames(Fv, ped$id)
}

#' Numerator (additive) relationship matrix
#'
#' Builds the dense additive relationship matrix A with the tabular method.
#' Suitable for up to roughly 15,000 individuals; for larger pedigrees use
#' the sparse inverse \code{\link{Ainverse}}.
#'
#' @param ped pedigree (see \code{\link{pedigree_prepare}}).
#' @return A symmetric matrix with individual names as dimnames.
#' @examples
#' ped <- data.frame(id = c("A3", "A4", "A5"), sire = c("A1", "A1", "A3"),
#'                   dam = c("A2", "A2", "A4"))
#' Amatrix(ped)
#' @export
Amatrix <- function(ped) {
  if (is.null(ped$sire_i)) ped <- pedigree_prepare(ped)
  n <- nrow(ped)
  s <- ped$sire_i; d <- ped$dam_i
  A <- matrix(0, n, n)
  for (i in seq_len(n)) {
    if (i > 1) {
      j <- seq_len(i - 1)
      a <- 0.5 * ((if (s[i] > 0) A[j, s[i]] else 0) + (if (d[i] > 0) A[j, d[i]] else 0))
      A[j, i] <- a; A[i, j] <- a
    }
    A[i, i] <- 1 + if (s[i] > 0 && d[i] > 0) 0.5 * A[s[i], d[i]] else 0
  }
  dimnames(A) <- list(ped$id, ped$id)
  A
}

#' Sparse inverse of the additive relationship matrix
#'
#' Henderson's rules with inbreeding (Quaas, 1976), using the inbreeding
#' coefficients of Meuwissen and Luo (1992).
#'
#' @param ped pedigree (see \code{\link{pedigree_prepare}}).
#' @return A sparse symmetric matrix (\code{Matrix} package) with the
#'   attribute \code{INVERSE = TRUE}, so that it can be given directly to
#'   \code{vm()} or \code{str()} in \code{\link{mlreml}} (the sparse engine
#'   uses it as it is; the dense engine inverts it).
#' @export
Ainverse <- function(ped) {
  if (is.null(ped$sire_i)) ped <- pedigree_prepare(ped)
  n <- nrow(ped)
  Fv <- inbreeding_coef(ped)
  s <- ped$sire_i; d <- ped$dam_i
  Fp <- function(j) ifelse(j == 0, -1, Fv[pmax(j, 1)])
  b <- 1 / (0.5 - 0.25 * (Fp(s) + Fp(d)))
  I <- c(); J <- c(); X <- c()
  add <- function(i, j, x) { I <<- c(I, i); J <<- c(J, j); X <<- c(X, x) }
  idx <- seq_len(n)
  add(idx, idx, b)
  hs <- s > 0; hd <- d > 0
  add(idx[hs], s[hs], -b[hs] / 2); add(s[hs], idx[hs], -b[hs] / 2); add(s[hs], s[hs], b[hs] / 4)
  add(idx[hd], d[hd], -b[hd] / 2); add(d[hd], idx[hd], -b[hd] / 2); add(d[hd], d[hd], b[hd] / 4)
  both <- hs & hd
  add(s[both], d[both], b[both] / 4); add(d[both], s[both], b[both] / 4)
  Ai <- Matrix::sparseMatrix(i = I, j = J, x = X, dims = c(n, n), dimnames = list(ped$id, ped$id))
  Ai <- Matrix::forceSymmetric(Ai)
  attr(Ai, "INVERSE") <- TRUE
  ## log|A| = -sum(log b) and diag(A) = 1 + F, used by the sparse engine of mlreml()
  attr(Ai, "Kinfo") <- list(n = n, sumx = sum(Ai@x), logdet = -sum(log(b)),
                            diag = unname(1 + Fv))
  Ai
}

#' Quality control of a SNP matrix
#'
#' @param M matrix of genotypes (individuals in rows), coded 0/1/2 or
#'   -1/0/1; missing values as \code{NA}.
#' @param maf minimum minor-allele frequency.
#' @param callrate minimum call rate per marker.
#' @param ind_callrate minimum call rate per individual.
#' @return A list with the filtered matrix (\code{M}, coded 0/1/2),
#'   allele frequencies and a report of the removed markers and individuals.
#' @export
snp_qc <- function(M, maf = 0.05, callrate = 0.90, ind_callrate = 0.90) {
  M <- as.matrix(M)
  if (min(M, na.rm = TRUE) < 0) M <- M + 1
  icr <- rowMeans(!is.na(M))
  M <- M[icr >= ind_callrate, , drop = FALSE]
  cr <- colMeans(!is.na(M))
  p <- colMeans(M, na.rm = TRUE) / 2
  mf <- pmin(p, 1 - p)
  keep <- cr >= callrate & mf >= maf & is.finite(mf)
  list(M = M[, keep, drop = FALSE], p = p[keep],
       report = data.frame(markers_in = length(keep), removed_callrate = sum(cr < callrate),
                           removed_maf = sum(cr >= callrate & !(mf >= maf)),
                           markers_out = sum(keep), individuals_in = length(icr),
                           individuals_out = sum(icr >= ind_callrate)))
}

#' Genomic relationship matrix
#'
#' @param M matrix of genotypes (individuals in rows) coded 0/1/2 or -1/0/1.
#'   Missing values are replaced by the marker mean.
#' @param method \code{"VanRaden"} (VanRaden 2008, method 1),
#'   \code{"Yang"} (standardised markers, VanRaden method 2) or
#'   \code{"scaled"} (centred and scaled markers divided by the number of
#'   markers, \eqn{ZZ'/p}, the kernel of GBLUP as ridge regression).
#' @param p optional vector of base allele frequencies.
#' @return A symmetric matrix with the rownames of \code{M}.
#' @references VanRaden, P.M. (2008). Efficient methods to compute genomic
#'   predictions. \emph{J. Dairy Sci.} 91, 4414-4423.
#' @export
Gmatrix <- function(M, method = c("VanRaden", "Yang", "scaled"), p = NULL) {
  method <- match.arg(method)
  M <- as.matrix(M)
  if (min(M, na.rm = TRUE) < 0) M <- M + 1
  if (is.null(p)) p <- colMeans(M, na.rm = TRUE) / 2
  na <- which(is.na(M), arr.ind = TRUE)
  if (nrow(na)) M[na] <- 2 * p[na[, 2]]
  Z <- sweep(M, 2, 2 * p)
  G <- switch(method,
              VanRaden = tcrossprod(Z) / (2 * sum(p * (1 - p))),
              Yang = { s <- sqrt(2 * p * (1 - p)); s[s == 0] <- 1; tcrossprod(sweep(Z, 2, s, "/")) / ncol(Z) },
              scaled = { s <- apply(M, 2, stats::sd); s[s == 0] <- 1
                         tcrossprod(scale(M, scale = s)) / ncol(M) })
  dimnames(G) <- list(rownames(M), rownames(M))
  G
}

#' Make a symmetric matrix positive definite (bending)
#'
#' @param K symmetric matrix.
#' @param tol minimum eigenvalue after bending (relative to the largest).
#' @return The bent matrix.
#' @export
bend <- function(K, tol = 1e-4) {
  e <- eigen((K + t(K)) / 2, symmetric = TRUE)
  v <- pmax(e$values, tol * max(e$values))
  out <- e$vectors %*% (v * t(e$vectors))
  dimnames(out) <- dimnames(K)
  out
}

#' Align a genomic matrix with the pedigree matrix
#'
#' Rescales G as \eqn{\alpha + \beta G} so that the averages of its diagonal
#' and of all its elements equal those of A22 (Christensen et al., 2012).
#'
#' @param G genomic relationship matrix.
#' @param A22 pedigree relationships of the genotyped individuals.
#' @return The aligned matrix, with attributes \code{alpha} and \code{beta}.
#' @export
align_G <- function(G, A22) {
  mdG <- mean(diag(G)); maG <- mean(G); mdA <- mean(diag(A22)); maA <- mean(A22)
  beta <- (mdA - maA) / (mdG - maG); alpha <- mdA - beta * mdG
  out <- alpha + beta * G
  attr(out, "alpha") <- alpha; attr(out, "beta") <- beta
  out
}

#' Single-step relationship matrix H and its inverse
#'
#' Combines the pedigree matrix A of all individuals with the genomic matrix G
#' of the genotyped individuals (Legarra et al., 2009; Aguilar et al., 2010).
#' G is optionally blended with A22 and aligned to it before combining.
#'
#' @param A pedigree relationship matrix of all individuals (dense).
#' @param G genomic relationship matrix of the genotyped individuals; its
#'   rownames must be in \code{rownames(A)}.
#' @param blend weight of A22 in \eqn{(1-w)G + wA_{22}}.
#' @param align logical; align G to A22 with \code{\link{align_G}}.
#' @param tau,omega scaling factors of \eqn{G^{-1}} and \eqn{A_{22}^{-1}} in
#'   the inverse.
#' @param inverse logical; return \eqn{H^{-1}} instead of H.
#' @return H (or its inverse) with the dimnames of A.
#' @references Legarra, A., Aguilar, I., Misztal, I. (2009). A relationship
#'   matrix including full pedigree and genomic information. \emph{J. Dairy
#'   Sci.} 92, 4656-4663.
#' @export
Hmatrix <- function(A, G, blend = 0.05, align = TRUE, tau = 1, omega = 1, inverse = FALSE) {
  g <- match(rownames(G), rownames(A))
  if (anyNA(g)) stop("genotyped individuals missing from A")
  A22 <- A[g, g]
  if (align) G <- align_G(G, A22)
  G <- (1 - blend) * G + blend * A22
  if (!inverse) {
    A22i <- solve(A22)
    B <- A[, g] %*% A22i
    H <- A + B %*% (G - A22) %*% t(B)
    dimnames(H) <- dimnames(A)
    return(H)
  }
  Ai <- solve(A)
  Ai[g, g] <- Ai[g, g] + tau * solve(G) - omega * solve(A22)
  dimnames(Ai) <- dimnames(A)
  Ai
}
