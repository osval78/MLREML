#' MLREML: linear mixed models by Average-Information REML
#'
#' MLREML fits linear mixed models for plant and animal breeding by
#' restricted maximum likelihood with the Average Information algorithm.
#' The main function is \code{\link{mlreml}}. Two computing engines are
#' available: a dense engine based on the variance matrix of the observations,
#' which supports every variance structure, and a sparse engine based on the
#' mixed model equations, the sparse Cholesky factorisation and the Takahashi
#' sparse inverse, for data sets with hundreds of thousands to millions of
#' records. A user guide in English with the theory and worked examples with
#' real data (version 1.0.0) is installed with the package:
#' \code{system.file("doc", "MLREML-guide-en.pdf", package = "MLREML")}. The
#' guide in Spanish, \code{system.file("doc", "MLREML-guide-es.pdf", package = "MLREML")},
#' describes version 0.9.0 and does not include the additions of version 1.0.0.
#'
#' Main functions:
#' \itemize{
#'   \item \code{\link{mlreml}}: model fitting (including direct-maternal
#'     models with the \code{str()} term and the sparse engine).
#'   \item \code{\link{summary.mlreml}}, \code{\link{wald}} (with
#'     Kenward-Roger denominator degrees of freedom),
#'     \code{\link{predict.mlreml}}, \code{\link{vpredict}}, \code{\link{lrt}},
#'     \code{\link{vc_matrix}}, \code{\link{variogram}}: inference.
#'   \item \code{\link{pedigree_prepare}}, \code{\link{Amatrix}},
#'     \code{\link{Ainverse}}, \code{\link{inbreeding_coef}}, \code{\link{snp_qc}},
#'     \code{\link{Gmatrix}}, \code{\link{align_G}}, \code{\link{Hmatrix}},
#'     \code{\link{bend}}: relationship matrices.
#'   \item \code{\link{gblup}}, \code{\link{cv_gblup}}: fast GBLUP.
#' }
#' @useDynLib MLREML, .registration = TRUE
#' @importFrom Rcpp sourceCpp
#' @keywords internal
"_PACKAGE"
