#' Fit a linear mixed model by Average-Information REML
#'
#' \code{mlreml} fits the linear mixed model
#' \deqn{y = X\beta + \sum_k Z_k u_k + e,\quad u_k \sim N(0, G_k),\quad e \sim N(0, R)}
#' by restricted maximum likelihood (REML) with the Average Information (AI)
#' algorithm. The covariance matrices \eqn{G_k} and \eqn{R} are specified with
#' an ASReml-like syntax as direct (Kronecker) products of variance structures.
#'
#' @section Specifying random terms and residuals:
#' Each random term is a product of components separated by \code{:}.
#' Each component is a structure function applied to a factor, to a
#' polynomial basis of a covariate or to a multi-membership factor:
#' \describe{
#'   \item{\code{id(f)} or \code{f}}{independent effects, identity matrix.}
#'   \item{\code{vm(f, K)}}{effects correlated according to a known matrix
#'     \code{K} (pedigree A, genomic G, single-step H, kinship). \code{K}
#'     must have rownames that contain all levels of \code{f}; it may contain
#'     additional levels (individuals without records), whose BLUPs are also
#'     returned. \code{K} may also be given through its inverse, flagged with
#'     the attribute \code{INVERSE = TRUE} (as returned by
#'     \code{\link{Ainverse}}); the sparse engine then uses it directly.}
#'   \item{\code{diag(f)}}{independent effects with a different variance
#'     for each level of \code{f}.}
#'   \item{\code{us(f)}}{unstructured (fully parameterised) covariance matrix.}
#'   \item{\code{fa(f, k)}}{factor analytic structure with \code{k} factors,
#'     \eqn{\Lambda\Lambda' + \Psi}.}
#'   \item{\code{cs(f)}}{compound symmetry correlation.}
#'   \item{\code{ar1(f)}}{first-order autoregressive correlation; if the
#'     levels of \code{f} are numeric, the actual distances are used, so
#'     gaps are allowed.}
#'   \item{\code{expc(x)}}{exponential correlation \eqn{\rho^{|x_i-x_j|}}
#'     for an irregularly spaced numeric covariate.}
#'   \item{\code{sexp(x, y)}}{isotropic exponential correlation
#'     \eqn{\rho^{d_{ij}}} on two-dimensional coordinates (irregular
#'     spatial data).}
#'   \item{\code{pol(x, k)}, \code{leg(x, k)}}{raw and normalised Legendre
#'     polynomial bases of order \code{k} (random regression); usually
#'     combined with \code{us()} or \code{diag()}.}
#'   \item{\code{mm(f1, f2)}}{multi-membership factor (for example, general
#'     combining ability of the two parents in a diallel).}
#'   \item{\code{units}}{the observation units (one level per record).}
#' }
#' A term whose components are all correlation structures (\code{id},
#' \code{vm}, \code{cs}, \code{ar1}, \code{expc}, \code{sexp}) receives a
#' scale variance. At most one variance structure (\code{diag}, \code{us},
#' \code{fa}) is allowed per term, and it carries the scale.
#'
#' The \code{residual} formula uses the same syntax; the default is
#' \code{~ units} (independent residuals with a common variance) and, for
#' multivariate models, \code{~ us(trait):units}.
#'
#' @section Correlated effects of several factors (direct-maternal models):
#' The term \code{str(f1, f2, ..., K = A, cov = "us")} defines \eqn{m \ge 2}
#' random effects that share the levels of the matrix \code{K} and are
#' correlated with each other: with \eqn{u = (u_1', \ldots, u_m')'} and
#' \eqn{Z = [Z_1, \ldots, Z_m]},
#' \deqn{Var(u) = \Sigma \otimes K,}
#' where \eqn{\Sigma} is an unstructured (\code{cov = "us"}) or diagonal
#' (\code{cov = "diag"}) \eqn{m \times m} matrix. The usual application is
#' the direct-maternal animal model, \code{str(animal, dam, K = A)}, in which
#' \eqn{Z_1} links each record to the animal and \eqn{Z_2} to its dam, and
#' \eqn{\Sigma} contains the direct and maternal genetic variances and their
#' covariance. A missing value of a factor of \code{str()} (for example an
#' unknown dam) means that the record receives no effect from it; such
#' records are kept. If \code{K} is omitted the levels are independent
#' (\eqn{K = I}).
#'
#' @section Computing engines:
#' The \code{"dense"} engine works with the \eqn{n \times n} matrix
#' \eqn{V = Var(y)} and supports every structure; its cost grows with
#' \eqn{n^3} and its memory with \eqn{n^2}, so it is meant for up to a few
#' thousand records. The \code{"sparse"} engine works with Henderson's mixed
#' model equations, a sparse Cholesky factorisation (CHOLMOD, through the
#' \pkg{Matrix} package) and the sparse (Takahashi) inverse, so that its cost
#' depends on the number of non-zero elements rather than on \eqn{n^2}; it
#' handles hundreds of thousands to millions of records. It supports random
#' terms built from \code{id}, \code{vm}, \code{diag} and \code{us}
#' components (with factors, \code{pol}, \code{leg} or \code{mm} bases) and
#' \code{str()} terms, and the residual structures \code{units},
#' \code{diag(f):units} and, in multivariate models, \code{us(trait):units}.
#' \code{engine = "auto"} (default) uses the sparse engine when there are more
#' than 5000 records and the model is supported, and the dense engine
#' otherwise. Both engines give the same estimates, BLUPs and prediction
#' error variances up to numerical precision.
#'
#' @section Multivariate models:
#' If the left-hand side of \code{fixed} is \code{cbind(y1, y2, ...)}, the data
#' are stacked internally, a factor \code{trait} is created, and \code{units}
#' identifies the original records, so that \code{us(trait):units} is the
#' residual covariance matrix between traits measured on the same record.
#' Records with some traits missing are kept for the traits observed.
#'
#' @param fixed two-sided formula for the fixed effects.
#' @param random one-sided formula with the random terms, or \code{NULL}.
#' @param residual one-sided formula for the residual structure.
#' @param data data frame.
#' @param start optional named vector of starting values (names as in
#'   \code{summary(fit)$varcomp}).
#' @param fix character vector with names of variance parameters to be held
#'   fixed at their starting values.
#' @param maxit maximum number of AI iterations.
#' @param tol convergence tolerance for the change of the REML log-likelihood.
#' @param pev logical; compute prediction error variances of the BLUPs.
#' @param trace logical; print the iteration history.
#' @param store logical; keep the matrices needed by \code{\link{predict.mlreml}}
#'   and by the Kenward-Roger adjustment of \code{\link{wald}}.
#' @param engine \code{"auto"}, \code{"dense"} or \code{"sparse"} (see the
#'   section on computing engines).
#' @return An object of class \code{"mlreml"}.
#' @references
#' Gilmour, A.R., Thompson, R., Cullis, B.R. (1995). Average information REML:
#' an efficient algorithm for variance parameter estimation in linear mixed
#' models. \emph{Biometrics} 51, 1440-1450.
#'
#' Johnson, D.L., Thompson, R. (1995). Restricted maximum likelihood estimation
#' of variance components for univariate animal models using sparse matrix
#' techniques and average information. \emph{J. Dairy Sci.} 78, 449-456.
#'
#' Misztal, I., Perez-Enciso, M. (1993). Sparse matrix inversion for
#' restricted maximum likelihood estimation of variance components by
#' expectation-maximization. \emph{J. Dairy Sci.} 76, 1479-1483.
#'
#' Willham, R.L. (1963). The covariance between relatives for characters
#' composed of components contributed by related individuals.
#' \emph{Biometrics} 19, 18-27.
#' @examples
#' set.seed(1)
#' d <- data.frame(block = factor(rep(1:4, each = 30)),
#'                 gen = factor(rep(1:30, 4)))
#' d$y <- 10 + rnorm(4)[d$block] + rnorm(30, sd = 1.5)[d$gen] + rnorm(120)
#' fit <- mlreml(y ~ block, random = ~ id(gen), data = d)
#' summary(fit)
#' @export
mlreml <- function(fixed, random = NULL, residual = NULL, data, start = NULL,
                   fix = NULL, maxit = 50, tol = 1e-6, pev = TRUE, trace = TRUE,
                   store = TRUE, engine = c("auto", "dense", "sparse")) {
  cl <- match.call()
  engine <- match.arg(engine)
  env <- environment(fixed)
  data <- as.data.frame(data)
  lhs <- fixed[[2]]
  multi <- is.call(lhs) && identical(lhs[[1]], as.name("cbind"))
  if (multi) {
    traits <- vapply(as.list(lhs)[-1], deparse, "")
    long <- do.call(rbind, lapply(traits, function(tr) {
      dd <- data
      dd$.y <- data[[tr]]
      dd$trait <- tr
      dd$.units <- seq_len(nrow(data))
      dd
    }))
    long$trait <- factor(long$trait, levels = traits)
    data <- long
    yname <- ".y"
    if (is.null(residual)) residual <- ~ us(trait):units
  } else {
    yname <- deparse(lhs)
    data$.y <- eval(lhs, data, env)
    traits <- NULL
  }
  if (is.null(residual)) residual <- ~ units
  rhs <- stats::delete.response(stats::terms(fixed))
  term_labels <- function(f) {
    if (is.null(f)) return(character(0))
    tt <- stats::terms(f, keep.order = TRUE)
    attr(tt, "term.labels")
  }
  rlabs <- term_labels(random)
  rlab <- term_labels(residual)
  if (length(rlab) != 1) stop("the residual formula must contain a single term")
  ## records with missing values are removed, except for missing values of the
  ## factors of str() terms (they mean "no effect", e.g. an unknown dam)
  is_str <- vapply(rlabs, function(l) .is_str_label(l), logical(1))
  vars <- unique(c(all.vars(rhs), unlist(lapply(rlabs[!is_str], function(l) all.vars(str2lang(l)))),
                   all.vars(residual)))
  vars <- intersect(vars, names(data))
  keep <- !is.na(data$.y)
  for (v in vars) keep <- keep & !is.na(data[[v]])
  data <- data[keep, , drop = FALSE]
  if (multi) data <- data[order(data$.units, data$trait), , drop = FALSE]
  rownames(data) <- NULL
  n <- nrow(data)
  y <- data$.y

  ## choice of the computing engine
  why <- .sparse_supported(rlabs, rlab, multi)
  if (engine == "auto") engine <- if (n > 5000 && is.null(why)) "sparse" else "dense"
  if (engine == "sparse" && !is.null(why))
    stop("the sparse engine does not support this model (", why, "); use engine = \"dense\"")
  if (engine == "sparse")
    return(.mlreml_sparse(cl = cl, fixed = fixed, random = random, residual = residual,
                          data = data, y = y, rhs = rhs, rlabs = rlabs, rlab = rlab, env = env,
                          multi = multi, traits = traits, yname = yname, start = start,
                          fix = fix, maxit = maxit, tol = tol, pev = pev, trace = trace,
                          store = store))

  ## fixed effects
  mf <- stats::model.frame(rhs, data, drop.unused.levels = TRUE)
  X0 <- stats::model.matrix(rhs, mf)
  qrX <- qr(X0)
  keepX <- sort(qrX$pivot[seq_len(qrX$rank)])
  X <- X0[, keepX, drop = FALSE]
  assign <- attr(X0, "assign")[keepX]
  xlev <- stats::.getXlevels(stats::terms(mf), mf)
  p <- ncol(X)

  ## random and residual terms
  terms <- lapply(rlabs, .make_term, data = data, env = env, nobs = n)
  rterm <- .make_term(rlab, data, env, n, is_resid = TRUE)
  allterms <- c(terms, list(rterm))
  names(allterms) <- c(vapply(terms, function(t) t$label, ""), paste0("units!R"))

  ## parameter bookkeeping
  init <- .start_values(allterms, y, X, data)
  pp <- .setup_params(init, start, fix)
  theta <- pp$theta; info <- pp$info; free <- pp$free

  ## AI-REML iterations
  evalfun <- function(theta, deriv) .reml_eval(allterms, info, theta, y, X, deriv = deriv, free = free)
  it <- .ai_iterate(evalfun, allterms, info, theta, free, maxit, tol, trace)
  theta <- it$theta

  ## final quantities
  fin <- .reml_eval(allterms, info, theta, y, X, deriv = TRUE, free = free, keep = TRUE)
  vt <- .varcomp_table(fin$AI, theta, info, free)

  beta <- drop(fin$Ci %*% crossprod(fin$VX, y))
  names(beta) <- colnames(X)
  vb <- fin$Ci
  dimnames(vb) <- list(colnames(X), colnames(X))
  Py <- fin$Py

  ## BLUPs
  blups <- list()
  fitted_r <- drop(X %*% beta)
  for (k in seq_along(terms)) {
    tk <- terms[[k]]
    th <- theta[info$termid == k]
    if (identical(tk$kind, "str")) {
      bl <- .str_blup_dense(tk, th, Py, fin$P, pev)
      blups[[tk$label]] <- bl$out
      fitted_r <- fitted_r + bl$fit
      next
    }
    zt <- .term_Z(tk)
    parts <- .term_parts(tk, th)
    q <- length(zt$levels)
    dG <- .G_diag(parts)
    u <- numeric(q); pevv <- rep(NA_real_, q)
    chunk <- max(1L, floor(5e6 / n))
    for (st in seq(1L, q, by = chunk)) {
      rows <- st:min(q, st + chunk - 1L)
      GZt <- .GZt_rows(tk, parts, rows)
      u[rows] <- drop(GZt %*% Py)
      if (pev) pevv[rows] <- dG[rows] - rowSums((GZt %*% fin$P) * GZt)
    }
    out <- data.frame(level = zt$levels, blup = u, stringsAsFactors = FALSE)
    if (pev) {
      out$pev <- pmax(pevv, 0)
      out$se <- sqrt(out$pev)
      out$reliability <- ifelse(dG > 0, 1 - out$pev / dG, NA)
    }
    blups[[tk$label]] <- out
    fitted_r <- fitted_r + as.vector(zt$Z %*% u)
  }
  ## drop the n x n working matrices kept inside the terms
  terms <- lapply(terms, .strip_term); rterm <- .strip_term(rterm)
  npar <- sum(free)
  ll <- fin$loglik
  res <- list(call = cl, fixed = fixed, random = random, residual = residual,
              loglik = ll, AIC = -2 * ll + 2 * npar, BIC = -2 * ll + log(n - p) * npar,
              varcomp = vt$varcomp, theta = theta, vcov_theta = vt$vcov_theta, AI = fin$AI,
              free = free, info = info, beta = beta, vcov_beta = vb, blups = blups,
              fitted = fitted_r, residuals = y - fitted_r,
              fixed_fitted = drop(X %*% beta), y = y, n = n, p = p, X = X,
              assign = assign, xlev = xlev, terms_fixed = stats::terms(mf),
              terms = terms, rterm = rterm, converged = it$converged,
              iterations = nrow(it$history), history = it$history, multi = multi,
              traits = traits, data = data, yname = yname, engine = "dense")
  if (store) { res$P <- fin$P; res$VX <- fin$VX }
  class(res) <- "mlreml"
  res
}

## starting values, user starting values and fixed parameters
.setup_params <- function(init, start, fix) {
  theta <- init$theta
  info <- init$info
  if (!is.null(start)) {
    m <- match(names(start), info$name)
    if (anyNA(m)) stop("unknown names in 'start': ", paste(names(start)[is.na(m)], collapse = ", "))
    theta[m] <- start
  }
  free <- !info$fixed_constraint
  if (!is.null(fix)) {
    m <- match(fix, info$name)
    if (anyNA(m)) stop("unknown names in 'fix': ", paste(fix[is.na(m)], collapse = ", "))
    free[m] <- FALSE
  }
  info$fixed_user <- !free & !info$fixed_constraint
  list(theta = theta, info = info, free = free)
}

## AI-REML iterations with Levenberg-Marquardt damping (shared by both engines);
## evalfun(theta, deriv) returns loglik and, with deriv = TRUE, score and AI
.ai_iterate <- function(evalfun, allterms, info, theta, free, maxit, tol, trace) {
  history <- data.frame()
  conv <- FALSE
  cur <- evalfun(theta, TRUE)
  lambda <- 0
  if (!any(free)) { maxit <- 0; conv <- TRUE }
  for (it in seq_len(maxit)) {
    accepted <- FALSE
    ## active set (version 1.0.0): parameters on their lower bound whose score or Newton
    ## step points outside the parameter space are held on the bound and removed from
    ## the AI system, so that the remaining parameters still move to their optimum
    ## (0.9.0 clipped the joint step, which could stall all parameters at a
    ## non-stationary point when a variance was on the boundary)
    lwf <- info$lower[free]
    atb <- is.finite(lwf) & theta[free] <= lwf + 1e-6 * pmax(abs(lwf), 1e-12)
    for (h in 1:20) {
      A <- cur$AI + lambda * diag(pmax(diag(cur$AI), 1e-12), nrow(cur$AI))
      act <- !(atb & cur$score < 0)
      step <- NULL
      for (pass in seq_len(length(act) + 1)) {
        st <- numeric(length(act))
        sa <- tryCatch(solve(A[act, act, drop = FALSE], cur$score[act]), error = function(e) NULL)
        if (is.null(sa)) break
        st[act] <- sa
        out <- act & atb & st < 0
        if (!any(out)) { step <- st; break }
        act[out] <- FALSE
      }
      if (!is.null(step)) {
        cand <- theta
        cand[free] <- theta[free] + step
        cand <- .project(allterms, info, .clip(cand, info))
        if (.valid(allterms, info, cand)) {
          ll_c <- tryCatch(evalfun(cand, FALSE)$loglik, error = function(e) -Inf)
          if (is.finite(ll_c) && ll_c >= cur$loglik - 1e-10) { accepted <- TRUE; break }
        }
      }
      lambda <- if (lambda == 0) 1e-3 else lambda * 10
    }
    if (!accepted) { warning("no improving step found at iteration ", it); break }
    dpar <- max(abs(cand - theta) / pmax(abs(theta), 1e-4))
    theta <- cand
    new <- evalfun(theta, TRUE)
    dll <- new$loglik - cur$loglik
    history <- rbind(history, data.frame(iteration = it, loglik = new$loglik, lambda = lambda))
    if (trace) message(sprintf("Iteration %2d  logLik = %.4f  (damping %.2g)", it, new$loglik, lambda))
    lambda <- if (lambda <= 1e-3) 0 else lambda / 100
    cur <- new
    ## Newton decrement excluding parameters held at a lower bound
    lw <- info$lower[free]
    atlow <- is.finite(lw) & (theta[free] <= lw + 1e-6 * pmax(abs(lw), 1e-12)) & cur$score < 0
    nd <- if (all(atlow)) 0 else {
      sc <- cur$score[!atlow]
      Aa <- cur$AI[!atlow, !atlow, drop = FALSE]
      tryCatch(sum(sc * solve(Aa, sc)), error = function(e) sum(sc * (MASS_ginv(Aa) %*% sc)))
    }
    if (abs(dll) < tol && (nd < 1e-3 || dpar < 1e-5)) {
      conv <- TRUE
      if (nd >= 1e-3)
        warning("AI-REML stopped because the steps became negligible although the score is not ",
                "zero; a variance matrix is probably singular (on the boundary of the parameter ",
                "space). Check the estimates and consider a reduced structure (diag, fa).")
      break
    }
  }
  if (!conv) warning("AI-REML did not converge in ", maxit, " iterations")
  list(theta = theta, history = history, converged = conv)
}

## table of variance parameters with standard errors from the inverse AI matrix
.varcomp_table <- function(AI, theta, info, free) {
  AIinv <- if (any(free)) tryCatch(solve(AI), error = function(e) MASS_ginv(AI)) else matrix(0, 0, 0)
  se <- rep(NA_real_, length(theta))
  se[free] <- sqrt(pmax(diag(AIinv), 0))
  vcov_theta <- matrix(0, length(theta), length(theta))
  vcov_theta[free, free] <- AIinv
  bound <- ifelse(!free, "F", "P")
  atb <- free & theta <= info$lower * 1.0000001 & info$type == "variance"
  bound[atb] <- "B"
  varcomp <- data.frame(term = info$term, component = info$name, estimate = theta,
                        std.error = se, z.ratio = theta / se, bound = bound,
                        stringsAsFactors = FALSE)
  rownames(varcomp) <- info$name
  list(varcomp = varcomp, vcov_theta = vcov_theta)
}

## drop the n x n working matrices kept inside a term
.strip_term <- function(t) {
  for (ci in seq_along(t$comps)) t$comps[[ci]]$M <- NULL
  t$Mab <- NULL
  t
}

## rebuild the n x n working matrices of a stripped term (dense engine)
.restore_term <- function(t) {
  if (identical(t$kind, "str")) {
    if (is.null(t$Mab)) t$Mab <- .str_M(t)
    return(t)
  }
  for (ci in seq_along(t$comps)) {
    cc <- t$comps[[ci]]
    if (cc$npar == 0 && is.null(cc$M)) {
      S <- if (cc$struct == "vm") cc$K else NULL
      if (cc$struct == "id" && is.null(cc$idx)) S <- diag(cc$L)
      t$comps[[ci]]$M <- .expand(cc, S)
    }
  }
  t
}

## generalised inverse without MASS dependency
MASS_ginv <- function(A, tol = sqrt(.Machine$double.eps)) {
  s <- svd(A)
  pos <- s$d > max(tol * s$d[1], 0)
  s$v[, pos, drop = FALSE] %*% (t(s$u[, pos, drop = FALSE]) / s$d[pos])
}

## ---------------------------------------------------------------------------
## starting values and parameter table
.start_values <- function(allterms, y, X, data, r = NULL) {
  if (is.null(r)) r <- stats::lm.fit(X, y)$residuals
  vp <- stats::var(r)
  nt <- length(allterms)
  share <- 1 / nt
  theta <- numeric(0)
  info <- data.frame()
  for (k in seq_along(allterms)) {
    tk <- allterms[[k]]
    th <- numeric(0); lower <- numeric(0); upper <- numeric(0); fc <- logical(0)
    if (tk$scale) { th <- vp * share; lower <- 1e-8 * vp; upper <- Inf; fc <- FALSE }
    for (cc in tk$comps) {
      if (cc$npar == 0) next
      if (cc$struct %in% c("cs")) {
        ## a compound-symmetry correlation matrix of order L is positive definite only for
        ## rho > -1/(L - 1) (0.9.0 allowed rho down to -0.99 for any L)
        lw <- if (cc$L > 1) max(-0.999, -1 / (cc$L - 1) + 1e-4) else -0.999
        th <- c(th, 0.1); lower <- c(lower, lw); upper <- c(upper, 0.999); fc <- c(fc, FALSE)
      } else if (cc$struct %in% c("ar1", "expc", "sexp")) {
        dmin <- min(cc$D[cc$D > 0])
        th <- c(th, 0.5^(1 / dmin))
        ## a negative autocorrelation is only defined for integer distances
        ## (rho^d is not real for rho < 0 and non-integer d)
        intd <- all(abs(cc$D - round(cc$D)) < 1e-8)
        lower <- c(lower, if (cc$struct == "ar1" && intd) -0.99 else 1e-6)
        upper <- c(upper, 0.999); fc <- c(fc, FALSE)
      } else {
        ## level-specific starting variances
        d <- numeric(cc$L)
        for (l in seq_len(cc$L)) {
          zl <- cc$Z[, l]
          rows <- which(zl != 0)
          if (!is.null(cc$idx) && length(rows) >= 3) d[l] <- stats::var(r[rows]) * share
          else if (length(rows) > 0) d[l] <- share * vp / mean(zl[rows]^2)
          else d[l] <- share * vp
        }
        d[!is.finite(d) | d <= 0] <- share * vp
        if (cc$struct == "diag") {
          th <- c(th, d); lower <- c(lower, 1e-8 * d); upper <- c(upper, rep(Inf, cc$L))
          fc <- c(fc, rep(FALSE, cc$L))
        } else if (cc$struct == "us") {
          ij <- .us_index(cc$L)
          v <- ifelse(ij[, 1] == ij[, 2], d[ij[, 1]], 0)
          th <- c(th, v)
          lower <- c(lower, ifelse(ij[, 1] == ij[, 2], 1e-8 * d[ij[, 1]], -Inf))
          upper <- c(upper, rep(Inf, nrow(ij))); fc <- c(fc, rep(FALSE, nrow(ij)))
        } else if (cc$struct == "fa") {
          L <- cc$L; kk <- cc$k
          lam <- matrix(0.1 * sqrt(d), L, kk)
          lam[, 1] <- sqrt(0.5 * d)
          cons <- matrix(FALSE, L, kk)
          for (m in seq_len(kk)) if (m > 1) { cons[seq_len(m - 1), m] <- TRUE; lam[seq_len(m - 1), m] <- 0 }
          th <- c(th, as.vector(lam), 0.5 * d)
          lower <- c(lower, rep(-Inf, L * kk), 1e-8 * d)
          upper <- c(upper, rep(Inf, L * kk + L))
          fc <- c(fc, as.vector(cons), rep(FALSE, L))
        }
      }
    }
    lab <- if (tk$is_resid) paste0("R!", tk$label) else tk$label
    info <- rbind(info, data.frame(termid = k, term = lab,
                                   name = paste0(lab, "!", tk$parnames),
                                   type = tk$partypes, lower = lower, upper = upper,
                                   fixed_constraint = fc, stringsAsFactors = FALSE))
    theta <- c(theta, th)
  }
  names(theta) <- info$name
  list(theta = theta, info = info)
}

.clip <- function(theta, info) {
  pmin(pmax(theta, info$lower), info$upper)
}

## project unstructured matrices onto the positive semi-definite cone
.project <- function(allterms, info, theta, eps = 1e-6) {
  for (k in seq_along(allterms)) {
    tk <- allterms[[k]]
    ids <- which(info$termid == k)
    pos <- if (tk$scale) 2L else 1L
    for (cc in tk$comps) {
      if (cc$npar == 0) next
      j <- ids[pos:(pos + cc$npar - 1)]
      pos <- pos + cc$npar
      if (cc$struct == "us") {
        S <- .comp_Sigma(cc, theta[j])
        e <- eigen(S, symmetric = TRUE)
        mx <- max(e$values)
        if (min(e$values) < eps * mx) {
          v <- pmax(e$values, eps * mx)
          S <- e$vectors %*% (v * t(e$vectors))
          theta[j] <- S[.us_index(cc$L)]
        }
      }
    }
  }
  theta
}

## check positive definiteness of us matrices
.valid <- function(allterms, info, theta) {
  for (k in seq_along(allterms)) {
    tk <- allterms[[k]]
    th <- theta[info$termid == k]
    pos <- if (tk$scale) 2L else 1L
    for (cc in tk$comps) {
      if (cc$npar == 0) next
      thc <- th[pos:(pos + cc$npar - 1)]
      pos <- pos + cc$npar
      if (cc$struct == "us") {
        ev <- eigen(.comp_Sigma(cc, thc), symmetric = TRUE, only.values = TRUE)$values
        if (min(ev) <= 1e-9 * max(abs(ev))) return(FALSE)
      }
    }
  }
  TRUE
}

## V matrix (and the component matrices needed for derivatives)
.build_V <- function(allterms, info, theta) {
  n <- nrow(allterms[[1]]$comps[[1]]$Z)
  V <- matrix(0, n, n)
  cache <- vector("list", length(allterms))
  for (k in seq_along(allterms)) {
    tk <- allterms[[k]]
    th <- theta[info$termid == k]
    if (identical(tk$kind, "str")) {
      ## sum_ab Sigma_ab Z_a K Z_b'
      for (j in seq_along(th)) V <- V + th[j] * tk$Mab[[j]]
      cache[[k]] <- list(ths = list(th), s2 = 1)
      next
    }
    pos <- if (tk$scale) 2L else 1L
    Ms <- vector("list", length(tk$comps)); ths <- vector("list", length(tk$comps))
    for (ci in seq_along(tk$comps)) {
      cc <- tk$comps[[ci]]
      if (cc$npar == 0) { Ms[[ci]] <- cc$M; ths[[ci]] <- numeric(0) }
      else {
        thc <- th[pos:(pos + cc$npar - 1)]; pos <- pos + cc$npar
        Ms[[ci]] <- .expand(cc, .comp_Sigma(cc, thc)); ths[[ci]] <- thc
      }
    }
    Mt <- Reduce(`*`, Ms)
    s2 <- if (tk$scale) th[1] else 1
    V <- V + s2 * Mt
    cache[[k]] <- list(Ms = Ms, ths = ths, s2 = s2, Mt = Mt)
  }
  list(V = V, cache = cache)
}

## derivative of V with respect to the i-th parameter
.dV <- function(allterms, info, cache, i) {
  k <- info$termid[i]
  tk <- allterms[[k]]
  pi_k <- which(info$termid == k)
  local <- match(i, pi_k)
  ch <- cache[[k]]
  if (identical(tk$kind, "str")) return(tk$Mab[[local]])
  if (tk$scale && local == 1) return(ch$Mt)
  ci <- tk$parcomp[local]; j <- tk$parj[local]
  cc <- tk$comps[[ci]]
  dM <- .expand(cc, .comp_dSigma(cc, ch$ths[[ci]], j))
  others <- ch$Ms[-ci]
  out <- if (length(others)) Reduce(`*`, others) * dM else dM
  ch$s2 * out
}

## REML log-likelihood, score and AI matrix
.reml_eval <- function(allterms, info, theta, y, X, deriv = TRUE, free = NULL, keep = FALSE) {
  bv <- .build_V(allterms, info, theta)
  V <- bv$V
  n <- length(y); p <- ncol(X)
  R <- tryCatch(chol(V), error = function(e) NULL)
  if (is.null(R)) {
    if (!deriv) return(list(loglik = -Inf))
    jit <- 1e-8 * mean(diag(V))
    R <- chol(V + diag(jit, n))
  }
  if (!deriv) {
    VX <- backsolve(R, backsolve(R, X, transpose = TRUE))
    Vy <- backsolve(R, backsolve(R, y, transpose = TRUE))
    XVX <- crossprod(X, VX)
    cC <- chol(XVX)
    b <- backsolve(cC, backsolve(cC, crossprod(X, Vy), transpose = TRUE))
    yPy <- sum(y * Vy) - sum(crossprod(X, Vy) * b)
    ll <- -0.5 * (2 * sum(log(diag(R))) + 2 * sum(log(diag(cC))) + yPy + (n - p) * log(2 * pi))
    return(list(loglik = ll))
  }
  Vi <- chol2inv(R)
  VX <- Vi %*% X
  XVX <- crossprod(X, VX)
  cC <- chol(XVX)
  Ci <- chol2inv(cC)
  P <- Vi - VX %*% Ci %*% t(VX)
  rm(Vi)
  Py <- drop(P %*% y)
  ll <- -0.5 * (2 * sum(log(diag(R))) + 2 * sum(log(diag(cC))) + sum(y * Py) + (n - p) * log(2 * pi))
  fi <- which(free)
  m <- length(fi)
  W <- matrix(0, n, m)
  trPV <- numeric(m)
  for (a in seq_len(m)) {
    dV <- .dV(allterms, info, bv$cache, fi[a])
    trPV[a] <- sum(P * dV)
    W[, a] <- dV %*% Py
  }
  score <- -0.5 * (trPV - drop(crossprod(Py, W)))
  AI <- 0.5 * crossprod(W, P %*% W)
  out <- list(loglik = ll, score = score, AI = AI, Py = Py)
  if (keep) { out$P <- P; out$VX <- VX; out$Ci <- Ci; out$V <- V }
  out
}
