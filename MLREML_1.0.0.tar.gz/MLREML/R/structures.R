## ---------------------------------------------------------------------------
## Variance structures and model terms
##
## A model term is a direct product of components, e.g. us(env):vm(gen, G).
## Each component has
##   * a "basis": the design of the component (a factor, a polynomial basis
##     of a covariate, a multi-membership factor or the observation units), and
##   * a "structure": the covariance (or correlation) matrix of the effects
##     of that component (id, vm, cs, ar1, expc, sexp, diag, us, fa).
## The covariance contributed by a term to Var(y) is
##     sigma2 * (Z1 S1 Z1') o (Z2 S2 Z2') o ...           (o = Hadamard)
## which is identical to Z (S1 x S2 x ...) Z' when Z is the face-splitting
## (row-wise Khatri-Rao) product of the component designs.
## ---------------------------------------------------------------------------

.corr_structs <- c("id", "vm", "cs", "ar1", "expc", "sexp")
.var_structs  <- c("diag", "us", "fa")
.all_structs  <- c(.corr_structs, .var_structs)
.basis_funs   <- c("pol", "leg", "mm")

## flatten a ':' call into its components
.split_colon <- function(e) {
  if (is.call(e) && identical(e[[1]], as.name(":")))
    return(c(.split_colon(e[[2]]), .split_colon(e[[3]])))
  list(e)
}

## Legendre polynomials (normalised, as used for random regression)
.legendre <- function(x, k) {
  r <- range(x)
  t <- if (diff(r) > 0) -1 + 2 * (x - r[1]) / diff(r) else rep(0, length(x))
  P <- matrix(0, length(x), k + 1)
  P[, 1] <- 1
  if (k >= 1) P[, 2] <- t
  if (k >= 2) for (j in 2:k) P[, j + 1] <- ((2 * j - 1) * t * P[, j] - (j - 1) * P[, j - 1]) / j
  P <- sweep(P, 2, sqrt((2 * (0:k) + 1) / 2), "*")
  colnames(P) <- as.character(0:k)
  P
}

## evaluate the basis of a component
.eval_basis <- function(e, data, env, nobs) {
  if (is.name(e)) {
    nm <- as.character(e)
    if (nm == "units") {
      u <- if (!is.null(data[[".units"]])) data[[".units"]] else seq_len(nobs)
      f <- factor(u, levels = unique(u))
      return(list(type = "factor", f = f, label = "units", numeric = FALSE, x = NULL))
    }
    if (is.null(data[[nm]])) stop("variable '", nm, "' not found in data")
    x <- data[[nm]]
    num <- is.numeric(x)
    f <- if (is.factor(x)) droplevels(x) else factor(x, levels = sort(unique(x)))
    return(list(type = "factor", f = f, label = nm, numeric = num, x = x))
  }
  if (is.call(e)) {
    fn <- as.character(e[[1]])
    if (fn %in% c("pol", "leg")) {
      x <- eval(e[[2]], data, env)
      k <- if (length(e) >= 3) eval(e[[3]], data, env) else 1
      if (fn == "pol") {
        Z <- outer(x, 0:k, "^")
        colnames(Z) <- as.character(0:k)
      } else Z <- .legendre(x, k)
      return(list(type = "basis", Z = Z, label = deparse(e), numeric = FALSE))
    }
    if (fn == "mm") {
      vars <- lapply(as.list(e)[-1], function(a) as.character(eval(a, data, env)))
      lev <- sort(unique(unlist(vars)))
      lev <- lev[!is.na(lev)]
      Z <- Matrix::Matrix(0, nobs, length(lev), sparse = TRUE)
      for (v in vars) {
        ok <- !is.na(v)
        Z <- Z + Matrix::sparseMatrix(i = which(ok), j = match(v[ok], lev),
                                      x = 1, dims = c(nobs, length(lev)))
      }
      colnames(Z) <- lev
      return(list(type = "basis", Z = Z, label = deparse(e), numeric = FALSE))
    }
  }
  stop("cannot interpret '", deparse(e), "' as a factor, pol(), leg(), mm() or units")
}

## build one component from an expression such as us(env), vm(gen, G), gen
.make_component <- function(e, data, env, nobs, dense = TRUE) {
  struct <- "id"; arg <- e; k <- NULL; K <- NULL; extra <- NULL
  if (is.call(e) && as.character(e[[1]]) %in% .all_structs) {
    struct <- as.character(e[[1]])
    arg <- e[[2]]
    if (struct == "fa") k <- if (length(e) >= 3) eval(e[[3]], data, env) else 1
    if (struct == "vm") {
      if (length(e) < 3) stop("vm() needs a relationship matrix: vm(factor, K)")
      K <- eval(e[[3]], env)
      if (is.null(rownames(K))) stop("the matrix given to vm() must have rownames")
      ## a matrix flagged as an inverse (attribute INVERSE = TRUE, as returned by Ainverse())
      ## is inverted for the dense engine and used as it is by the sparse engine
      if (dense) {
        if (isTRUE(attr(K, "INVERSE"))) K <- .invert_K(K)
        if (inherits(K, "Matrix")) K <- as.matrix(K)
      }
    }
    if (struct == "sexp") extra <- e[[3]]
  }
  if (struct == "sexp") {
    x <- eval(arg, data, env); y <- eval(extra, data, env)
    key <- paste(x, y, sep = "_")
    lev <- unique(key)
    xy <- cbind(x, y)[match(lev, key), , drop = FALSE]
    D <- as.matrix(stats::dist(xy))
    b <- list(type = "factor", f = factor(key, levels = lev),
              label = paste0("sexp(", deparse(arg), ",", deparse(extra), ")"), numeric = FALSE)
  } else b <- .eval_basis(arg, data, env, nobs)

  comp <- list(struct = struct, k = k, basis_type = b$type, label = b$label)
  if (b$type == "factor") {
    if (struct == "vm") {
      lev <- rownames(K)
      idx <- match(as.character(b$f), lev)
      if (anyNA(idx)) stop("levels of '", b$label, "' missing from the vm() matrix: ",
                           paste(utils::head(unique(as.character(b$f)[is.na(idx)])), collapse = ", "))
      comp$K <- K
    } else {
      lev <- levels(b$f)
      idx <- as.integer(b$f)
    }
    comp$idx <- idx
    comp$levels <- lev
    comp$Z <- Matrix::sparseMatrix(i = seq_len(nobs), j = idx, x = 1,
                                   dims = c(nobs, length(lev)))
  } else {
    if (struct == "vm") stop("vm() requires a factor")
    comp$Z <- Matrix::Matrix(b$Z, sparse = TRUE)
    comp$levels <- colnames(b$Z)
    comp$idx <- NULL
  }
  L <- length(comp$levels)
  comp$L <- L
  comp$var_type <- struct %in% .var_structs
  ## distance matrices for correlation structures
  if (struct == "ar1") {
    num <- suppressWarnings(as.numeric(comp$levels))
    pos <- if (!anyNA(num)) num else seq_len(L)
    comp$D <- abs(outer(pos, pos, "-"))
  }
  if (struct == "expc") {
    num <- suppressWarnings(as.numeric(comp$levels))
    if (anyNA(num)) stop("expc() needs a numeric variable")
    comp$D <- abs(outer(num, num, "-"))
  }
  if (struct == "sexp") comp$D <- D
  ## parameters
  comp$npar <- switch(struct, id = 0, vm = 0, cs = 1, ar1 = 1, expc = 1, sexp = 1,
                      diag = L, us = L * (L + 1) / 2, fa = L * k + L)
  comp$parnames <- .comp_parnames(comp)
  comp
}

.comp_parnames <- function(comp) {
  lev <- comp$levels; L <- comp$L
  switch(comp$struct,
         id = character(0), vm = character(0),
         cs = "cor", ar1 = "cor", expc = "cor", sexp = "cor",
         diag = lev,
         us = {
           ij <- which(lower.tri(diag(L), diag = TRUE), arr.ind = TRUE)
           ij <- ij[order(ij[, 1], ij[, 2]), , drop = FALSE]
           paste(lev[ij[, 1]], lev[ij[, 2]], sep = ":")
         },
         fa = c(paste0("fa", rep(seq_len(comp$k), each = L), "_", rep(lev, comp$k)),
                paste0("var_", lev)))
}

## positions of the us parameters (row-wise lower triangle)
.us_index <- function(L) {
  ij <- which(lower.tri(diag(L), diag = TRUE), arr.ind = TRUE)
  ij[order(ij[, 1], ij[, 2]), , drop = FALSE]
}

## covariance / correlation matrix of a component given its parameters
.comp_Sigma <- function(comp, th) {
  L <- comp$L
  switch(comp$struct,
         id = diag(L),
         vm = comp$K,
         cs = { S <- matrix(th[1], L, L); diag(S) <- 1; S },
         ar1 = , expc = , sexp = th[1]^comp$D,
         diag = diag(th, L),
         us = {
           S <- matrix(0, L, L); ij <- .us_index(L)
           S[ij] <- th; S[ij[, 2:1, drop = FALSE]] <- th; S
         },
         fa = {
           k <- comp$k
           Lam <- matrix(th[seq_len(L * k)], L, k)
           tcrossprod(Lam) + diag(th[L * k + seq_len(L)], L)
         })
}

## derivative of the component matrix with respect to its j-th parameter
.comp_dSigma <- function(comp, th, j) {
  L <- comp$L
  switch(comp$struct,
         cs = { S <- matrix(1, L, L); diag(S) <- 0; S },
         ar1 = , expc = , sexp = {
           ## d rho^d / d rho = d rho^(d - 1); version 1.0.0 fixes the derivative for distances
           ## smaller than one (0.9.0 used rho^max(d - 1, 0), wrong when 0 < d < 1)
           D <- comp$D
           out <- D * th[1]^(D - 1)
           out[D == 0] <- 0
           out
         },
         diag = { S <- matrix(0, L, L); S[j, j] <- 1; S },
         us = {
           ij <- .us_index(L)[j, ]
           S <- matrix(0, L, L); S[ij[1], ij[2]] <- 1; S[ij[2], ij[1]] <- 1; S
         },
         fa = {
           k <- comp$k
           if (j <= L * k) {
             Lam <- matrix(th[seq_len(L * k)], L, k)
             l <- (j - 1) %% L + 1; m <- (j - 1) %/% L + 1
             e <- numeric(L); e[l] <- 1
             outer(e, Lam[, m]) + outer(Lam[, m], e)
           } else {
             S <- matrix(0, L, L); l <- j - L * k; S[l, l] <- 1; S
           }
         })
}

## n x n matrix Z S Z' of a component
.expand <- function(comp, S) {
  if (!is.null(comp$idx)) {
    if (comp$struct %in% c("id") && is.null(S)) return(outer(comp$idx, comp$idx, "==") * 1)
    return(S[comp$idx, comp$idx, drop = FALSE])
  }
  as.matrix(comp$Z %*% S %*% Matrix::t(comp$Z))
}

## type of each parameter: "variance", "covariance", "correlation", "loading"
.comp_partypes <- function(comp) {
  L <- comp$L
  switch(comp$struct,
         id = character(0), vm = character(0),
         cs = "correlation", ar1 = "correlation", expc = "correlation", sexp = "correlation",
         diag = rep("variance", L),
         us = { ij <- .us_index(L); ifelse(ij[, 1] == ij[, 2], "variance", "covariance") },
         fa = c(rep("loading", L * comp$k), rep("variance", L)))
}

## build a term from a label such as "us(env):vm(gen, G)"
.make_term <- function(label, data, env, nobs, is_resid = FALSE, dense = TRUE) {
  e <- str2lang(label)
  if (.is_str_label(label)) {
    if (is_resid) stop("str() cannot be used in the residual formula")
    return(.make_str_term(e, label, data, env, nobs, dense))
  }
  parts <- .split_colon(e)
  comps <- lapply(parts, .make_component, data = data, env = env, nobs = nobs, dense = dense)
  nvar <- sum(vapply(comps, function(cc) cc$var_type, logical(1)))
  if (nvar > 1) stop("term '", label, "' has more than one variance-type component ",
                     "(diag/us/fa); only one is identifiable")
  term <- list(label = label, comps = comps, scale = (nvar == 0), is_resid = is_resid)
  term$names <- vapply(comps, function(cc) cc$label, "")
  term$npar <- term$scale + sum(vapply(comps, function(cc) cc$npar, 0))
  pn <- character(0); pt <- character(0); pc <- integer(0); pj <- integer(0)
  if (term$scale) { pn <- "sigma2"; pt <- "variance"; pc <- 0L; pj <- 0L }
  for (ci in seq_along(comps)) {
    cc <- comps[[ci]]
    if (cc$npar > 0) {
      pn <- c(pn, paste0(cc$label, "_", cc$parnames))
      pt <- c(pt, .comp_partypes(cc))
      pc <- c(pc, rep(ci, cc$npar)); pj <- c(pj, seq_len(cc$npar))
    }
  }
  term$parnames <- pn; term$partypes <- pt; term$parcomp <- pc; term$parj <- pj
  ## expanded matrices of components without parameters are fixed (dense engine only)
  if (dense) for (ci in seq_along(comps)) {
    cc <- comps[[ci]]
    if (cc$npar == 0) {
      S <- if (cc$struct == "vm") cc$K else NULL
      if (cc$struct == "id" && is.null(cc$idx)) S <- diag(cc$L)
      comps[[ci]]$M <- .expand(cc, S)
    }
  }
  term$comps <- comps
  term
}

## design matrix (n x prod(L)) and level names of a term (face-splitting product)
.term_Z <- function(term) {
  if (identical(term$kind, "str"))
    return(list(Z = do.call(cbind, term$Zs),
                levels = paste(rep(term$names, each = length(term$levels)), term$levels, sep = ":")))
  Zt <- Matrix::t(term$comps[[1]]$Z)
  lev <- term$comps[[1]]$levels
  if (length(term$comps) > 1) for (ci in 2:length(term$comps)) {
    cc <- term$comps[[ci]]
    Zt <- Matrix::KhatriRao(Zt, Matrix::t(cc$Z))
    lev <- as.vector(t(outer(lev, cc$levels, paste, sep = ":")))
  }
  list(Z = Matrix::t(Zt), levels = lev)
}

## covariance matrix of the effects of a term (direct product)
.term_G <- function(term, th) {
  G <- matrix(1, 1, 1)
  pos <- 1L
  if (term$scale) { s2 <- th[1]; pos <- 2L } else s2 <- 1
  for (cc in term$comps) {
    thc <- if (cc$npar > 0) th[pos:(pos + cc$npar - 1)] else numeric(0)
    pos <- pos + cc$npar
    G <- kronecker(G, .comp_Sigma(cc, thc))
  }
  s2 * G
}

## component matrices of a term at given parameters
.term_parts <- function(term, th) {
  pos <- 1L
  if (term$scale) { s2 <- th[1]; pos <- 2L } else s2 <- 1
  S <- list()
  for (ci in seq_along(term$comps)) {
    cc <- term$comps[[ci]]
    thc <- if (cc$npar > 0) th[pos:(pos + cc$npar - 1)] else numeric(0)
    pos <- pos + cc$npar
    S[[ci]] <- .comp_Sigma(cc, thc)
  }
  list(s2 = s2, S = S, L = vapply(term$comps, function(cc) cc$L, 0))
}

## multi-index (one column per component) of term levels, last component fastest
.level_index <- function(Ls, rows) {
  r <- rows - 1
  out <- matrix(0L, length(rows), length(Ls))
  for (ci in rev(seq_along(Ls))) {
    out[, ci] <- as.integer(r %% Ls[ci]) + 1L
    r <- r %/% Ls[ci]
  }
  out
}

## rows of G Z' (|rows| x n) without forming G
.GZt_rows <- function(term, parts, rows) {
  ai <- .level_index(parts$L, rows)
  out <- NULL
  for (ci in seq_along(term$comps)) {
    cc <- term$comps[[ci]]
    blk <- if (!is.null(cc$idx)) parts$S[[ci]][ai[, ci], cc$idx, drop = FALSE] else
      as.matrix(parts$S[[ci]][ai[, ci], , drop = FALSE] %*% Matrix::t(cc$Z))
    out <- if (is.null(out)) blk else out * blk
  }
  parts$s2 * out
}

## sub-matrix of G
.G_sub <- function(parts, rows, cols) {
  ar <- .level_index(parts$L, rows); ac <- .level_index(parts$L, cols)
  out <- matrix(parts$s2, length(rows), length(cols))
  for (ci in seq_along(parts$S)) out <- out * parts$S[[ci]][ar[, ci], ac[, ci], drop = FALSE]
  out
}

## diagonal of G
.G_diag <- function(parts) {
  d <- parts$s2
  for (S in parts$S) d <- kronecker(d, diag(S))
  as.vector(d)
}

## second derivative of the component matrix with respect to its parameters j1 and j2
## (needed by the Kenward-Roger adjustment; zero for structures linear in their parameters)
.comp_d2Sigma <- function(comp, th, j1, j2) {
  L <- comp$L
  switch(comp$struct,
         ar1 = , expc = , sexp = {
           D <- comp$D
           out <- D * (D - 1) * th[1]^(D - 2)
           out[D == 0 | D == 1] <- 0
           out
         },
         fa = {
           k <- comp$k
           if (j1 > L * k || j2 > L * k) return(NULL)
           l1 <- (j1 - 1) %% L + 1; m1 <- (j1 - 1) %/% L + 1
           l2 <- (j2 - 1) %% L + 1; m2 <- (j2 - 1) %/% L + 1
           if (m1 != m2) return(NULL)
           S <- matrix(0, L, L); S[l1, l2] <- S[l1, l2] + 1; S[l2, l1] <- S[l2, l1] + 1; S
         },
         NULL)
}

## dense inverse of a relationship matrix given as its (sparse) inverse
.invert_K <- function(Ki) {
  nm <- rownames(Ki)
  K <- as.matrix(Matrix::solve(Matrix::forceSymmetric(Matrix::Matrix(Ki, sparse = TRUE))))
  dimnames(K) <- list(nm, nm)
  K
}


## ---------------------------------------------------------------------------
## str(): correlated random effects of several factors sharing the levels of K
## (direct-maternal models). Var(u_1', ..., u_m')' = Sigma (m x m) %x% K.
## ---------------------------------------------------------------------------
.is_str_label <- function(label) {
  e <- tryCatch(str2lang(label), error = function(err) NULL)
  is.call(e) && identical(e[[1]], as.name("str"))
}

.make_str_term <- function(e, label, data, env, nobs, dense = TRUE) {
  args <- as.list(e)[-1]
  nms <- names(args); if (is.null(nms)) nms <- rep("", length(args))
  bad <- setdiff(nms[nms != ""], c("K", "cov"))
  if (length(bad)) stop("unknown argument(s) of str(): ", paste(bad, collapse = ", "))
  facs <- args[nms == ""]
  m <- length(facs)
  if (m < 2) stop("str() needs at least two factors, e.g. str(animal, dam, K = A)")
  fn <- vapply(facs, function(a) paste(deparse(a), collapse = ""), "")
  if (anyDuplicated(fn)) stop("the factors of str() must be different")
  cov <- if ("cov" %in% nms) eval(args[["cov"]], env) else "us"
  cov <- match.arg(cov, c("us", "diag"))
  K <- if ("K" %in% nms) eval(args[["K"]], env) else NULL
  vals <- lapply(facs, function(a) {
    v <- eval(a, data, env)
    v <- as.character(v)
    v[v %in% c("", "0", "NA")] <- NA
    v
  })
  if (is.null(K)) {
    lev <- sort(unique(unlist(vals))); lev <- lev[!is.na(lev)]
  } else {
    if (is.null(rownames(K))) stop("the matrix K of str() must have rownames")
    lev <- rownames(K)
    if (dense) {
      if (isTRUE(attr(K, "INVERSE"))) K <- .invert_K(K)
      if (inherits(K, "Matrix")) K <- as.matrix(K)
    }
  }
  idx <- lapply(seq_len(m), function(a) {
    i <- match(vals[[a]], lev)
    miss <- !is.na(vals[[a]]) & is.na(i)
    if (any(miss)) stop("levels of '", fn[a], "' missing from K in str(): ",
                        paste(utils::head(unique(vals[[a]][miss])), collapse = ", "))
    i
  })
  q <- length(lev)
  Zs <- lapply(idx, function(i) {
    ok <- which(!is.na(i))
    Matrix::sparseMatrix(i = ok, j = i[ok], x = 1, dims = c(nobs, q))
  })
  ## pseudo-component carrying Sigma (an us or diag structure on the m effects)
  ind <- Matrix::sparseMatrix(i = unlist(lapply(idx, function(i) which(!is.na(i)))),
                              j = rep(seq_len(m), vapply(idx, function(i) sum(!is.na(i)), 0L)),
                              x = 1, dims = c(nobs, m))
  pc <- list(struct = cov, k = NULL, basis_type = "effects", label = "str", idx = NULL,
             levels = fn, L = m, var_type = TRUE, Z = ind)
  pc$npar <- if (cov == "us") m * (m + 1) / 2 else m
  pc$parnames <- .comp_parnames(pc)
  term <- list(label = label, kind = "str", comps = list(pc), scale = FALSE, is_resid = FALSE,
               names = fn, m = m, cov = cov, idx = idx, Zs = Zs, levels = lev, K = K)
  term$npar <- pc$npar
  term$parnames <- pc$parnames
  term$partypes <- .comp_partypes(pc)
  term$parcomp <- rep(1L, pc$npar); term$parj <- seq_len(pc$npar)
  if (dense) term$Mab <- .str_M(term)
  term
}

## n x n matrices dV/dSigma_ab of a str() term: Z_a K Z_a' (a = b) and
## Z_a K Z_b' + Z_b K Z_a' (a != b), in the order of the parameters
.str_M <- function(term) {
  ZKZ <- function(a, b) {
    ia <- term$idx[[a]]; ib <- term$idx[[b]]
    na <- is.na(ia); nb <- is.na(ib)
    ia[na] <- 1L; ib[nb] <- 1L
    M <- if (is.null(term$K)) outer(ia, ib, "==") * 1 else term$K[ia, ib, drop = FALSE]
    M[na, ] <- 0; M[, nb] <- 0
    unname(M)
  }
  ij <- if (term$cov == "us") .us_index(term$m) else cbind(seq_len(term$m), seq_len(term$m))
  lapply(seq_len(nrow(ij)), function(r) {
    a <- ij[r, 1]; b <- ij[r, 2]
    if (a == b) ZKZ(a, a) else { M <- ZKZ(a, b); M + t(M) }
  })
}

## BLUPs and prediction error variances of a str() term (dense engine)
.str_blup_dense <- function(term, th, Py, P, pev) {
  m <- term$m; q <- length(term$levels); n <- length(Py)
  S <- .comp_Sigma(term$comps[[1]], th)
  Kcols <- function(rows, b) {
    ib <- term$idx[[b]]; nb <- is.na(ib); ib[nb] <- 1L
    B <- if (is.null(term$K)) outer(rows, ib, "==") * 1 else term$K[rows, ib, drop = FALSE]
    B[, nb] <- 0
    B
  }
  dK <- if (is.null(term$K)) rep(1, q) else diag(term$K)
  u <- numeric(m * q); pevv <- rep(NA_real_, m * q)
  chunk <- max(1L, floor(5e6 / n))
  for (a in seq_len(m)) for (st in seq(1L, q, by = chunk)) {
    rows <- st:min(q, st + chunk - 1L)
    GZt <- 0
    for (b in seq_len(m)) if (S[a, b] != 0) GZt <- GZt + S[a, b] * Kcols(rows, b)
    if (!is.matrix(GZt)) GZt <- matrix(0, length(rows), n)
    pos <- (a - 1) * q + rows
    u[pos] <- drop(GZt %*% Py)
    if (pev) pevv[pos] <- S[a, a] * dK[rows] - rowSums((GZt %*% P) * GZt)
  }
  dG <- rep(diag(S), each = q) * rep(dK, m)
  out <- data.frame(effect = rep(term$names, each = q), level = rep(term$levels, m),
                    blup = u, stringsAsFactors = FALSE)
  if (pev) {
    out$pev <- pmax(pevv, 0)
    out$se <- sqrt(out$pev)
    out$reliability <- ifelse(dG > 0, 1 - out$pev / dG, NA)
  }
  fit <- numeric(n)
  for (a in seq_len(m)) fit <- fit + as.vector(term$Zs[[a]] %*% u[(a - 1) * q + seq_len(q)])
  list(out = out, fit = fit)
}
