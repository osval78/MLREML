## =====================================================================
## 01_data_preparation.R
## Reads the G2F maize data (2014-2016), builds the genomic relationship
## matrices (G) and the environmental relationship matrices (W) used in
## the article "MLREML: an open-access R package ...".
## Raw files expected in data/raw/:  X_G2F_<year>.csv (markers),
##   Y_G2F_<year>.csv (phenotypes, BLUEs per Env x Hybrid), EC_G2F_<year>.csv
## =====================================================================
suppressPackageStartupMessages({library(MLREML); library(data.table)})
dir.create("data/processed", showWarnings = FALSE, recursive = TRUE)
dir.create("outputs", showWarnings = FALSE)
sink("outputs/01_data_preparation.txt", split = TRUE)

summ <- list()
for (yr in 2014:2016) {
  ## --- markers (already centred and standardised in the raw file) -------
  X <- fread(sprintf("data/raw/X_G2F_%d.csv", yr))
  hyb <- X$Hybrid
  X <- as.matrix(X[, -(1:2)]); rownames(X) <- hyb
  ## --- genomic relationship matrix: G = ZZ'/p with standardised markers --
  G <- Gmatrix(X, method = "scaled")
  G <- bend(G, tol = 1e-4)              # guarantee positive definiteness
  saveRDS(G, sprintf("data/processed/G_%d.rds", yr))
  ## --- phenotypes ------------------------------------------------------
  Y <- fread(sprintf("data/raw/Y_G2F_%d.csv", yr))
  Y <- Y[Hybrid %in% hyb]
  setnames(Y, "Grain_Moisture_BLUE", "GM")
  fwrite(Y, sprintf("data/processed/pheno_%d.csv", yr))
  ## --- environmental covariates -> environmental kernel W ---------------
  EC <- fread(sprintf("data/raw/EC_G2F_%d.csv", yr))
  envs <- EC$Env
  W0 <- apply(as.matrix(EC[, -(1:3)]), 2, function(v) as.numeric(trimws(v)))  # drop index, Env, Year
  W0 <- W0[, colSums(is.na(W0)) == 0, drop = FALSE]
  W0 <- W0[, apply(W0, 2, function(v) sd(v) > 0), drop = FALSE]
  W0 <- scale(W0)
  W <- tcrossprod(W0) / ncol(W0); dimnames(W) <- list(envs, envs)
  W <- bend(W / mean(diag(W)), tol = 1e-3)
  saveRDS(W, sprintf("data/processed/W_%d.rds", yr))
  summ[[as.character(yr)]] <- data.frame(
    Year = yr, Environments = uniqueN(Y$Env), Hybrids_genotyped = nrow(G),
    Hybrids_phenotyped = uniqueN(Y$Hybrid), Records = nrow(Y), SNPs = ncol(X),
    EC = ncol(W0), Mean_GM = mean(Y$GM), SD_GM = sd(Y$GM),
    mean_diag_G = mean(diag(G)), mean_offdiag_G = mean(G[upper.tri(G)]))
  rm(X, G); invisible(gc())
}
tab <- do.call(rbind, summ)
print(tab, digits = 4)
fwrite(tab, "outputs/Table_data_summary.csv")

## ---------------------------------------------------------------------
## Combined G for the 2014 and 2015 hybrids (bivariate example, Box 6).
## Marker codes are identical across the yearly files, so the rows can be
## stacked and the matrix computed on the union of hybrids.
## ---------------------------------------------------------------------
X14 <- fread("data/raw/X_G2F_2014.csv"); X15 <- fread("data/raw/X_G2F_2015.csv")
X15 <- X15[!Hybrid %in% X14$Hybrid]
X <- rbind(X14, X15); hyb <- X$Hybrid
X <- as.matrix(X[, -(1:2)]); rownames(X) <- hyb
G1415 <- bend(Gmatrix(X, method = "scaled"), tol = 1e-4)
saveRDS(G1415, "data/processed/G_2014_2015.rds")
rm(X, X14, X15); invisible(gc())

## Hybrid means per year (first stage of a two-stage analysis)
m14 <- fread("data/processed/pheno_2014.csv")[, .(GM2014 = mean(GM)), by = Hybrid]
m15 <- fread("data/processed/pheno_2015.csv")[, .(GM2015 = mean(GM)), by = Hybrid]
biv <- merge(m14, m15, by = "Hybrid", all = TRUE)
fwrite(biv, "data/processed/hybrid_means_2014_2015.csv")
cat("\nBivariate data: hybrids =", nrow(biv), "; both years =",
    sum(complete.cases(biv)), "\n")

## Parents of the 2016 hybrids (female line / tester), split at the
## top-level "/" (names of the lines may contain "/" inside parentheses)
split_top <- function(s) {
  ch <- strsplit(s, "")[[1]]; depth <- cumsum(ch == "(") - cumsum(ch == ")")
  pos <- which(ch == "/" & depth == 0); pos <- pos[length(pos)]
  c(substr(s, 1, pos - 1), substr(s, pos + 1, nchar(s)))
}
p16 <- fread("data/processed/pheno_2016.csv")
par16 <- unique(p16[, .(Hybrid)])
pp <- t(vapply(par16$Hybrid, split_top, character(2)))
par16[, `:=`(Female = pp[, 1], Tester = pp[, 2])]
p16 <- merge(p16, par16, by = "Hybrid")
fwrite(p16, "data/processed/pheno_2016.csv")
cat("2016: female lines =", uniqueN(par16$Female), "; testers =", uniqueN(par16$Tester), "\n")
print(sort(table(par16$Tester), decreasing = TRUE)[1:8])
sink()
