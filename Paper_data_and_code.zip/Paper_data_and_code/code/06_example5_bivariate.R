## =====================================================================
## 06_example5_bivariate.R  (Box 6)
## Bivariate genomic model for the hybrid means of 2014 and 2015
## (1,522 hybrids, 270 evaluated in both years): genetic correlation
## between years and prediction of 2015 performance borrowing 2014 data.
## =====================================================================
source("code/00_setup.R")
sink("outputs/06_example5_bivariate.txt", split = TRUE)
G <- readRDS("data/processed/G_2014_2015.rds")
b <- as.data.frame(fread("data/processed/hybrid_means_2014_2015.csv"))
b$Hybrid <- factor(b$Hybrid)
tt <- system.time(
  fb <- mlreml(cbind(GM2014, GM2015) ~ trait, random = ~ us(trait):vm(Hybrid, G),
               residual = ~ us(trait):units, data = b, trace = TRUE))[3]
print(summary(fb)); cat("time (s):", tt, "\n")
vg <- vc_matrix(fb, "us(trait):vm(Hybrid, G)"); vr <- vc_matrix(fb, "residual")
print(vg); print(vr)
print(vpredict(fb, rg ~ V2 / sqrt(V1 * V3)))
dg <- mean(diag(G))
print(vpredict(fb, as.formula(sprintf("h2_2014 ~ %.5f*V1/(%.5f*V1 + V4)", dg, dg))))
print(vpredict(fb, as.formula(sprintf("h2_2015 ~ %.5f*V3/(%.5f*V3 + V6)", dg, dg))))
saveRDS(list(vg = vg, vr = vr), "outputs/Ex5_bivariate_vc.rds")
u <- coef(fb, "random", "us(trait):vm(Hybrid, G)")
fwrite(u, "outputs/Ex5_bivariate_gebv.csv")

## --- CV: 2015 records of the 270 common hybrids masked in 5 folds ----------
both <- as.character(b$Hybrid[complete.cases(b)])
set.seed(15); fo <- setNames(sample(rep(1:5, length.out = length(both))), both)
cvb <- data.frame()
for (k in 1:5) {
  tst <- names(fo)[fo == k]
  bt <- b; bt$GM2015[bt$Hybrid %in% tst] <- NA
  ## univariate GBLUP with the 2015 data only
  y15 <- setNames(bt$GM2015, bt$Hybrid)
  gu <- gblup(y15, G)
  p_uni <- gu$beta[1] + gu$gebv[tst]
  ## bivariate model: the 2014 records of the test hybrids are used
  fk <- mlreml(cbind(GM2014, GM2015) ~ trait, random = ~ us(trait):vm(Hybrid, G),
               residual = ~ us(trait):units, data = bt, trace = FALSE, pev = FALSE,
               store = FALSE)
  uk <- coef(fk, "random", "us(trait):vm(Hybrid, G)")
  uu <- setNames(uk$blup, uk$level)
  p_biv <- fk$beta[1] + fk$beta["traitGM2015"] + uu[paste0("GM2015:", tst)]
  obs <- b$GM2015[match(tst, b$Hybrid)]
  cvb <- rbind(cvb, data.frame(fold = k, Model = c("Univariate GBLUP (2015)", "Bivariate (2014 + 2015)"),
                               cor = c(cor(p_uni, obs), cor(p_biv, obs)),
                               mspe = c(mean((p_uni - obs)^2), mean((p_biv - obs)^2))))
  cat("fold", k, "done\n")
}
print(cvb); print(aggregate(cbind(cor, mspe) ~ Model, cvb, mean))
fwrite(cvb, "outputs/Ex5_bivariate_cv.csv")
sink()
