## =====================================================================
## 03_example2_line_by_tester.R  (Box 3)
## Line x tester analysis of the 2016 hybrids in ten environments:
## GCA of female lines and testers, SCA, heterogeneous residuals, Wald
## tests, predicted tester means with SED, and agreement with lme4.
## =====================================================================
source("code/00_setup.R")
sink("outputs/03_example2_line_tester.txt", split = TRUE)
d <- load_2016()
cat("n =", nrow(d), "; female lines =", nlevels(d$Female), "; testers =",
    nlevels(d$Tester), "; hybrids =", nlevels(d$Hybrid), "\n\n")

## --- homogeneous residual (the model lme4 can also fit) -------------------
t0 <- system.time(
  f0 <- mlreml(GM ~ Env, random = ~ Female + Tester + Hybrid, data = d, trace = FALSE))[3]
print(summary(f0))
library(lme4)
t_lmer <- system.time(
  l0 <- lmer(GM ~ Env + (1 | Female) + (1 | Tester) + (1 | Hybrid), data = d, REML = TRUE))[3]
vc_l <- as.data.frame(VarCorr(l0))
val <- data.frame(component = c("Female (GCA lines)", "Tester (GCA testers)", "Hybrid (SCA)", "Residual"),
                  MLREML = f0$varcomp$estimate,
                  lme4 = vc_l$vcov[match(c("Female", "Tester", "Hybrid", "Residual"), vc_l$grp)])
val <- rbind(val, data.frame(component = "REML logLik", MLREML = f0$loglik, lme4 = as.numeric(logLik(l0))))
val <- rbind(val, data.frame(component = "time (s)", MLREML = t0, lme4 = t_lmer))
print(val, digits = 7); fwrite(val, "outputs/Ex2_validation_lme4.csv")
u_l <- ranef(l0)$Tester; u_m <- coef(f0, "random", "Tester")
cat("max |BLUP difference| for testers:", max(abs(u_m$blup - u_l[u_m$level, 1])), "\n\n")

## --- heterogeneous residual variances by environment --------------------
f1 <- mlreml(GM ~ Env, random = ~ Female + Tester + Hybrid,
             residual = ~ diag(Env):units, data = d, trace = FALSE)
print(summary(f1))
print(lrt(f0, f1, boundary = FALSE))
## Wald F tests: incremental (sequential) and conditional (marginality-respecting)
## statistics with Kenward-Roger denominator degrees of freedom (default of the
## dense engine in MLREML 1.0.0)
wf <- wald(f1); print(wf); fwrite(as.data.frame(wf), "outputs/Ex2_wald_KR.csv")
## proportion of genetic variance due to GCA (lines + testers)
print(vpredict(f1, GCA_ratio ~ (V1 + V2) / (V1 + V2 + V3)))
print(vpredict(f1, SCA_ratio ~ V3 / (V1 + V2 + V3)))
fwrite(f1$varcomp, "outputs/Ex2_varcomp_heterogeneous.csv")

## --- predicted means of the testers (averaged over environments) ---------
pt <- predict(f1, classify = "Tester")
nT <- table(unique(d[, c("Hybrid", "Tester")])$Tester)
pv <- pt$pvals; pv$n_hybrids <- as.integer(nT[as.character(pv$Tester)])
pv <- pv[order(pv$predicted.value), ]
print(head(pv, 10)); cat("Average SED (testers):", pt$avsed, "\n")
fwrite(pv, "outputs/Ex2_tester_predictions.csv")
fwrite(coef(f1, "random", "Female"), "outputs/Ex2_female_gca.csv")

## --- the same model with the sparse engine (MLREML >= 1.0.0) --------------
## With n < 5000, engine = "auto" selects the dense engine; the sparse engine
## (sparse mixed model equations, supernodal Cholesky) gives the same REML fit.
td <- system.time(fd <- mlreml(GM ~ Env, random = ~ Female + Tester + Hybrid,
                               residual = ~ diag(Env):units, data = d, trace = FALSE,
                               engine = "dense"))[3]
ts <- system.time(fs <- mlreml(GM ~ Env, random = ~ Female + Tester + Hybrid,
                               residual = ~ diag(Env):units, data = d, trace = FALSE,
                               engine = "sparse"))[3]
eng <- data.frame(engine = c("dense", "sparse"), logLik = c(fd$loglik, fs$loglik),
                  iterations = c(fd$iterations, fs$iterations), seconds = c(td, ts))
eng$max_abs_diff_varcomp <- c(0, max(abs(fs$varcomp$estimate - fd$varcomp$estimate)))
eng$max_abs_diff_blup <- c(0, max(abs(unlist(lapply(fs$blups, `[[`, "blup")) -
                                      unlist(lapply(fd$blups, `[[`, "blup")))))
print(eng, digits = 8); fwrite(eng, "outputs/Ex2_dense_vs_sparse.csv")
sink()
