## =====================================================================
## 00_setup.R  -  common objects and helper functions (sourced by 02-08)
## =====================================================================
suppressPackageStartupMessages({library(MLREML); library(data.table)})
## The scripts were written for MLREML 1.0.0 (active-set boundary handling,
## Kenward-Roger Wald tests, str() terms, dense/sparse engines).
if (packageVersion("MLREML") < "1.0.0") stop("MLREML >= 1.0.0 is required")
options(width = 110)
## Ten 2016 environments used in the multi-environment examples
MET_ENVS <- c("WIH2_2016", "IAH1_2016", "MOH1_2016", "DEH1_2016", "NYH2_2016",
              "GAH1_2016", "MNH1_2016", "ARH1_2016", "NCH1_2016", "OHH1_2016")

## Six environments (contrasting regions) used in the genomic MET examples
MET6_ENVS <- c("WIH2_2016", "IAH1_2016", "MOH1_2016", "DEH1_2016", "GAH1_2016", "NCH1_2016")

load_2016 <- function(envs = MET_ENVS) {
  Y <- fread("data/processed/pheno_2016.csv")
  d <- as.data.frame(Y[Env %in% envs])
  d$Env <- factor(d$Env, levels = envs)
  d$Hybrid <- factor(d$Hybrid); d$Female <- factor(d$Female); d$Tester <- factor(d$Tester)
  d
}

## Prediction of y for (Env, Hybrid) pairs from a fitted mlreml model:
## fixed environment effect (if Env is fixed) + every random term whose
## levels match Hybrid, Env or Env:Hybrid.
predict_eh <- function(fit, newdata) {
  b <- fit$beta
  mu <- rep(b[1], nrow(newdata))
  if (any(grepl("^Env", names(b)))) {
    ce <- paste0("Env", newdata$Env)
    add <- b[ce]; add[is.na(add)] <- 0; mu <- mu + add
  }
  keys <- list(H = as.character(newdata$Hybrid), E = as.character(newdata$Env),
               EH = paste(newdata$Env, newdata$Hybrid, sep = ":"))
  for (tb in fit$blups) {
    lv <- tb$level; u <- setNames(tb$blup, lv)
    hit <- vapply(keys, function(k) mean(k %in% lv), 0)
    k <- keys[[which.max(hit)]]
    if (max(hit) > 0) { a <- u[k]; a[is.na(a)] <- 0; mu <- mu + a }
  }
  unname(mu)
}

## Folds for hybrids (CV1: newly developed hybrids)
make_folds <- function(ids, k = 5, seed = 2026) {
  set.seed(seed); u <- unique(as.character(ids))
  setNames(sample(rep(seq_len(k), length.out = length(u))), u)
}
