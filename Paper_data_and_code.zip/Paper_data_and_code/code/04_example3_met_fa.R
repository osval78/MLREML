## =====================================================================
## 04_example3_met_fa.R  (Box 4)
## Genomic multi-environment models for six 2016 environments: a sequence
## of variance structures for the genotype x environment effects
## (compound symmetry, diagonal, factor analytic of order 1-2,
## unstructured) and a reaction-norm model with an environmental-covariate
## kernel W. All models use heterogeneous residual variances by environment.
## =====================================================================
source("code/00_setup.R")
sink("outputs/04_example3_met.txt", split = TRUE)
G <- readRDS("data/processed/G_2016.rds"); W <- readRDS("data/processed/W_2016.rds")
d <- load_2016(MET6_ENVS)
res <- ~ diag(Env):units
models <- list(
  "CS (main + GxE)" = ~ vm(Hybrid, G) + id(Env):vm(Hybrid, G),
  "DIAG"            = ~ diag(Env):vm(Hybrid, G),
  "FA1"             = ~ fa(Env, 1):vm(Hybrid, G),
  "FA2"             = ~ fa(Env, 2):vm(Hybrid, G),
  "US"              = ~ us(Env):vm(Hybrid, G),
  "RN (EC kernel W)" = ~ vm(Hybrid, G) + vm(Env, W):vm(Hybrid, G))
fits <- list(); tab <- data.frame()
for (m in names(models)) {
  cat("\n================", m, "================\n")
  tt <- system.time(f <- mlreml(GM ~ Env, random = models[[m]], residual = res,
                                data = d, trace = FALSE, maxit = 100))[3]
  if (!f$converged) {
    ## Fallback for a Heywood case (a specific variance of the FA structure
    ## goes to zero): fix the boundary parameter at a small value and restart
    ## from the current estimates (Sections 13.2-13.6 of the user guide).
    ## With MLREML 1.0.0 (active-set handling of parameters on the boundary)
    ## all the models of this example converge directly and this branch is
    ## not used; with version 0.9.0 it was needed for FA2.
    bnd <- rownames(f$varcomp)[f$varcomp$bound == "B"]
    cat("Not converged; fixing boundary parameter(s):", bnd, "\n")
    st <- f$theta; st[bnd] <- 1e-4
    tt <- tt + system.time(f <- mlreml(GM ~ Env, random = models[[m]], residual = res,
                                       data = d, start = st, fix = bnd, trace = FALSE,
                                       maxit = 100))[3]
  }
  print(summary(f))
  tab <- rbind(tab, data.frame(Model = m, Random = deparse(models[[m]]),
                               Parameters = sum(f$free), logLik = f$loglik,
                               AIC = f$AIC, BIC = f$BIC, Iterations = f$iterations,
                               Converged = f$converged, Seconds = tt))
  f$P <- NULL; f$VX <- NULL; f$data <- NULL      # keep the stored object small
  fits[[m]] <- f
  saveRDS(fits, "outputs/Ex3_fits.rds")
}
print(tab, digits = 6); fwrite(tab, "outputs/Ex3_model_comparison.csv")

## --- likelihood ratio tests between nested FA models ------------------
print(lrt(fits[["FA1"]], fits[["FA2"]], boundary = FALSE))
print(lrt(fits[["DIAG"]], fits[["FA1"]], boundary = FALSE))

## --- genetic covariance/correlation matrices -------------------------
for (m in c("FA1", "FA2", "US", "DIAG")) {
  vc <- vc_matrix(fits[[m]], paste0(names(fits[[m]]$blups)[1]))
  saveRDS(vc, sprintf("outputs/Ex3_vc_%s.rds", m))
}
vc2 <- readRDS("outputs/Ex3_vc_FA2.rds")
cat("\nFA2: genetic correlation matrix\n"); print(round(vc2$cor, 2))
cat("\nFA2: rotated loadings, specific variances, % variance explained\n")
print(round(cbind(vc2$loadings_rotated, psi = vc2$psi, pct = vc2$pct_variance), 3))
cat("\nGenetic variances by environment (DIAG):\n")
print(round(diag(readRDS("outputs/Ex3_vc_DIAG.rds")$cov), 3))
cat("\nReaction norm: variance components\n"); print(fits[["RN (EC kernel W)"]]$varcomp[1:2, 1:5])
cat("\nObserved correlation between the environments in W (EC kernel):\n")
print(round(cov2cor(W[MET6_ENVS, MET6_ENVS]), 2))
sink()
