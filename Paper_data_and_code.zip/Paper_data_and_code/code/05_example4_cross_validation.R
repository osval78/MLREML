## =====================================================================
## 05_example4_cross_validation.R  (Box 5)
## Predictive ability of the multi-environment models.
##  CV1: newly developed hybrids (5-fold, all records of a hybrid masked)
##  CV0: untested environments (leave one environment out), possible only
##       when environments are linked by the environmental kernel W.
## =====================================================================
source("code/00_setup.R")
sink("outputs/05_example4_cv.txt", split = TRUE)
G <- readRDS("data/processed/G_2016.rds"); W <- readRDS("data/processed/W_2016.rds")
d <- load_2016(MET6_ENVS)
res <- ~ diag(Env):units

## ---------------------------- CV1 ---------------------------------------
cv1_models <- list(
  "CS (main + GxE)"  = ~ vm(Hybrid, G) + id(Env):vm(Hybrid, G),
  "DIAG"             = ~ diag(Env):vm(Hybrid, G),
  "FA1"              = ~ fa(Env, 1):vm(Hybrid, G),
  "FA2"              = ~ fa(Env, 2):vm(Hybrid, G),
  "RN (EC kernel W)" = ~ vm(Hybrid, G) + vm(Env, W):vm(Hybrid, G))
fold <- make_folds(d$Hybrid, k = 5)
d$fold <- fold[as.character(d$Hybrid)]
cv1 <- data.frame()
for (k in 1:5) for (m in names(cv1_models)) {
  trn <- d[d$fold != k, ]; tst <- d[d$fold == k, ]
  f <- mlreml(GM ~ Env, random = cv1_models[[m]], residual = res, data = trn,
              trace = FALSE, pev = FALSE, store = FALSE, maxit = 100)
  tst$pred <- predict_eh(f, tst)
  r <- do.call(rbind, lapply(split(tst, tst$Env), function(z)
    data.frame(Env = z$Env[1], cor = cor(z$pred, z$GM),
               mspe = mean((z$pred - z$GM)^2), n = nrow(z))))
  r$fold <- k; r$Model <- m; cv1 <- rbind(cv1, r)
  cat(sprintf("CV1 fold %d %-18s mean r = %.3f\n", k, m, mean(r$cor)))
  fwrite(cv1, "outputs/Ex4_CV1_results.csv")
}
s1 <- aggregate(cbind(cor, mspe) ~ Model, cv1, mean)
print(s1[order(-s1$cor), ], digits = 4)

## ---------------------------- CV0 ---------------------------------------
cv0_models <- list(
  "G only"           = ~ vm(Env, W) + vm(Hybrid, G),
  "RN (EC kernel W)" = ~ vm(Env, W) + vm(Hybrid, G) + vm(Env, W):vm(Hybrid, G))
cv0 <- data.frame()
for (e in MET6_ENVS) for (m in names(cv0_models)) {
  trn <- droplevels(d[d$Env != e, ]); tst <- d[d$Env == e, ]
  f <- mlreml(GM ~ 1, random = cv0_models[[m]], residual = ~ diag(Env):units,
              data = trn, trace = FALSE, pev = FALSE, store = FALSE, maxit = 100)
  p <- predict_eh(f, tst)
  cv0 <- rbind(cv0, data.frame(Env = e, Model = m, cor = cor(p, tst$GM),
                               mspe = mean((p - tst$GM)^2), n = nrow(tst)))
  cat(sprintf("CV0 %-10s %-18s r = %.3f\n", e, m, cor(p, tst$GM)))
  fwrite(cv0, "outputs/Ex4_CV0_results.csv")
}
print(aggregate(cbind(cor, mspe) ~ Model, cv0, mean), digits = 4)
sink()
