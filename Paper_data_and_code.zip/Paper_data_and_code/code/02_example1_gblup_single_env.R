## =====================================================================
## 02_example1_gblup_single_env.R  (Box 2 of the article)
## GBLUP in one environment with the general engine mlreml() and with the
## spectral function gblup(); genomic heritability; GEBVs of unphenotyped
## hybrids; 5-fold cross-validation in all 18 environments of 2016.
## =====================================================================
source("code/00_setup.R")
sink("outputs/02_example1_gblup.txt", split = TRUE)
G <- readRDS("data/processed/G_2016.rds")
Y <- as.data.frame(fread("data/processed/pheno_2016.csv"))
d1 <- subset(Y, Env == "WIH2_2016"); d1$Hybrid <- factor(d1$Hybrid)
cat("Records in WIH2_2016:", nrow(d1), " genotyped hybrids:", nrow(G), "\n\n")

## --- (a) general AI-REML engine ---------------------------------------
t_ml <- system.time(
  fit <- mlreml(GM ~ 1, random = ~ vm(Hybrid, G), data = d1, trace = TRUE))[3]
print(summary(fit))
dg <- mean(diag(G))
h2 <- vpredict(fit, as.formula(sprintf("h2 ~ %.6f * V1 / (%.6f * V1 + V2)", dg, dg)))
print(h2)

## --- (b) spectral GBLUP ----------------------------------------------
y <- setNames(d1$GM, d1$Hybrid)
t_gb <- system.time(gb <- gblup(y, G))[3]
print(gb$varcomp)
cmp <- data.frame(
  quantity = c("logLik", "sigma2_g", "sigma2_e", "time_sec"),
  mlreml = c(fit$loglik, fit$varcomp$estimate, t_ml),
  gblup  = c(gb$loglik, gb$varcomp[1:2], t_gb))
print(cmp, digits = 7)
fwrite(cmp, "outputs/Ex1_mlreml_vs_gblup.csv")

## --- (c) GEBVs of all 456 hybrids, phenotyped or not --------------------
u <- coef(fit, "random", "vm(Hybrid, G)")
u$phenotyped <- u$level %in% d1$Hybrid
u$gebv_gblup <- gb$gebv[u$level]
cat("\nCorrelation of BLUPs mlreml vs gblup:", cor(u$blup, u$gebv_gblup),
    "  max abs diff:", max(abs(u$blup - u$gebv_gblup)), "\n")
print(aggregate(reliability ~ phenotyped, u, mean))
fwrite(u, "outputs/Ex1_gebv_WIH2_2016.csv")

## --- (d) 5-fold CV (5 replicates) in each of the 18 environments ------
cvall <- rbindlist(lapply(sort(unique(Y$Env)), function(e) {
  de <- subset(Y, Env == e)
  r <- cv_gblup(setNames(de$GM, de$Hybrid), G, folds = 5, reps = 5, seed = 1)
  r$Env <- e; r
}))
print(cvall[, .(mean_cor = mean(cor), sd = sd(cor), h2 = mean(h2)), by = Env])
fwrite(cvall, "outputs/Ex1_cv_by_environment.csv")
sink()
