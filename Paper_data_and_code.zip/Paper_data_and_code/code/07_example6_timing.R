## =====================================================================
## 07_example6_timing.R
## Computing time of MLREML as a function of the number of records
## (random subsets of the six 2016 environments).
## =====================================================================
source("code/00_setup.R")
sink("outputs/07_timing.txt", split = TRUE)
G <- readRDS("data/processed/G_2016.rds")
d <- load_2016(MET6_ENVS)
## warm-up fit (loads code and BLAS) so that the first timing is not inflated
invisible(mlreml(GM ~ Env, random = ~ vm(Hybrid, G), data = d[1:200, ], trace = FALSE))
tim <- data.frame()
for (n in c(400, 800, 1200, 1596)) {
  set.seed(n); s <- droplevels(d[sort(sample(nrow(d), n)), ])
  t1 <- system.time(f1 <- mlreml(GM ~ Env, random = ~ vm(Hybrid, G), data = s,
                                 trace = FALSE, pev = FALSE))[3]
  t2 <- system.time(f2 <- mlreml(GM ~ Env, random = ~ fa(Env, 1):vm(Hybrid, G),
                                 residual = ~ diag(Env):units, data = s,
                                 trace = FALSE, pev = FALSE, maxit = 100))[3]
  tim <- rbind(tim,
    data.frame(n = n, Model = "GBLUP (2 parameters)", parameters = sum(f1$free),
               iterations = f1$iterations, seconds = t1, sec_per_iter = t1 / (f1$iterations + 2)),
    data.frame(n = n, Model = "FA1 GxE + diag residual (18 parameters)", parameters = sum(f2$free),
               iterations = f2$iterations, seconds = t2, sec_per_iter = t2 / (f2$iterations + 2)))
  print(tail(tim, 2)); fwrite(tim, "outputs/Ex6_timing.csv")
}
cat("\nR session:\n"); print(sessionInfo()$BLAS); print(R.version.string)
sink()
